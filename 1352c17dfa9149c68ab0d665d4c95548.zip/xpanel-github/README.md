# XPanel 希旭面板 - GitHub 一键安装发布指南

把 `sh/` 和 `release/` 两个文件夹上传到你的 **GitHub 公开仓库**，用户就能用一条命令在线安装：

```bash
bash <(curl -sSL https://raw.githubusercontent.com/xixuwlkj/xpanel/main/sh/xp.sh)
```

## 仓库文件结构（上传后）

```
xpanel/  （你的仓库）
├── sh/
│   └── xp.sh              ← 在线安装引导脚本（已填好你的仓库地址）
└── release/
    └── xpanel.zip         ← 面板安装包
```

## 上传方法（手机或电脑都行）

1. 打开仓库主页 `https://github.com/xixuwlkj/xpanel`
2. 文件列表上方点 **Add file**（或绿色 **+** 图标）→ 选 **Upload files**
3. 选中本目录里的 `sh/xp.sh` 和 `release/xpanel.zip` 一起上传
   - 注意保持目录层级：先建 `sh/` 和 `release/` 文件夹，把文件放进去
   - 网页端拖拽 zip/sh 文件时，GitHub 会自动按路径建文件夹；如果手动，请先点「creating new files here」逐级建 `sh/`、`release/` 目录
4. 滚动到底部点绿色 **Commit changes**

## 验证是否成功

浏览器打开以下两个链接，能正常显示内容就成功了：

- `https://raw.githubusercontent.com/xixuwlkj/xpanel/main/sh/xp.sh`
- `https://raw.githubusercontent.com/xixuwlkj/xpanel/main/release/xpanel.zip`

成功后用户在服务器上执行：

```bash
bash <(curl -sSL https://raw.githubusercontent.com/xixuwlkj/xpanel/main/sh/xp.sh)
```

## 常见问题

- 仓库必须 **Public**，否则 raw 链接 404
- 默认分支是 `main`（截图里已确认），无需改动
- raw 有 CDN 缓存，刚上传后 1~2 分钟可能拉不到，稍等即可
