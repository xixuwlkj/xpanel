# -*- coding: utf-8 -*-
"""
XPanel 希旭面板 - 端到端 API 测试
运行: 在项目根目录执行 python3 tests/test_api.py
需要先设置测试路径环境变量（见 test 脚本或 install.sh）
"""
import base64
import json
import os
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 测试用临时目录（避免污染系统）
_BASE = os.path.join(tempfile.gettempdir(), 'xpanel_test')
os.makedirs(_BASE, exist_ok=True)
os.environ['XPANEL_WWW_ROOT'] = os.path.join(_BASE, 'wwwroot')
os.environ['XPANEL_NGINX_CONF_DIR'] = os.path.join(_BASE, 'nginx')
os.environ['XPANEL_MAIL_ROOT'] = os.path.join(_BASE, 'mail')
os.environ['XPANEL_POSTFIX_MAIN_CF'] = os.path.join(_BASE, 'postfix/main.cf')
os.environ['XPANEL_POSTFIX_VIRTUAL'] = os.path.join(_BASE, 'postfix/virtual')
os.environ['XPANEL_POSTFIX_VMAILBOX'] = os.path.join(_BASE, 'postfix/vmailbox')
os.environ['XPANEL_DOVECOT_CONF_DIR'] = os.path.join(_BASE, 'dovecot')
os.environ['XPANEL_DOVECOT_CONF'] = os.path.join(_BASE, 'dovecot/dovecot.conf')
os.environ['XPANEL_DOVECOT_PASSWD'] = os.path.join(_BASE, 'dovecot/dovecot-passwd')
os.environ['XPANEL_SYSTEMD_DIR'] = os.path.join(_BASE, 'systemd')
# 清理旧的测试数据目录（项目 data 目录）
_PROJ_DATA = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data')
import shutil
if os.path.isdir(_PROJ_DATA):
    shutil.rmtree(_PROJ_DATA)

from xpanel.app import app

app.config['TESTING'] = True
c = app.test_client()

passed, failed = 0, 0


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1
        print(f'  [PASS] {name}')
    else:
        failed += 1
        print(f'  [FAIL] {name} {extra}')


print('== 1. 认证 ==')
r = c.post('/api/login', json={'username': 'admin', 'password': 'xpanel888'})
check('默认账号登录', r.status_code == 200 and r.get_json()['ok'])
tok = r.get_json()['token']
H = {'X-Panel-Token': tok}
check('错误密码被拒', c.post('/api/login', json={'username': 'admin', 'password': 'bad'}).get_json()['ok'] is False)
check('无 token 被拒', c.get('/api/system/overview').status_code == 401)
check('改密码', c.post('/api/change_password', json={'old_password': 'xpanel888', 'new_password': 'newpass123'}, headers=H).get_json()['ok'])
check('新密码登录', c.post('/api/login', json={'username': 'admin', 'password': 'newpass123'}).get_json()['ok'])
# 改回
c.post('/api/change_password', json={'old_password': 'newpass123', 'new_password': 'xpanel888'}, headers=H)

print('== 2. 系统监控 ==')
r = c.get('/api/system/overview', headers=H).get_json()
check('系统总览', r['ok'] and 'data' in r and 'cpu_percent' in r['data'])
r = c.get('/api/system/services', headers=H).get_json()
check('服务状态', r['ok'] and isinstance(r['data'], list))
r = c.get('/api/system/cpu_history', headers=H).get_json()
check('CPU 历史采样', r['ok'] and len(r['data']) >= 2)

print('== 3. 网站管理 ==')
for st, dom in (('php', 'php.example.com'), ('python', 'py.example.com'), ('static', 'st.example.com')):
    r = c.post('/api/sites', json={'name': st, 'domain': dom, 'site_type': st,
                                   'php_version': '8.1', 'port': 8001}, headers=H)
    check(f'创建 {st} 站点', r.get_json()['ok'], r.get_data(as_text=True))
r = c.get('/api/sites', headers=H).get_json()
check('站点列表 3 个', len(r['data']) == 3)
r = c.get('/api/sites/1/config', headers=H).get_json()
check('PHP 站点含 fastcgi 配置', 'fastcgi' in r['data']['nginx_conf'])
r = c.get('/api/sites/2/config', headers=H).get_json()
check('Python 站点含反向代理', 'proxy_pass' in r['data']['nginx_conf'])
r = c.get('/api/sites/3/config', headers=H).get_json()
check('静态站点 index', 'try_files' in r['data']['nginx_conf'])
# 检查生成的站点文件
check('PHP 站点根目录有 index.php', os.path.exists(os.path.join(_BASE, 'wwwroot/php.example.com/index.php')))
check('静态站点根目录有 index.html', os.path.exists(os.path.join(_BASE, 'wwwroot/st.example.com/index.html')))
# 重复域名拒绝
r = c.post('/api/sites', json={'name': 'dup', 'domain': 'php.example.com', 'site_type': 'php'}, headers=H)
check('重复域名被拒', r.get_json()['ok'] is False)
r = c.post('/api/sites/1/toggle', headers=H)
check('站点启停', r.get_json()['ok'])

print('== 4. 节点管理 ==')
r = c.get('/api/nodes/status', headers=H).get_json()
check('Xray 状态接口', r['ok'] and 'installed' in r['data'])
r = c.post('/api/nodes', json={'name': 'hk', 'protocol': 'vmess', 'port': 10086, 'network': 'tcp'}, headers=H)
check('创建 vmess 节点', r.get_json()['ok'])
r = c.post('/api/nodes', json={'name': 'ws', 'protocol': 'vmess', 'port': 10087, 'network': 'ws', 'path': '/ray'}, headers=H)
check('创建 ws 节点', r.get_json()['ok'])
r = c.post('/api/nodes', json={'name': 'dup', 'protocol': 'vmess', 'port': 10086, 'network': 'tcp'}, headers=H)
check('重复端口被拒', r.get_json()['ok'] is False)
r = c.get('/api/nodes', headers=H).get_json()
check('节点列表 2 个', len(r['data']) == 2)
n = r['data'][0]
# 验证 vmess 链接可解码
b64 = n['share_link'].split('vmess://')[1]
decoded = json.loads(base64.b64decode(b64 + '===').decode())
check('vmess 链接可解码', decoded['port'] == str(n['port']) and decoded['id'] == n['uuid'])
r = c.get('/api/nodes/1', headers=H).get_json()
check('节点详情含 Xray JSON', json.loads(r['data']['json'])['protocol'] == 'vmess')
r = c.post('/api/nodes/1/toggle', headers=H)
check('节点启停', r.get_json()['ok'])

print('== 5. 邮箱管理 ==')
r = c.post('/api/email/domains', json={'domain': 'fwd.example.com', 'mode': 'forward', 'forward_target': 'me@qq.com'}, headers=H)
check('创建转发域名', r.get_json()['ok'])
fwd_id = r.get_json()['id']
r = c.post('/api/email/accounts', json={'domain_id': fwd_id, 'prefix': 'sales', 'account_type': 'alias'}, headers=H)
check('创建转发别名', r.get_json()['ok'])
r = c.post('/api/email/domains', json={'domain': 'mail.example.net', 'mode': 'standalone'}, headers=H)
check('创建独立邮箱域名', r.get_json()['ok'])
std_id = r.get_json()['id']
r = c.post('/api/email/accounts', json={'domain_id': std_id, 'prefix': 'bob', 'account_type': 'mailbox', 'password': 'bob123456'}, headers=H)
check('创建独立邮箱账号', r.get_json()['ok'])
# 校验生成的配置文件
virtual = open(os.path.join(_BASE, 'postfix/virtual')).read()
check('转发配置含 sales@fwd.example.com→me@qq.com', f'sales@fwd.example.com\tme@qq.com' in virtual)
vmailbox = open(os.path.join(_BASE, 'postfix/vmailbox')).read()
check('独立邮箱映射含 bob', 'bob@mail.example.net' in vmailbox)
pwdf = open(os.path.join(_BASE, 'dovecot/dovecot-passwd')).read()
check('Dovecot 密码文件含 bob', 'bob@mail.example.net:{PLAIN}bob123456' in pwdf)

print('== 6. 网页邮箱 Webmail ==')
# 投放一封测试邮件
md = os.path.join(_BASE, 'mail/mail.example.net/bob/Maildir/new')
os.makedirs(md, exist_ok=True)
with open(os.path.join(md, '1.test'), 'w', encoding='utf-8') as f:
    f.write("From: alice@example.com\nTo: bob@mail.example.net\n"
            "Subject: =?utf-8?B?5rWL6K+V5L2T6aqM?=\n\n这是测试邮件\n")
r = c.get('/api/webmail/mail.example.net/inbox')
check('未登录访问被拒', r.get_json()['ok'] is False)
r = c.post('/api/webmail/mail.example.net/login', json={'prefix': 'bob', 'password': 'bob123456'})
check('Webmail 登录', r.get_json()['ok'])
wtok = r.get_json()['token']
WH = {'X-WM-Token': wtok}
r = c.get('/api/webmail/mail.example.net/inbox', headers=WH).get_json()
check('收件箱有 1 封', len(r['data']['new']) == 1)
r = c.get('/api/webmail/mail.example.net/read?box=new&file=1.test', headers=WH).get_json()
check('读信正文正常', r['ok'] and '测试邮件' in r['data']['body'], repr(r['data'].get('body')))
check('主题解码正常', r['data']['subject'] == '测试体验', r['data']['subject'])
# 非管理员不能管理账号
r = c.post('/api/webmail/mail.example.net/login', json={'prefix': 'admin', 'password': ''})
# 用 admin 账号
r = c.get('/api/email/domains', headers=H).get_json()
admin_acct = [a for a in r['data'] if a['domain'] == 'mail.example.net'][0]['accounts'][0]
admin_pwd = admin_acct['password']
r = c.post('/api/webmail/mail.example.net/login', json={'prefix': 'admin', 'password': admin_pwd})
wtok2 = r.get_json()['token']
r = c.get('/api/webmail/mail.example.net/accounts', headers={'X-WM-Token': wtok2}).get_json()
check('admin 可管理账号', r['ok'])

print('== 7. 面板页面 ==')
check('首页 200', c.get('/').status_code == 200)
check('前端 JS 200', c.get('/static/js/app.js').status_code == 200)
check('前端 CSS 200', c.get('/static/css/style.css').status_code == 200)
check('Webmail 页面 200', c.get('/webmail/mail.example.net').status_code == 200)

print(f'\n========== 结果: {passed} 通过, {failed} 失败 ==========')
sys.exit(1 if failed else 0)
