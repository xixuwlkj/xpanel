# -*- coding: utf-8 -*-
"""
XPanel 希旭面板 - 通用工具
"""
import hashlib
import hmac
import os
import random
import re
import secrets
import string
import subprocess
import time
import uuid as _uuid
import json
from . import config


# ---------------- 密码与安全 ----------------
def hash_password(password: str, salt: str = None) -> str:
    """PBKDF2 哈希，返回 salt$hash"""
    if not salt:
        salt = secrets.token_hex(16)
    dk = hashlib.pbkdf2_hmac('sha256', password.encode(), salt.encode(), 100000)
    return f"{salt}${dk.hex()}"


def verify_password(password: str, stored: str) -> bool:
    if not stored or '$' not in stored:
        return False
    salt, _ = stored.split('$', 1)
    return hmac.compare_digest(hash_password(password, salt), stored)


def gen_token() -> str:
    return secrets.token_urlsafe(32)


def gen_password(length=10) -> str:
    chars = string.ascii_letters + string.digits
    return ''.join(secrets.choice(chars) for _ in range(length))


def gen_uuid() -> str:
    return str(_uuid.uuid4())


# ---------------- Shell 执行 ----------------
def run_cmd(cmd, timeout=60):
    """执行 shell 命令，返回 (code, stdout, stderr)"""
    try:
        p = subprocess.run(cmd, shell=True, capture_output=True,
                           text=True, timeout=timeout)
        return p.returncode, p.stdout.strip(), p.stderr.strip()
    except subprocess.TimeoutExpired:
        return 1, '', 'timeout'


def which(name):
    code, out, _ = run_cmd(f"command -v {name}")
    return out if code == 0 and out else ''


def read_file(path):
    try:
        with open(path, 'r', encoding='utf-8', errors='ignore') as f:
            return f.read()
    except Exception:
        return ''


def write_file(path, content, mode='w'):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, mode, encoding='utf-8') as f:
        f.write(content)
    return True


def save_json(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)


def load_json(path, default=None):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return default if default is not None else {}


# ---------------- 校验 ----------------
DOMAIN_RE = re.compile(
    r'^(?=.{4,253}$)([a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,63}$')


def valid_domain(d):
    return bool(DOMAIN_RE.match(d or ''))


def valid_port(p):
    try:
        return 1 <= int(p) <= 65535
    except Exception:
        return False


def safe_filename(name):
    return re.sub(r'[^a-zA-Z0-9_.-]', '_', name)


def ensure_root_path(domain):
    """按宝塔习惯返回站点根目录"""
    return os.path.join(config.WWW_ROOT, safe_filename(domain))
