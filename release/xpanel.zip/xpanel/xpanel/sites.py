# -*- coding: utf-8 -*-
"""
XPanel 希旭面板 - 网站管理
支持：PHP 站点 / Python 项目(flask/fastapi/gunicorn) / 静态站点
"""
import os
import re
from flask import Blueprint, request, jsonify

from . import config, db, utils
from .auth import login_required

bp = Blueprint('sites', __name__)


# ---------- 辅助 ----------
def nginx_conf_dir():
    """自动识别 Nginx 站点配置目录（兼容宝塔与标准发行版）"""
    cfg = config.NGINX_CONF_DIR
    # 显式配置的路径（env 指定或非默认）优先，自动创建
    if cfg != '/www/server/nginx/conf/vhost':
        os.makedirs(cfg, exist_ok=True)
        return cfg
    candidates = [
        config.NGINX_CONF_DIR,                 # /www/server/nginx/conf/vhost
        '/www/server/panel/vhost/nginx',       # 宝塔其他路径
        '/etc/nginx/conf.d',
        '/etc/nginx/sites-enabled',
    ]
    for d in candidates:
        if os.path.isdir(d):
            return d
    # 都不存在则默认标准目录（安装脚本会创建）
    os.makedirs('/etc/nginx/conf.d', exist_ok=True)
    return '/etc/nginx/conf.d'


def detect_php_sockets():
    """探测系统已安装的 php-fpm socket，返回版本列表"""
    sockets = []
    # Ubuntu/Debian: /run/php/php*-fpm.sock
    run_dir = '/run/php'
    if os.path.isdir(run_dir):
        for f in sorted(os.listdir(run_dir)):
            m = re.match(r'php([\d.]+)-fpm\.sock', f)
            if m:
                sockets.append({'version': m.group(1),
                                'socket': f"/run/php/{f}"})
    # 宝塔风格: /www/server/php/xx/var/run/php-fpm.sock
    if os.path.isdir(config.PHP_CONF_DIR):
        for v in sorted(os.listdir(config.PHP_CONF_DIR)):
            sock = os.path.join(config.PHP_CONF_DIR, v, 'var/run/php-fpm.sock')
            if os.path.exists(sock):
                sockets.append({'version': v, 'socket': sock})
    if not sockets:
        # 兜底：探测可执行 php-fpm
        code, out, _ = utils.run_cmd("ls /usr/sbin/php-fpm* /usr/bin/php-fpm* 2>/dev/null")
        for line in out.splitlines():
            m = re.search(r'php-fpm([\d.]*)', line)
            if m:
                v = m.group(1) or '8.1'
                sockets.append({'version': v, 'socket': f"/run/php/php{v}-fpm.sock"})
    return sockets


def nginx_conf_for(site):
    """根据站点信息生成 Nginx server 配置"""
    server_name = site['domain']
    root = site['root_path'] or utils.ensure_root_path(site['domain'])
    listen = [80]
    lines = []
    lines.append(f"# XPanel 站点: {site['name']} ({site['domain']})")
    lines.append("server {")
    lines.append(f"    listen {', '.join(str(p) for p in listen)};")
    lines.append(f"    server_name {server_name};")
    lines.append(f"    root {root};")

    if site['site_type'] == 'static':
        lines.append("    index index.html index.htm;")
        lines.append("    location / {")
        lines.append("        try_files $uri $uri/ =404;")
        lines.append("    }")
    elif site['site_type'] == 'php':
        ver = site.get('php_version') or '8.1'
        sock = detect_php_sockets()
        socket_path = f"/run/php/php{ver}-fpm.sock"
        for s in sock:
            if s['version'].startswith(ver.split('.')[0]):
                socket_path = s['socket']
                break
        lines.append("    index index.php index.html index.htm;")
        lines.append("    location / {")
        lines.append("        try_files $uri $uri/ /index.php?$query_string;")
        lines.append("    }")
        lines.append("    location ~ \\.php$ {")
        lines.append("        fastcgi_pass unix:%s;" % socket_path)
        lines.append("        fastcgi_index index.php;")
        lines.append("        include fastcgi_params;")
        lines.append("        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;")
        lines.append("    }")
    elif site['site_type'] == 'python':
        port = site.get('port') or 8000
        lines.append("    location / {")
        lines.append(f"        proxy_pass http://127.0.0.1:{port};")
        lines.append("        proxy_set_header Host $host;")
        lines.append("        proxy_set_header X-Real-IP $remote_addr;")
        lines.append("        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;")
        lines.append("        proxy_set_header X-Forwarded-Proto $scheme;")
        lines.append("    }")
    lines.append("}")
    return "\n".join(lines)


def nginx_site_path(domain):
    fname = utils.safe_filename(domain) + '.conf'
    return os.path.join(nginx_conf_dir(), fname)


def apply_nginx():
    """写入配置后重载 nginx"""
    os.makedirs(nginx_conf_dir(), exist_ok=True)
    code, out, err = utils.run_cmd(f"{config.NGINX_BIN} -t 2>&1")
    if code != 0:
        return False, f"Nginx 配置测试失败: {err or out}"
    code, out, err = utils.run_cmd("systemctl reload nginx 2>/dev/null || nginx -s reload 2>/dev/null || service nginx reload")
    if code != 0:
        # 非 systemd 环境
        code, out, err = utils.run_cmd("nginx -s reload")
    return code == 0, err or out


def systemd_unit_name(domain):
    return f"xpanel-{utils.safe_filename(domain)}.service"


def systemd_dir():
    d = os.environ.get('XPANEL_SYSTEMD_DIR', '/etc/systemd/system')
    os.makedirs(d, exist_ok=True)
    return d


def python_service_conf(site, py_bin, app_module):
    """为 Python 站点生成 systemd 单元"""
    domain = site['domain']
    name = systemd_unit_name(domain)
    root = site['root_path']
    venv = os.path.join(root, '.venv')
    gunicorn = os.path.join(venv, 'bin', 'gunicorn')
    unit = f"""[Unit]
Description=XPanel Python Site {domain}
After=network.target

[Service]
Type=simple
WorkingDirectory={root}
ExecStart={gunicorn} -b 127.0.0.1:{site['port']} -w 2 --access-logfile - {app_module}
Restart=always
RestartSec=3
User=www-data
Group=www-data
Environment=PATH={venv}/bin:/usr/local/bin:/usr/bin

[Install]
WantedBy=multi-user.target
"""
    return name, unit


# ---------- API ----------
@bp.get('/api/sites')
@login_required
def list_sites():
    rows = db.fetchall("SELECT * FROM sites ORDER BY id DESC")
    for r in rows:
        r['php_versions'] = [s['version'] for s in detect_php_sockets()]
        r['config_exists'] = os.path.exists(nginx_site_path(r['domain']))
    return jsonify({'ok': True, 'data': rows})


@bp.post('/api/sites')
@login_required
def create_site():
    data = request.get_json(silent=True) or {}
    name = (data.get('name') or '').strip()
    domain = (data.get('domain') or '').strip()
    site_type = data.get('site_type') or 'php'
    php_version = data.get('php_version') or '8.1'

    if not name or not domain:
        return jsonify({'ok': False, 'msg': '站点名称和域名不能为空'})
    if not utils.valid_domain(domain):
        return jsonify({'ok': False, 'msg': '域名格式不正确'})
    if db.fetchone("SELECT id FROM sites WHERE domain=?", (domain,)):
        return jsonify({'ok': False, 'msg': '该域名已存在'})

    root = utils.ensure_root_path(domain)
    port = 0
    if site_type == 'python':
        port = int(data.get('port') or 0)
        if not utils.valid_port(port):
            return jsonify({'ok': False, 'msg': 'Python 站点需要合法的内部端口'})
        if db.fetchone("SELECT id FROM sites WHERE port=?", (port,)):
            return jsonify({'ok': False, 'msg': f'端口 {port} 已被其他站点占用'})

    site_id = db.execute(
        "INSERT INTO sites(name,domain,site_type,php_version,root_path,port,frame) "
        "VALUES(?,?,?,?,?,?,?)",
        (name, domain, site_type, php_version, root, port,
         data.get('frame') or 'flask'))

    site = db.fetchone("SELECT * FROM sites WHERE id=?", (site_id,))

    # 创建目录
    os.makedirs(root, exist_ok=True)
    if site_type == 'static':
        utils.write_file(os.path.join(root, 'index.html'),
                         f"<h1>Welcome to {domain}</h1>\n<p>XPanel 静态站点已就绪。</p>\n")
    elif site_type == 'php':
        utils.write_file(os.path.join(root, 'index.php'),
                         "<?php echo '<h1>Hello, XPanel PHP!</h1><p>PHP 站点已就绪</p>'; ?>\n")
    elif site_type == 'python':
        init_python_site(site)

    # 写入 Nginx 配置
    write_site_nginx(site)
    ok, msg = apply_nginx()
    return jsonify({'ok': True, 'msg': ('站点创建成功' if ok else f'站点已创建，但 Nginx 重载失败: {msg}'),
                    'id': site_id, 'nginx_ok': ok})


def write_site_nginx(site):
    conf = nginx_conf_for(site)
    utils.write_file(nginx_site_path(site['domain']), conf)


def init_python_site(site):
    """初始化 Python 站点：venv + gunicorn + 示例应用 + systemd"""
    root = site['root_path']
    os.makedirs(root, exist_ok=True)
    frame = site.get('frame') or 'flask'
    venv = os.path.join(root, '.venv')
    app_module = 'app:app'
    if frame == 'fastapi':
        app_module = 'main:app'

    # 示例应用
    if frame == 'flask':
        utils.write_file(os.path.join(root, 'app.py'), _flask_sample(site['domain']))
    else:
        utils.write_file(os.path.join(root, 'main.py'), _fastapi_sample(site['domain']))
    utils.write_file(os.path.join(root, 'requirements.txt'), _req_text(frame))

    # 创建 venv 并安装依赖
    py = utils.which('python3') or 'python3'
    if not os.path.exists(os.path.join(venv, 'bin', 'python')):
        utils.run_cmd(f"{py} -m venv {venv}", timeout=120)
    utils.run_cmd(f"{venv}/bin/pip install --upgrade pip -q", timeout=180)
    utils.run_cmd(f"{venv}/bin/pip install -r {os.path.join(root, 'requirements.txt')} -q", timeout=300)

    # systemd 服务
    name, unit = python_service_conf(site, py, app_module)
    utils.write_file(os.path.join(systemd_dir(), name), unit)
    utils.run_cmd("systemctl daemon-reload 2>/dev/null")
    utils.run_cmd(f"systemctl enable {name} 2>/dev/null")
    utils.run_cmd(f"systemctl start {name} 2>/dev/null")


def _flask_sample(domain):
    return f'''from flask import Flask
app = Flask(__name__)

@app.route("/")
def index():
    return f"<h1>Hello, {domain}</h1><p>XPanel Python (Flask) 站点运行中。</p>"

if __name__ == "__main__":
    app.run()
'''


def _fastapi_sample(domain):
    return f'''from fastapi import FastAPI
app = FastAPI(title="{domain}")

@app.get("/")
def index():
    return {{"msg": f"Hello, {domain}", "powered": "XPanel"}}
'''


def _req_text(frame):
    if frame == 'fastapi':
        return "fastapi\nuvicorn\ngunicorn\n"
    return "flask\ngunicorn\n"


@bp.delete('/api/sites/<int:site_id>')
@login_required
def delete_site(site_id):
    site = db.fetchone("SELECT * FROM sites WHERE id=?", (site_id,))
    if not site:
        return jsonify({'ok': False, 'msg': '站点不存在'})
    # 删除 Nginx 配置
    p = nginx_site_path(site['domain'])
    if os.path.exists(p):
        os.remove(p)
    # 停止 python 服务
    if site['site_type'] == 'python':
        utils.run_cmd(f"systemctl stop {systemd_unit_name(site['domain'])} 2>/dev/null")
        utils.run_cmd(f"systemctl disable {systemd_unit_name(site['domain'])} 2>/dev/null")
        utils.run_cmd(f"rm -f {os.path.join(systemd_dir(), systemd_unit_name(site['domain']))}")
        utils.run_cmd("systemctl daemon-reload 2>/dev/null")
    db.execute("DELETE FROM sites WHERE id=?", (site_id,))
    apply_nginx()
    return jsonify({'ok': True, 'msg': '站点已删除（网站文件已保留）'})


@bp.post('/api/sites/<int:site_id>/toggle')
@login_required
def toggle_site(site_id):
    site = db.fetchone("SELECT * FROM sites WHERE id=?", (site_id,))
    if not site:
        return jsonify({'ok': False, 'msg': '站点不存在'})
    enabled = 1 - site['enabled']
    db.execute("UPDATE sites SET enabled=? WHERE id=?", (enabled, site_id))
    if site['site_type'] == 'python':
        svc = systemd_unit_name(site['domain'])
        utils.run_cmd(f"systemctl {'start' if enabled else 'stop'} {svc} 2>/dev/null")
    # 改 Nginx 配置（enabled=0 时注释 server）
    return jsonify({'ok': True, 'msg': '已启用' if enabled else '已停用'})


@bp.get('/api/sites/<int:site_id>/config')
@login_required
def site_config(site_id):
    site = db.fetchone("SELECT * FROM sites WHERE id=?", (site_id,))
    if not site:
        return jsonify({'ok': False, 'msg': '站点不存在'})
    conf_path = nginx_site_path(site['domain'])
    nginx_conf = utils.read_file(conf_path)
    php_versions = [s['version'] for s in detect_php_sockets()]
    return jsonify({'ok': True, 'data': {
        'site': site, 'nginx_conf': nginx_conf,
        'php_versions': php_versions,
        'root_path': site['root_path'],
    }})


@bp.post('/api/sites/<int:site_id>/apply_nginx')
@login_required
def site_apply_nginx(site_id):
    site = db.fetchone("SELECT * FROM sites WHERE id=?", (site_id,))
    if not site:
        return jsonify({'ok': False, 'msg': '站点不存在'})
    write_site_nginx(site)
    ok, msg = apply_nginx()
    return jsonify({'ok': ok, 'msg': 'Nginx 已重载' if ok else f'重载失败: {msg}'})


@bp.get('/api/sites/files')
@login_required
def site_files():
    path = request.args.get('path') or ''
    root = request.args.get('root') or ''
    # 安全限制：只允许读取站点目录
    if root and not path:
        full = root
    elif root:
        full = os.path.join(root, path)
    else:
        full = path
    full = os.path.realpath(full)
    if root and not full.startswith(os.path.realpath(root)):
        return jsonify({'ok': False, 'msg': '路径越界'})
    if not os.path.isdir(full):
        return jsonify({'ok': False, 'msg': '目录不存在'})
    entries = []
    try:
        for name in sorted(os.listdir(full)):
            p = os.path.join(full, name)
            st = os.stat(p)
            entries.append({
                'name': name,
                'is_dir': os.path.isdir(p),
                'size': st.st_size,
                'mtime': st.st_mtime,
            })
    except PermissionError:
        return jsonify({'ok': False, 'msg': '无权限访问该目录'})
    return jsonify({'ok': True, 'data': {
        'path': full, 'entries': entries,
    }})


@bp.get('/api/sites/file_content')
@login_required
def site_file_content():
    path = request.args.get('path') or ''
    root = request.args.get('root') or ''
    if root:
        full = os.path.realpath(os.path.join(root, path))
        if not full.startswith(os.path.realpath(root)):
            return jsonify({'ok': False, 'msg': '路径越界'})
    else:
        full = path
    if not os.path.isfile(full):
        return jsonify({'ok': False, 'msg': '文件不存在'})
    return jsonify({'ok': True, 'data': {
        'path': full,
        'content': utils.read_file(full),
    }})
