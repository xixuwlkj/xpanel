# -*- coding: utf-8 -*-
"""
XPanel 希旭面板 - 节点管理
支持 vmess / vless / trojan 协议，生成 Xray 配置与客户端分享链接
"""
import base64
import json
import os
import time
from flask import Blueprint, request, jsonify

from . import config, db, utils
from .auth import login_required

bp = Blueprint('nodes', __name__)


# ---------- 核心安装 ----------
def xray_installed():
    return os.path.exists(config.XRAY_BIN) and os.access(config.XRAY_BIN, os.X_OK)


def xray_running():
    code, out, _ = utils.run_cmd("pgrep -x xray >/dev/null && echo RUN || echo STOP")
    return 'RUN' in out


def install_xray():
    """一键安装 Xray 核心（官方安装脚本）"""
    if xray_installed():
        return True, 'Xray 已安装'
    # 官方安装脚本（无需交互）
    code, out, err = utils.run_cmd(
        "bash -c '$(curl -Ls https://github.com/XTLS/Xray-install/raw/main/install-release.sh)' @ install",
        timeout=300)
    if xray_installed():
        return True, 'Xray 安装成功'
    return False, f"安装失败: {err or out}"


def get_public_ip():
    for url in ('https://api.ipify.org', 'https://ifconfig.me/ip',
                'https://ipinfo.io/ip'):
        code, out, _ = utils.run_cmd(f"curl -s --max-time 5 {url}")
        if code == 0 and out and '.' in out:
            return out.strip()
    return '127.0.0.1'


# ---------- 配置生成 ----------
def build_inbound(node):
    inbound = {
        "tag": f"in-{node['name']}",
        "port": node['port'],
        "protocol": node['protocol'],
        "settings": {},
        "streamSettings": {
            "network": node['network'] or 'tcp',
            "security": "tls" if node['tls'] else "none",
        },
    }
    if node['protocol'] == 'vmess':
        inbound['settings']['clients'] = [{
            "id": node['uuid'],
            "alterId": node['alter_id'] or 0,
        }]
    elif node['protocol'] == 'vless':
        inbound['settings']['clients'] = [{"id": node['uuid']}]
        inbound['settings']['decryption'] = 'none'
    elif node['protocol'] == 'trojan':
        inbound['settings']['clients'] = [{"password": node['uuid']}]
        inbound['settings']['decryption'] = 'none'
        inbound['streamSettings']['security'] = 'tls'

    if node['network'] == 'ws':
        inbound['streamSettings']['wsSettings'] = {
            "path": node['path'] or '/',
            "headers": {"Host": node['host']} if node['host'] else {},
        }
    elif node['network'] == 'grpc':
        inbound['streamSettings']['grpcSettings'] = {
            "serviceName": node['path'] or '',
        }

    if node['tls']:
        cert = node.get('cert_path') or '/etc/xray/tls.crt'
        key = node.get('key_path') or '/etc/xray/tls.key'
        inbound['streamSettings']['tlsSettings'] = {
            "certificates": [{"certificateFile": cert, "keyFile": key}]
        }
    return inbound


def build_xray_config(nodes):
    cfg = {
        "log": {"loglevel": "warning"},
        "inbounds": [build_inbound(n) for n in nodes],
        "outbounds": [
            {"protocol": "freedom", "tag": "direct"},
            {"protocol": "blackhole", "tag": "block"}
        ],
        "routing": {
            "domainStrategy": "IPIfNonMatch",
            "rules": [
                {"type": "field", "protocol": ["bittorrent"], "outboundTag": "block"}
            ]
        }
    }
    return cfg


def write_xray_config(nodes):
    cfg = build_xray_config(nodes)
    utils.save_json(os.path.join(config.XRAY_CONF_DIR, 'config.json'), cfg)
    return cfg


# ---------- 分享链接 ----------
def vmess_link(node, server_ip):
    payload = {
        "v": "2",
        "ps": node['name'],
        "add": server_ip,
        "port": str(node['port']),
        "id": node['uuid'],
        "aid": str(node['alter_id'] or 0),
        "scy": node['encryption'] or 'auto',
        "net": node['network'] or 'tcp',
        "type": "none",
        "host": node['host'] or '',
        "path": node['path'] or '',
        "tls": "tls" if node['tls'] else "",
    }
    raw = json.dumps(payload, ensure_ascii=False)
    b64 = base64.b64encode(raw.encode()).decode()
    return f"vmess://{b64}"


def vless_link(node, server_ip):
    params = [f"type={node['network'] or 'tcp'}",
              f"encryption=none",
              f"security={'tls' if node['tls'] else 'none'}"]
    if node['network'] == 'ws':
        params.append(f"path={node['path'] or '/'}")
        if node['host']:
            params.append(f"host={node['host']}")
    if node['tls']:
        params.append(f"sni={node['host'] or ''}")
    q = '&'.join(params)
    return f"vless://{node['uuid']}@{server_ip}:{node['port']}?{q}#{node['name']}"


def trojan_link(node, server_ip):
    params = [f"security={'tls' if node['tls'] else 'none'}"]
    if node['network'] == 'ws':
        params.append(f"type=ws&path={node['path'] or '/'}")
    q = '&'.join(params)
    return f"trojan://{node['uuid']}@{server_ip}:{node['port']}?{q}#{node['name']}"


def share_link(node, server_ip):
    if node['protocol'] == 'vmess':
        return vmess_link(node, server_ip)
    if node['protocol'] == 'vless':
        return vless_link(node, server_ip)
    return trojan_link(node, server_ip)


# ---------- API ----------
@bp.get('/api/nodes/status')
@login_required
def core_status():
    return jsonify({'ok': True, 'data': {
        'installed': xray_installed(),
        'running': xray_running(),
        'version': utils.read_file('/usr/local/share/xray/version.txt').strip()
        if os.path.exists('/usr/local/share/xray/version.txt') else '',
    }})


@bp.post('/api/nodes/install')
@login_required
def core_install():
    if not utils.which('curl'):
        utils.run_cmd("apt-get install -y curl 2>/dev/null || yum install -y curl 2>/dev/null", timeout=180)
    ok, msg = install_xray()
    if ok:
        os.makedirs(config.XRAY_CONF_DIR, exist_ok=True)
        apply_all_nodes()
        utils.run_cmd("systemctl restart xray 2>/dev/null || systemctl start xray 2>/dev/null")
    return jsonify({'ok': ok, 'msg': msg})


def apply_all_nodes():
    """把全部启用的节点写进 Xray 配置"""
    if not xray_installed():
        return
    nodes = db.fetchall("SELECT * FROM nodes WHERE enabled=1")
    write_xray_config(nodes)


@bp.post('/api/nodes/reload')
@login_required
def core_reload():
    apply_all_nodes()
    code, out, err = utils.run_cmd(
        "systemctl restart xray 2>/dev/null || (pgrep -x xray && kill -HUP $(pgrep -x xray | head -1))")
    return jsonify({'ok': code == 0 or xray_running(), 'msg': '已重载节点配置'})


@bp.get('/api/nodes')
@login_required
def list_nodes():
    nodes = db.fetchall("SELECT * FROM nodes ORDER BY id DESC")
    server_ip = get_public_ip()
    for n in nodes:
        n['share_link'] = share_link(n, server_ip)
        n['server_ip'] = server_ip
        n['running'] = xray_running()
    return jsonify({'ok': True, 'data': nodes,
                    'installed': xray_installed(),
                    'running': xray_running()})


@bp.post('/api/nodes')
@login_required
def create_node():
    data = request.get_json(silent=True) or {}
    name = (data.get('name') or '').strip()
    protocol = data.get('protocol') or 'vmess'
    port = data.get('port')
    if not name:
        return jsonify({'ok': False, 'msg': '节点名称不能为空'})
    if not utils.valid_port(port):
        return jsonify({'ok': False, 'msg': '端口不合法'})
    if db.fetchone("SELECT id FROM nodes WHERE port=?", (port,)):
        return jsonify({'ok': False, 'msg': f'端口 {port} 已被其他节点占用'})

    node_id = db.execute(
        "INSERT INTO nodes(name,protocol,uuid,port,alter_id,encryption,"
        "network,path,host,tls) VALUES(?,?,?,?,?,?,?,?,?,?)",
        (name, protocol, data.get('uuid') or utils.gen_uuid(), int(port),
         int(data.get('alter_id') or 0), data.get('encryption') or 'auto',
         data.get('network') or 'tcp', data.get('path') or '',
         data.get('host') or '', 1 if data.get('tls') else 0))
    apply_all_nodes()
    if xray_running():
        utils.run_cmd("systemctl restart xray 2>/dev/null || kill -HUP $(pgrep -x xray | head -1)")
    return jsonify({'ok': True, 'msg': '节点创建成功', 'id': node_id})


@bp.delete('/api/nodes/<int:node_id>')
@login_required
def delete_node(node_id):
    node = db.fetchone("SELECT * FROM nodes WHERE id=?", (node_id,))
    if not node:
        return jsonify({'ok': False, 'msg': '节点不存在'})
    db.execute("DELETE FROM nodes WHERE id=?", (node_id,))
    apply_all_nodes()
    if xray_running():
        utils.run_cmd("systemctl restart xray 2>/dev/null || kill -HUP $(pgrep -x xray | head -1)")
    return jsonify({'ok': True, 'msg': '节点已删除'})


@bp.post('/api/nodes/<int:node_id>/toggle')
@login_required
def toggle_node(node_id):
    node = db.fetchone("SELECT * FROM nodes WHERE id=?", (node_id,))
    if not node:
        return jsonify({'ok': False, 'msg': '节点不存在'})
    enabled = 1 - node['enabled']
    db.execute("UPDATE nodes SET enabled=? WHERE id=?", (enabled, node_id))
    apply_all_nodes()
    if xray_running():
        utils.run_cmd("systemctl restart xray 2>/dev/null || kill -HUP $(pgrep -x xray | head -1)")
    return jsonify({'ok': True, 'msg': '已启用' if enabled else '已停用'})


@bp.post('/api/nodes/<int:node_id>/service')
@login_required
def node_service(node_id):
    """start/stop/restart xray"""
    action = (request.get_json(silent=True) or {}).get('action') or 'restart'
    apply_all_nodes()
    code, out, err = utils.run_cmd(f"systemctl {action} xray 2>/dev/null || service xray {action} 2>/dev/null")
    return jsonify({'ok': code == 0 or xray_running(),
                    'msg': f'Xray 已{action}', 'running': xray_running()})


@bp.get('/api/nodes/<int:node_id>')
@login_required
def node_detail(node_id):
    node = db.fetchone("SELECT * FROM nodes WHERE id=?", (node_id,))
    if not node:
        return jsonify({'ok': False, 'msg': '节点不存在'})
    server_ip = get_public_ip()
    node['share_link'] = share_link(node, server_ip)
    node['server_ip'] = server_ip
    cfg = build_inbound(node)
    return jsonify({'ok': True, 'data': {
        'node': node,
        'share_link': node['share_link'],
        'json': json.dumps(cfg, ensure_ascii=False, indent=2),
    }})
