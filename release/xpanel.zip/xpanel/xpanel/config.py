# -*- coding: utf-8 -*-
"""
XPanel 希旭面板 - 全局配置
"""
import json
import os

# 面板根目录（项目所在目录的上一级）
PANEL_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# 数据目录（数据库、日志、运行时配置）
DATA_DIR = os.path.join(PANEL_ROOT, 'data')
STATIC_DIR = os.path.join(PANEL_ROOT, 'static')
TPL_DIR = os.path.join(PANEL_ROOT, 'templates')

DB_PATH = os.path.join(DATA_DIR, 'panel.db')
LOG_PATH = os.path.join(DATA_DIR, 'panel.log')
CONFIG_JSON = os.path.join(DATA_DIR, 'panel.json')


def _load_panel_json():
    try:
        with open(CONFIG_JSON, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


_panel_json = _load_panel_json()


def panel_setting(key, default=None):
    """从 data/panel.json 读取自定义配置（安装脚本写入的运行时配置）"""
    return _panel_json.get(key, default)


# 面板默认监听
PANEL_HOST = '0.0.0.0'
PANEL_PORT = int(os.environ.get('XPANEL_PORT',
                                panel_setting('port', 8888)))

# 网站根目录（宝塔风格：/www/wwwroot）
WWW_ROOT = os.environ.get('XPANEL_WWW_ROOT',
                          panel_setting('www_root', '/www/wwwroot'))
NGINX_CONF_DIR = os.environ.get('XPANEL_NGINX_CONF_DIR',
                                '/www/server/nginx/conf/vhost')
NGINX_BIN = os.environ.get('XPANEL_NGINX_BIN', 'nginx')
PHP_CONF_DIR = os.environ.get('XPANEL_PHP_CONF_DIR', '/www/server/php')

# Xray 节点相关
XRAY_BIN = os.environ.get('XPANEL_XRAY_BIN', '/usr/local/bin/xray')
XRAY_CONF_DIR = os.environ.get('XPANEL_XRAY_CONF_DIR', '/usr/local/etc/xray')
XRAY_SERVICE = 'xray'

# 邮箱相关
POSTFIX_MAIN_CF = os.environ.get('XPANEL_POSTFIX_MAIN_CF', '/etc/postfix/main.cf')
POSTFIX_VIRTUAL = os.environ.get('XPANEL_POSTFIX_VIRTUAL', '/etc/postfix/virtual')
POSTFIX_TRANSPORT = os.environ.get('XPANEL_POSTFIX_TRANSPORT', '/etc/postfix/transport')
DOVECOT_CONF_DIR = os.environ.get('XPANEL_DOVECOT_CONF_DIR', '/etc/dovecot/conf.d')
MAIL_ROOT = os.environ.get('XPANEL_MAIL_ROOT',
                           panel_setting('mail_root', '/var/mail/vhosts'))  # 独立邮箱 Maildir 根目录

# 管理员默认账号（安装脚本会写入随机密码到 data/panel.json）
DEFAULT_ADMIN = panel_setting('admin_user', os.environ.get('XPANEL_ADMIN_USER', 'admin'))
DEFAULT_PASSWORD = panel_setting('admin_password',
                                 os.environ.get('XPANEL_ADMIN_PASS', 'xpanel888'))

# 登录 token 有效期（秒）
TOKEN_TTL = 12 * 3600


def ensure_dirs():
    for d in (DATA_DIR, STATIC_DIR, TPL_DIR):
        os.makedirs(d, exist_ok=True)
    os.makedirs(os.path.join(DATA_DIR, 'logs'), exist_ok=True)
