# -*- coding: utf-8 -*-
"""
XPanel 希旭面板 - 系统监控
"""
import os
import time
from flask import Blueprint, jsonify
import psutil

from . import config, utils
from .auth import login_required

bp = Blueprint('system', __name__)


def _net_io():
    try:
        c = psutil.net_io_counters()
        return c.bytes_sent, c.bytes_recv
    except Exception:
        return 0, 0


_net_prev = {'ts': time.time(), 'up': 0, 'down': 0}


def net_speed():
    up, down = _net_io()
    now = time.time()
    dt = now - _net_prev['ts']
    if dt <= 0:
        dt = 1
    up_speed = max(0, (up - _net_prev['up'])) / dt
    down_speed = max(0, (down - _net_prev['down'])) / dt
    _net_prev.update(ts=now, up=up, down=down)
    return up_speed, down_speed


def _fmt_bytes(n):
    n = float(n)
    for unit in ('B', 'KB', 'MB', 'GB', 'TB'):
        if n < 1024 or unit == 'TB':
            return f"{n:.2f} {unit}"
        n /= 1024


def service_status():
    """探测关键服务运行状态"""
    services = [
        ('nginx', 'Nginx', '网站服务'),
        ('php-fpm', 'PHP-FPM', 'PHP 服务'),
        ('xray', 'Xray', '节点服务'),
        ('postfix', 'Postfix', '邮件发送'),
        ('dovecot', 'Dovecot', '邮件投递'),
    ]
    out = []
    for bin_name, display, desc in services:
        if not utils.which(bin_name):
            out.append({'key': bin_name, 'name': display, 'desc': desc,
                        'installed': False, 'running': False})
            continue
        code, _, _ = utils.run_cmd(f"pgrep -x {bin_name} >/dev/null && echo RUN || echo STOP")
        running = 'RUN' in _
        out.append({'key': bin_name, 'name': display, 'desc': desc,
                    'installed': True, 'running': running})
    # 面板自身
    out.append({'key': 'xpanel', 'name': 'XPanel', 'desc': '面板服务',
                'installed': True, 'running': True})
    return out


@bp.get('/api/system/overview')
@login_required
def overview():
    load1, load5, load15 = (os.getloadavg() if hasattr(os, 'getloadavg')
                            else (0, 0, 0))
    vm = psutil.virtual_memory()
    disk_path = config.WWW_ROOT if os.path.exists(config.WWW_ROOT) else '/'
    disk = psutil.disk_usage(disk_path)
    # 找挂载点
    mount = disk_path
    for part in psutil.disk_partitions():
        if part.mountpoint == disk_path or disk_path.startswith(part.mountpoint + os.sep):
            mount = part.mountpoint
            break
    up, down = net_speed()
    boot = psutil.boot_time()
    return jsonify({
        'ok': True,
        'data': {
            'cpu_percent': psutil.cpu_percent(interval=None),
            'cpu_count': psutil.cpu_count(),
            'load': [round(load1, 2), round(load5, 2), round(load15, 2)],
            'mem': {'total': vm.total, 'used': vm.used, 'percent': vm.percent,
                    'free': vm.available},
            'disk': {'total': disk.total, 'used': disk.used,
                     'percent': disk.percent, 'free': disk.free,
                     'mount': mount},
            'net': {'up': _fmt_bytes(up), 'down': _fmt_bytes(down)},
            'uptime': int(time.time() - boot),
            'hostname': os.uname().nodename,
            'os': f"{os.uname().sysname} {os.uname().release}",
            'python': os.sys.version.split()[0],
        }
    })


@bp.get('/api/system/cpu_history')
@login_required
def cpu_history():
    """采集一段时间 CPU/内存采样用于画图"""
    fast = os.environ.get('XPANEL_FAST_SAMPLE') == '1'
    samples = 24 if fast else 30
    interval = 0.15 if fast else 0.3
    data = []
    # 用瞬时采样 + 手动 sleep 实现间隔采样（interval 模式在部分容器会阻塞）
    psutil.cpu_percent(interval=None)  # 初始化基准
    for i in range(samples):
        time.sleep(interval)
        data.append({
            'cpu': psutil.cpu_percent(interval=None),
            'mem': psutil.virtual_memory().percent,
        })
    return jsonify({'ok': True, 'data': data})


@bp.get('/api/system/net_history')
@login_required
def net_history():
    samples = []
    for _ in range(20):
        up, down = net_speed()
        samples.append({'up': round(up / 1024, 1), 'down': round(down / 1024, 1)})
        time.sleep(0.25)
    return jsonify({'ok': True, 'data': samples})


@bp.get('/api/system/services')
@login_required
def services():
    return jsonify({'ok': True, 'data': service_status()})


@bp.get('/api/system/processes')
@login_required
def processes():
    rows = []
    for p in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent']):
        try:
            info = p.info
            rows.append({
                'pid': info['pid'], 'name': info['name'],
                'cpu': round(info['cpu_percent'] or 0, 1),
                'mem': round(info['memory_percent'] or 0, 1),
            })
        except Exception:
            continue
    rows.sort(key=lambda x: -x['cpu'])
    return jsonify({'ok': True, 'data': rows[:30]})
