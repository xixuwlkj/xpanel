# -*- coding: utf-8 -*-
"""
XPanel 希旭面板 - 文件管理
浏览 / 上传 / 编辑 / 新建 / 重命名 / 删除 / 下载
"""
import os
import shutil
import time
from flask import Blueprint, request, jsonify, send_file
from . import utils
from .auth import login_required

bp = Blueprint('files', __name__)

_SIZE_UNITS = ['B', 'KB', 'MB', 'GB', 'TB']


def fmt_size(n):
    try:
        f = float(n)
    except Exception:
        return '0B'
    u = 0
    while f >= 1024 and u < len(_SIZE_UNITS) - 1:
        f /= 1024
        u += 1
    return f"{f:.1f}{_SIZE_UNITS[u]}" if u else f"{int(f)}B"


def entry(p):
    st = os.stat(p)
    isdir = os.path.isdir(p)
    return {
        'name': os.path.basename(p.rstrip('/')) or '/',
        'path': p,
        'is_dir': isdir,
        'size': 0 if isdir else st.st_size,
        'size_txt': '' if isdir else fmt_size(st.st_size),
        'mtime': time.strftime('%Y-%m-%d %H:%M', time.localtime(st.st_mtime)),
        'perm': oct(st.st_mode & 0o777),
    }


@bp.get('/api/files/list')
@login_required
def flist():
    path = os.path.realpath(request.args.get('path') or '/')
    if not os.path.isdir(path):
        return jsonify({'ok': False, 'msg': '目录不存在'})
    try:
        names = sorted(os.listdir(path),
                       key=lambda x: (os.path.isdir(os.path.join(path, x)) is False,
                                      x.lower()))
        entries = [entry(os.path.join(path, n)) for n in names]
    except PermissionError:
        return jsonify({'ok': False, 'msg': '无权限访问该目录'})
    parent = os.path.dirname(path.rstrip('/')) if path != '/' else ''
    disk = shutil.disk_usage(path)
    return jsonify({'ok': True, 'data': {
        'path': path, 'parent': parent, 'entries': entries,
        'disk_total': disk.total, 'disk_used': disk.used, 'disk_free': disk.free,
    }})


@bp.get('/api/files/content')
@login_required
def fcontent():
    path = os.path.realpath(request.args.get('path') or '')
    if not os.path.isfile(path):
        return jsonify({'ok': False, 'msg': '文件不存在'})
    if os.path.getsize(path) > 2 * 1024 * 1024:
        return jsonify({'ok': False, 'msg': '文件超过 2MB，请下载后在本地编辑'})
    return jsonify({'ok': True, 'data': {
        'path': path, 'content': utils.read_file(path)}})


@bp.post('/api/files/write')
@login_required
def fwrite():
    d = request.get_json(silent=True) or {}
    path = os.path.realpath(d.get('path') or '')
    if not path:
        return jsonify({'ok': False, 'msg': '路径不能为空'})
    utils.write_file(path, d.get('content') or '')
    return jsonify({'ok': True, 'msg': '已保存'})


@bp.post('/api/files/upload')
@login_required
def fupload():
    path = os.path.realpath(request.form.get('path') or '/')
    f = request.files.get('file')
    if not f:
        return jsonify({'ok': False, 'msg': '未选择文件'})
    f.save(os.path.join(path, os.path.basename(f.filename or 'file')))
    return jsonify({'ok': True, 'msg': f'已上传 {f.filename}'})


@bp.post('/api/files/mkdir')
@login_required
def fmkdir():
    d = request.get_json(silent=True) or {}
    path = os.path.realpath(d.get('path') or '')
    name = (d.get('name') or '').strip()
    if not name or '/' in name or '..' in name:
        return jsonify({'ok': False, 'msg': '名称不合法'})
    os.makedirs(os.path.join(path, name), exist_ok=True)
    return jsonify({'ok': True, 'msg': '目录已创建'})


@bp.post('/api/files/create')
@login_required
def fcreate():
    d = request.get_json(silent=True) or {}
    path = os.path.realpath(d.get('path') or '')
    name = (d.get('name') or '').strip()
    if not name or '/' in name or '..' in name:
        return jsonify({'ok': False, 'msg': '名称不合法'})
    utils.write_file(os.path.join(path, name), '')
    return jsonify({'ok': True, 'msg': '文件已创建'})


@bp.post('/api/files/rename')
@login_required
def frename():
    d = request.get_json(silent=True) or {}
    path = os.path.realpath(d.get('path') or '')
    new = (d.get('new_name') or '').strip()
    if not new or '/' in new or '..' in new:
        return jsonify({'ok': False, 'msg': '新名称不合法'})
    try:
        os.rename(path, os.path.join(os.path.dirname(path), new))
    except Exception as e:
        return jsonify({'ok': False, 'msg': f'重命名失败: {e}'})
    return jsonify({'ok': True, 'msg': '已重命名'})


@bp.delete('/api/files')
@login_required
def fdelete():
    path = os.path.realpath(request.args.get('path') or '')
    if not os.path.exists(path):
        return jsonify({'ok': False, 'msg': '路径不存在'})
    # 保护：不允许删除面板自身数据目录
    from . import config
    if path == os.path.realpath(config.DATA_DIR) or path == os.path.realpath(config.PANEL_ROOT):
        return jsonify({'ok': False, 'msg': '该路径受保护，不能删除'})
    try:
        if os.path.isdir(path):
            shutil.rmtree(path)
        else:
            os.remove(path)
    except Exception as e:
        return jsonify({'ok': False, 'msg': f'删除失败: {e}'})
    return jsonify({'ok': True, 'msg': '已删除'})


@bp.get('/api/files/download')
@login_required
def fdownload():
    path = os.path.realpath(request.args.get('path') or '')
    if not os.path.isfile(path):
        return jsonify({'ok': False, 'msg': '文件不存在'})
    return send_file(path, as_attachment=True,
                     download_name=os.path.basename(path))
