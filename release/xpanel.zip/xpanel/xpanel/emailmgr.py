# -*- coding: utf-8 -*-
"""
XPanel 希旭面板 - 邮箱管理
两种模式：
  forward   邮箱转发：配置域名 + 收件邮箱，创建前缀，前缀@域名 转发到收件邮箱
  standalone 独立邮箱：配置域名 + 生成网页邮箱(Webmail)，可创建任意前缀账号，在线收发
底层使用 Postfix（收/发）+ Dovecot（投递/认证）+ Maildir 存储
"""
import os
import re
import time
from flask import Blueprint, request, jsonify

from . import config, db, utils
from .auth import login_required

bp = Blueprint('email', __name__)


# ---------- 路径 ----------
def domain_maildir(domain, prefix):
    return os.path.join(config.MAIL_ROOT, utils.safe_filename(domain),
                        utils.safe_filename(prefix), 'Maildir')


def postfix_virtual_file():
    return config.POSTFIX_VIRTUAL


def postfix_vmailbox_file():
    return os.environ.get('XPANEL_POSTFIX_VMAILBOX',
                          '/etc/postfix/vmailbox')


def dovecot_passwd_file():
    return os.environ.get('XPANEL_DOVECOT_PASSWD',
                          '/etc/dovecot/dovecot-passwd')


# ---------- 服务探测 ----------
def services_ready():
    return {
        'postfix': bool(utils.which('postfix')),
        'dovecot': bool(utils.which('dovecot')),
    }


def ensure_postfix_dovecot():
    """按需安装 postfix + dovecot（Debian/Ubuntu）"""
    miss = []
    if not utils.which('postfix'):
        miss.append('postfix')
    if not utils.which('dovecot'):
        miss.append('dovecot')
    if not miss:
        return True, '已安装'
    cmd = f"DEBIAN_FRONTEND=noninteractive apt-get install -y {' '.join(miss)}"
    code, out, err = utils.run_cmd(cmd, timeout=600)
    if utils.which('postfix') and utils.which('dovecot'):
        return True, '安装完成'
    return False, err or out


# ---------- 配置生成 ----------
def build_virtual_maps():
    """生成 /etc/postfix/virtual（转发别名）"""
    lines = ["# 由 XPanel 自动生成 - 转发别名", ""]
    domains = db.fetchall("SELECT * FROM email_domains WHERE mode='forward' AND enabled=1")
    for d in domains:
        accts = db.fetchall(
            "SELECT * FROM email_accounts WHERE domain_id=? AND account_type='alias' AND enabled=1",
            (d['id'],))
        for a in accts:
            target = a['target'] or d['forward_target']
            if target:
                lines.append(f"{a['prefix']}@{d['domain']}\t{target}")
    return "\n".join(lines) + "\n"


def build_vmailbox_maps():
    """生成 /etc/postfix/vmailbox（独立邮箱账号映射）"""
    lines = ["# 由 XPanel 自动生成 - 独立邮箱", ""]
    domains = db.fetchall("SELECT * FROM email_domains WHERE mode='standalone' AND enabled=1")
    for d in domains:
        accts = db.fetchall(
            "SELECT * FROM email_accounts WHERE domain_id=? AND account_type='mailbox' AND enabled=1",
            (d['id'],))
        for a in accts:
            lines.append(f"{a['prefix']}@{d['domain']}\t"
                         f"{utils.safe_filename(d['domain'])}/{utils.safe_filename(a['prefix'])}/Maildir/")
    return "\n".join(lines) + "\n"


def build_dovecot_passwd():
    """生成 Dovecot passwd-file（独立邮箱密码）"""
    lines = ["# 由 XPanel 自动生成 - 独立邮箱密码", ""]
    domains = db.fetchall("SELECT * FROM email_domains WHERE mode='standalone'")
    for d in domains:
        accts = db.fetchall(
            "SELECT * FROM email_accounts WHERE domain_id=? AND account_type='mailbox'",
            (d['id'],))
        for a in accts:
            if a['password']:
                lines.append(f"{a['prefix']}@{d['domain']}:{{PLAIN}}{a['password']}::::::")
    return "\n".join(lines) + "\n"


def postfix_maincf_settings(domains):
    """生成 main.cf 需要的虚拟域配置片段"""
    fwd = [d['domain'] for d in domains if d['mode'] == 'forward']
    mbox = [d['domain'] for d in domains if d['mode'] == 'standalone']
    lines = []
    if mbox:
        lines.append(f"virtual_mailbox_domains = {' '.join(mbox)}")
        lines.append("virtual_mailbox_base = " + config.MAIL_ROOT)
        lines.append("virtual_mailbox_maps = hash:/etc/postfix/vmailbox")
        lines.append("virtual_uid_maps = static:1000")
        lines.append("virtual_gid_maps = static:1000")
        lines.append("virtual_minimum_uid = 1000")
        lines.append("virtual_mailbox_limit = 0")
    if fwd:
        lines.append(f"virtual_alias_domains = {' '.join(fwd)}")
        lines.append("virtual_alias_maps = hash:/etc/postfix/virtual")
    return lines


def apply_mail_config():
    """把生成的配置写入系统并重载服务（配置始终生成，重载仅在服务存在时执行）"""
    msgs = []
    domains = db.fetchall("SELECT * FROM email_domains WHERE enabled=1")

    # 1. virtual（转发别名）
    utils.write_file(postfix_virtual_file(), build_virtual_maps())
    utils.run_cmd("postmap " + postfix_virtual_file())

    # 2. vmailbox（独立邮箱）
    if any(d['mode'] == 'standalone' for d in domains):
        utils.write_file(postfix_vmailbox_file(), build_vmailbox_maps())
        utils.run_cmd("postmap " + postfix_vmailbox_file())

    # 3. main.cf 追加虚拟域配置（幂等）
    settings = postfix_maincf_settings(domains)
    main = utils.read_file(config.POSTFIX_MAIN_CF)
    if settings:
        marker = "# === XPanel managed start ==="
        marker_end = "# === XPanel managed end ==="
        seg = "\n".join([marker] + settings + [marker_end]) + "\n"
        if marker in main:
            main = re.sub(re.escape(marker) + ".*?" + re.escape(marker_end) + "\n?",
                          seg, main, flags=re.S)
        else:
            main = main.rstrip() + "\n\n" + seg
        utils.write_file(config.POSTFIX_MAIN_CF, main)
        utils.run_cmd("postfix check")

    # 4. Dovecot 密码与投递配置
    if any(d['mode'] == 'standalone' for d in domains):
        utils.write_file(dovecot_passwd_file(), build_dovecot_passwd())
        _write_dovecot_conf()

    # 重载（仅当服务已安装）
    if utils.which('postfix'):
        utils.run_cmd("postfix reload 2>/dev/null || systemctl reload postfix 2>/dev/null || service postfix reload 2>/dev/null")
    if utils.which('dovecot'):
        utils.run_cmd("systemctl reload dovecot 2>/dev/null || service dovecot reload 2>/dev/null")
    return True, '配置已应用'


def _write_dovecot_conf():
    """写入 Dovecot 的 mail_location 与认证配置"""
    conf_dir = config.DOVECOT_CONF_DIR
    os.makedirs(conf_dir, exist_ok=True)
    utils.write_file(os.path.join(conf_dir, '10-mail-xpanel.conf'),
                     f"mail_location = maildir:{config.MAIL_ROOT}/%d/%n/Maildir\n")
    utils.write_file(os.path.join(conf_dir, '10-auth-xpanel.conf'), """# XPanel: passwd-file 认证
disable_plaintext_auth = no
auth_mechanisms = plain login
passdb {
  driver = passwd-file
  args = scheme=PLAIN username_format=%u /etc/dovecot/dovecot-passwd
}
userdb {
  driver = static
  args = uid=1000 gid=1000 home=/var/mail/vhosts/%d/%n
}
""")
    # 确保 dovecot 配置目录有 dovecot.conf 引用（若不存在则创建最小配置）
    dovecot_main = os.environ.get('XPANEL_DOVECOT_CONF', '/etc/dovecot/dovecot.conf')
    if not os.path.exists(dovecot_main):
        utils.write_file(dovecot_main, """protocols = imap pop3
listen = *
log_path = /var/log/dovecot.log
!include conf.d/*.conf
""")


def ensure_maildir(domain, prefix):
    md = domain_maildir(domain, prefix)
    for sub in ('cur', 'new', 'tmp'):
        os.makedirs(os.path.join(md, sub), exist_ok=True)
    # 权限交给 vmail 用户
    utils.run_cmd(f"chown -R vmail:vmail {config.MAIL_ROOT} 2>/dev/null || chown -R 1000:1000 {config.MAIL_ROOT} 2>/dev/null")
    return md


# ---------- API ----------
@bp.get('/api/email/status')
@login_required
def status():
    s = services_ready()
    smtp_up = False
    code, out, _ = utils.run_cmd("ss -ltn 2>/dev/null | grep -q ':25 ' && echo UP || echo DOWN")
    smtp_up = 'UP' in out
    return jsonify({'ok': True, 'data': {
        'postfix': s['postfix'], 'dovecot': s['dovecot'],
        'port25': smtp_up,
        'mail_root': config.MAIL_ROOT,
    }})


@bp.post('/api/email/install')
@login_required
def install_mail():
    ok, msg = ensure_postfix_dovecot()
    if ok:
        utils.run_cmd("systemctl enable postfix dovecot 2>/dev/null")
        utils.run_cmd("systemctl restart postfix dovecot 2>/dev/null")
    return jsonify({'ok': ok, 'msg': msg})


@bp.get('/api/email/domains')
@login_required
def list_domains():
    rows = db.fetchall("SELECT * FROM email_domains ORDER BY id DESC")
    for r in rows:
        r['accounts'] = db.fetchall(
            "SELECT * FROM email_accounts WHERE domain_id=? ORDER BY id",
            (r['id'],))
        r['webmail_url'] = f"/webmail/{r['domain']}" if r['mode'] == 'standalone' else ''
    return jsonify({'ok': True, 'data': rows})


@bp.post('/api/email/domains')
@login_required
def create_domain():
    data = request.get_json(silent=True) or {}
    domain = (data.get('domain') or '').strip()
    mode = data.get('mode') or 'forward'
    forward_target = (data.get('forward_target') or '').strip()

    if not utils.valid_domain(domain):
        return jsonify({'ok': False, 'msg': '域名格式不正确'})
    if db.fetchone("SELECT id FROM email_domains WHERE domain=?", (domain,)):
        return jsonify({'ok': False, 'msg': '该邮箱域名已存在'})
    if mode == 'forward' and not forward_target:
        return jsonify({'ok': False, 'msg': '转发模式必须填写收件邮箱'})
    if mode == 'forward' and '@' not in forward_target:
        return jsonify({'ok': False, 'msg': '收件邮箱格式不正确'})

    did = db.execute(
        "INSERT INTO email_domains(domain,mode,forward_target,webmail_enabled) "
        "VALUES(?,?,?,1)", (domain, mode, forward_target))

    # 独立邮箱：默认创建 admin 管理账号
    if mode == 'standalone':
        ensure_maildir(domain, 'admin')
        db.execute(
            "INSERT INTO email_accounts(domain_id,prefix,password,account_type,target) "
            "VALUES(?,?,?,?,?)",
            (did, 'admin', utils.gen_password(10), 'mailbox', ''))

    apply_mail_config()
    return jsonify({'ok': True, 'msg': '邮箱域名创建成功', 'id': did})


@bp.delete('/api/email/domains/<int:did>')
@login_required
def delete_domain(did):
    d = db.fetchone("SELECT * FROM email_domains WHERE id=?", (did,))
    if not d:
        return jsonify({'ok': False, 'msg': '域名不存在'})
    db.execute("DELETE FROM email_accounts WHERE domain_id=?", (did,))
    db.execute("DELETE FROM email_domains WHERE id=?", (did,))
    apply_mail_config()
    return jsonify({'ok': True, 'msg': '邮箱域名已删除'})


@bp.post('/api/email/accounts')
@login_required
def create_account():
    data = request.get_json(silent=True) or {}
    did = data.get('domain_id')
    prefix = (data.get('prefix') or '').strip()
    account_type = data.get('account_type') or 'alias'
    target = (data.get('target') or '').strip()
    password = data.get('password') or ''

    d = db.fetchone("SELECT * FROM email_domains WHERE id=?", (did,))
    if not d:
        return jsonify({'ok': False, 'msg': '域名不存在'})
    if not re.match(r'^[a-zA-Z0-9._-]{1,64}$', prefix):
        return jsonify({'ok': False, 'msg': '前缀只能包含字母数字和 . _ -'})
    if db.fetchone("SELECT id FROM email_accounts WHERE domain_id=? AND prefix=?",
                   (did, prefix)):
        return jsonify({'ok': False, 'msg': '该前缀已存在'})

    if account_type == 'mailbox':
        if len(password) < 6:
            return jsonify({'ok': False, 'msg': '密码至少 6 位'})
        ensure_maildir(d['domain'], prefix)
    elif account_type == 'alias':
        if not target:
            target = d['forward_target']
        if '@' not in target:
            return jsonify({'ok': False, 'msg': '转发目标邮箱不正确'})

    db.execute(
        "INSERT INTO email_accounts(domain_id,prefix,password,account_type,target) "
        "VALUES(?,?,?,?,?)",
        (did, prefix, password, account_type, target))
    apply_mail_config()
    return jsonify({'ok': True, 'msg': '账号创建成功'})


@bp.delete('/api/email/accounts/<int:aid>')
@login_required
def delete_account(aid):
    a = db.fetchone("SELECT * FROM email_accounts WHERE id=?", (aid,))
    if not a:
        return jsonify({'ok': False, 'msg': '账号不存在'})
    d = db.fetchone("SELECT * FROM email_domains WHERE id=?", (a['domain_id'],))
    if a['account_type'] == 'mailbox' and d:
        import shutil
        shutil.rmtree(domain_maildir(d['domain'], a['prefix']), ignore_errors=True)
    db.execute("DELETE FROM email_accounts WHERE id=?", (aid,))
    apply_mail_config()
    return jsonify({'ok': True, 'msg': '账号已删除'})


@bp.get('/api/email/accounts/<int:aid>')
@login_required
def account_detail(aid):
    a = db.fetchone("SELECT * FROM email_accounts WHERE id=?", (aid,))
    if not a:
        return jsonify({'ok': False, 'msg': '账号不存在'})
    d = db.fetchone("SELECT * FROM email_domains WHERE id=?", (a['domain_id'],))
    return jsonify({'ok': True, 'data': {
        'account': a, 'domain': d['domain'], 'email': f"{a['prefix']}@{d['domain']}",
        'maildir': domain_maildir(d['domain'], a['prefix']) if a['account_type'] == 'mailbox' else '',
    }})


@bp.get('/api/email/config_preview')
@login_required
def config_preview():
    return jsonify({'ok': True, 'data': {
        'virtual': build_virtual_maps(),
        'vmailbox': build_vmailbox_maps(),
        'dovecot_passwd': build_dovecot_passwd(),
        'maincf': "\n".join(postfix_maincf_settings(
            db.fetchall("SELECT * FROM email_domains WHERE enabled=1"))),
    }})
