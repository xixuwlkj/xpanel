# -*- coding: utf-8 -*-
"""
XPanel 希旭面板 - Web 终端
pty + bash 轮询模式（零额外依赖，部署即用）
"""
import os
import pty
import select
import subprocess
import threading
from flask import Blueprint, request, jsonify
from .auth import login_required

bp = Blueprint('terminal', __name__)

_proc = None
_master_fd = None
_lock = threading.Lock()


def _ensure():
    global _proc, _master_fd
    with _lock:
        if _proc is not None and _proc.poll() is None:
            return True
        try:
            master, slave = pty.openpty()
            _proc = subprocess.Popen(
                ['/bin/bash', '--login'],
                stdin=slave, stdout=slave, stderr=slave,
                close_fds=True, preexec_fn=os.setsid)
            os.close(slave)
            _master_fd = master
            return True
        except Exception:
            return False


@bp.post('/api/terminal/start')
@login_required
def t_start():
    ok = _ensure()
    return jsonify({'ok': ok, 'msg': '终端已启动' if ok else '终端启动失败'})


@bp.post('/api/terminal/input')
@login_required
def t_input():
    if not _ensure():
        return jsonify({'ok': False, 'msg': '终端未启动'})
    data = (request.get_json(silent=True) or {}).get('data') or ''
    try:
        os.write(_master_fd, data.encode('utf-8', 'replace'))
    except Exception:
        pass
    return jsonify({'ok': True})


@bp.get('/api/terminal/output')
@login_required
def t_output():
    if not _ensure():
        return jsonify({'ok': True, 'data': ''})
    out = b''
    try:
        while True:
            r, _, _ = select.select([_master_fd], [], [], 0)
            if not r:
                break
            chunk = os.read(_master_fd, 4096)
            if not chunk:
                break
            out += chunk
    except Exception:
        pass
    return jsonify({'ok': True, 'data': out.decode('utf-8', 'replace')})


@bp.post('/api/terminal/reset')
@login_required
def t_reset():
    global _proc
    with _lock:
        if _proc is not None:
            try:
                _proc.kill()
            except Exception:
                pass
            _proc = None
    _ensure()
    return jsonify({'ok': True, 'msg': '终端已重置'})
