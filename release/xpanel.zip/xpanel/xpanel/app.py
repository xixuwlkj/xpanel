# -*- coding: utf-8 -*-
"""
XPanel 希旭面板 - 主入口
启动: python3 xpanel/app.py  (或通过 xpanel.service)
"""
import os
import logging
import sys

from flask import Flask, send_from_directory, jsonify

from . import config
from . import db as dbmod
from . import auth, system, sites, nodes, emailmgr, webmail, softwares, files, security, terminal

config.ensure_dirs()
os.makedirs(config.DATA_DIR, exist_ok=True)


def create_app():
    app = Flask(__name__,
                static_folder=config.STATIC_DIR,
                static_url_path='/static')
    app.config['JSON_AS_ASCII'] = False
    app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024

    # 初始化数据库与管理员
    dbmod.init_db()
    auth.init_admin()

    # 日志
    if not logging.getLogger('xpanel').handlers:
        h = logging.FileHandler(config.LOG_PATH, encoding='utf-8')
        h.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'))
        logging.getLogger('xpanel').addHandler(h)
        logging.getLogger('xpanel').setLevel(logging.INFO)

    # 注册蓝图
    app.register_blueprint(auth_module_bp())
    app.register_blueprint(system.bp)
    app.register_blueprint(sites.bp)
    app.register_blueprint(nodes.bp)
    app.register_blueprint(emailmgr.bp)
    app.register_blueprint(webmail.bp)
    app.register_blueprint(softwares.bp)
    app.register_blueprint(files.bp)
    app.register_blueprint(security.bp)
    app.register_blueprint(terminal.bp)

    @app.get('/')
    def index():
        return send_from_directory(config.STATIC_DIR, 'index.html')

    @app.get('/<path:path>')
    def static_fallback(path):
        # SPA 前端路由回退
        full = os.path.join(config.STATIC_DIR, path)
        if os.path.isfile(full):
            return send_from_directory(config.STATIC_DIR, path)
        return send_from_directory(config.STATIC_DIR, 'index.html')

    @app.errorhandler(404)
    def not_found(e):
        return jsonify({'ok': False, 'msg': '接口不存在'}), 404

    return app


def auth_module_bp():
    from flask import Blueprint
    b = Blueprint('auth_api', __name__)
    auth.register_api(b)
    return b


app = create_app()


if __name__ == '__main__':
    port = int(os.environ.get('XPANEL_PORT', config.PANEL_PORT))
    host = os.environ.get('XPANEL_HOST', config.PANEL_HOST)
    print(f"\n  XPanel 希旭面板启动中...")
    print(f"  访问地址: http://{host}:{port}")
    app.run(host=host, port=port, debug=False)
