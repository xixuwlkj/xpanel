# -*- coding: utf-8 -*-
"""
XPanel 希旭面板 - 认证与会话
"""
import threading
import time
from functools import wraps
from flask import request, jsonify, g
from . import db, config, utils

# 内存会话表 { token: {username, expire} }
_sessions = {}
_lock = threading.Lock()


def _cleanup():
    now = time.time()
    with _lock:
        for k in list(_sessions.keys()):
            if _sessions[k]['expire'] < now:
                del _sessions[k]


def create_session(username):
    _cleanup()
    token = utils.gen_token()
    with _lock:
        _sessions[token] = {'username': username,
                            'expire': time.time() + config.TOKEN_TTL}
    return token


def destroy_session(token):
    with _lock:
        _sessions.pop(token, None)


def get_session(token):
    _cleanup()
    with _lock:
        s = _sessions.get(token)
    return s


def init_admin():
    """首次启动时如果没有任何用户，则创建默认管理员"""
    if not db.fetchone("SELECT id FROM users LIMIT 1"):
        db.execute(
            "INSERT INTO users(username, password_hash) VALUES(?,?)",
            (config.DEFAULT_ADMIN, utils.hash_password(config.DEFAULT_PASSWORD)))
        return True
    return False


def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        token = request.headers.get('X-Panel-Token') or \
                (request.args.get('token') or '')
        s = get_session(token)
        if not s:
            return jsonify({'ok': False, 'msg': '未登录或会话已过期'}), 401
        g.username = s['username']
        g.token = token
        return fn(*args, **kwargs)
    return wrapper


def register_api(app):
    @app.post('/api/login')
    def api_login():
        data = request.get_json(silent=True) or {}
        username = (data.get('username') or '').strip()
        password = data.get('password') or ''
        user = db.fetchone("SELECT * FROM users WHERE username=?", (username,))
        if not user or not utils.verify_password(password, user['password_hash']):
            return jsonify({'ok': False, 'msg': '用户名或密码错误'})
        token = create_session(username)
        return jsonify({'ok': True, 'token': token, 'username': username})

    @app.post('/api/logout')
    @login_required
    def api_logout():
        destroy_session(g.token)
        return jsonify({'ok': True})

    @app.get('/api/me')
    @login_required
    def api_me():
        return jsonify({'ok': True, 'data': {
            'username': g.username, 'version': 'XPanel 1.0.0'}})

    @app.post('/api/change_password')
    @login_required
    def api_change_password():
        data = request.get_json(silent=True) or {}
        old = data.get('old_password') or ''
        new = data.get('new_password') or ''
        if len(new) < 6:
            return jsonify({'ok': False, 'msg': '新密码至少 6 位'})
        user = db.fetchone("SELECT * FROM users WHERE username=?", (g.username,))
        if not utils.verify_password(old, user['password_hash']):
            return jsonify({'ok': False, 'msg': '原密码错误'})
        db.execute("UPDATE users SET password_hash=? WHERE username=?",
                   (utils.hash_password(new), g.username))
        return jsonify({'ok': True, 'msg': '密码已修改'})
