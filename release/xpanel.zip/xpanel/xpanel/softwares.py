# -*- coding: utf-8 -*-
"""
XPanel 希旭面板 - 软件商店
检测各组件是否安装，并支持后台异步安装（宝塔式按需安装）。
组件不在面板安装脚本中强制安装，登录面板后由用户在软件商店/弹窗中选择安装。
"""
import os
import re
import subprocess
import threading
import time
from flask import Blueprint, request, jsonify

from . import config
from .auth import login_required
from .utils import run_cmd

bp = Blueprint('softwares', __name__)

# ---------------- 组件定义 ----------------
# check: 用于检测是否已安装的命令
# install: 按系统分发的安装命令；'any' 表示通用安装
COMPONENTS = [
    {
        'name': 'nginx',
        'label': 'Nginx 服务器',
        'desc': 'Web 服务器，网站 / PHP / 反向代理运行必需',
        'icon': '▣',
        'check': 'nginx -v',
        'install': {
            'debian': 'apt-get install -y nginx',
            'rhel': 'yum install -y nginx',
        },
        'service': 'nginx',
    },
    {
        'name': 'php',
        'label': 'PHP-FPM',
        'desc': 'PHP 运行环境（php8.1 + 常用扩展），PHP 网站必需',
        'icon': '℗',
        'check': 'php -v',
        'install': {
            'debian': 'apt-get install -y php-fpm php-cli php-mysql php-curl php-gd php-mbstring php-xml',
            'rhel': 'yum install -y php-fpm php-cli php-mysqlnd php-curl php-gd php-mbstring php-xml',
        },
        'service': 'php-fpm',
    },
    {
        'name': 'mysql',
        'label': 'MySQL / MariaDB',
        'desc': '数据库服务（MariaDB），网站数据存储',
        'icon': '◈',
        'check': 'mysql --version',
        'install': {
            'debian': 'DEBIAN_FRONTEND=noninteractive apt-get install -y mariadb-server',
            'rhel': 'yum install -y mariadb-server',
        },
        'service': 'mariadb',
    },
    {
        'name': 'postfix',
        'label': 'Postfix 邮件服务器',
        'desc': 'SMTP 邮件收发，邮箱服务（转发 / 独立邮箱）必需',
        'icon': '✉',
        'check': 'postconf -d',
        'install': {
            'debian': 'DEBIAN_FRONTEND=noninteractive apt-get install -y postfix',
            'rhel': 'yum install -y postfix',
        },
        'service': 'postfix',
    },
    {
        'name': 'dovecot',
        'label': 'Dovecot 收信服务',
        'desc': 'IMAP / POP3 收信，独立邮箱（网页邮箱）必需',
        'icon': '✆',
        'check': 'dovecot --version',
        'install': {
            'debian': 'apt-get install -y dovecot-imapd dovecot-pop3d',
            'rhel': 'yum install -y dovecot',
        },
        'service': 'dovecot',
    },
    {
        'name': 'xray',
        'label': 'Xray 核心',
        'desc': '代理节点运行核心（VMess / VLESS / Trojan）',
        'icon': '◎',
        'check': 'xray version',
        'install': {
            'any': "bash -c '$(curl -Ls https://github.com/XTLS/Xray-install/raw/main/install-release.sh)' @ install",
        },
        'service': 'xray',
    },
]

# ---------------- 运行状态（内存） ----------------
# {name: {'status': running|done|error, 'message': str, 'start': ts}}
_state = {}
_state_lock = threading.Lock()

# 非 root 测试模式：环境变量指定模拟安装命令
# 仅供沙箱 / 测试用：XPANEL_FAKE_INSTALL=1 时不执行真实 apt，直接标记成功
FAKE_INSTALL = os.environ.get('XPANEL_FAKE_INSTALL', '') == '1'


def detect_os():
    """返回 debian / rhel / unknown"""
    if os.path.exists('/etc/debian_version'):
        return 'debian'
    try:
        with open('/etc/os-release') as f:
            content = f.read()
        if re.search(r'(?i)ubuntu|debian', content):
            return 'debian'
        if re.search(r'(?i)centos|redhat|fedora|rocky|almalinux', content):
            return 'rhel'
    except Exception:
        pass
    return 'debian'  # 默认 debian


def _is_installed(name):
    comp = _by_name(name)
    if not comp:
        return False
    code, _, _ = run_cmd(comp['check'], timeout=15)
    return code == 0


def _by_name(name):
    for c in COMPONENTS:
        if c['name'] == name:
            return c
    return None


def scan():
    """返回全部组件当前状态"""
    result = {}
    for c in COMPONENTS:
        installed = _is_installed(c['name'])
        with _state_lock:
            st = _state.get(c['name'], {})
        if installed:
            status = 'done'
            message = '已安装'
        else:
            status = st.get('status', 'idle')
            message = st.get('message', '未安装')
        result[c['name']] = {
            'label': c['label'],
            'desc': c['desc'],
            'icon': c['icon'],
            'installed': installed,
            'status': status,
            'message': message,
        }
    return result


def _set_state(name, status, message):
    with _state_lock:
        _state[name] = {'status': status, 'message': message, 'start': time.time()}


def _install_worker(name):
    comp = _by_name(name)
    if not comp:
        return
    _set_state(name, 'running', '正在安装...')
    try:
        if FAKE_INSTALL:
            # 测试模式：不执行真实安装
            time.sleep(1)
            _set_state(name, 'done', '安装完成（测试模式）')
            return
        os_family = detect_os()
        cmd = comp['install'].get(os_family) or comp['install'].get('any')
        if not cmd:
            _set_state(name, 'error', '当前系统不支持自动安装，请手动安装')
            return
        # 更新软件源
        if os_family == 'debian':
            run_cmd('apt-get update', timeout=180)
        elif os_family == 'rhel':
            run_cmd('yum makecache', timeout=180)
        code, out, err = run_cmd(cmd, timeout=900)
        # 启动服务
        svc = comp.get('service')
        if svc:
            run_cmd(f"systemctl enable {svc} 2>/dev/null; systemctl restart {svc} 2>/dev/null", timeout=60)
        if _is_installed(name):
            _set_state(name, 'done', '安装完成')
        else:
            msg = (err or out or '')[-200:]
            _set_state(name, 'error', f'安装后校验失败: {msg}')
    except Exception as e:
        _set_state(name, 'error', f'安装异常: {str(e)}')


# ---------------- API ----------------
@bp.get('/api/softwares')
@login_required
def api_list():
    return jsonify({'ok': True, 'data': scan()})


@bp.post('/api/softwares/install')
@login_required
def api_install():
    body = request.get_json(silent=True) or {}
    name = (body.get('name') or '').strip()
    comp = _by_name(name)
    if not comp:
        return jsonify({'ok': False, 'msg': '未知组件'})
    with _state_lock:
        st = _state.get(name, {})
        if st.get('status') == 'running':
            return jsonify({'ok': False, 'msg': f'{comp["label"]} 正在安装中'})
        if st.get('status') == 'done':
            return jsonify({'ok': False, 'msg': f'{comp["label"]} 已安装'})
    if _is_installed(name):
        return jsonify({'ok': False, 'msg': f'{comp["label"]} 已安装'})
    t = threading.Thread(target=_install_worker, args=(name,), daemon=True)
    t.start()
    return jsonify({'ok': True, 'msg': f'开始安装 {comp["label"]}'})


@bp.post('/api/softwares/install_all')
@login_required
def api_install_all():
    started = []
    for c in COMPONENTS:
        if _is_installed(c['name']):
            continue
        with _state_lock:
            st = _state.get(c['name'], {})
            if st.get('status') == 'running' or st.get('status') == 'done':
                continue
        _set_state(c['name'], 'pending', '等待安装...')
        t = threading.Thread(target=_install_worker, args=(c['name'],), daemon=True)
        t.start()
        started.append(c['label'])
    return jsonify({'ok': True, 'msg': f'已开始安装 {len(started)} 个组件',
                    'data': {'started': started}})
