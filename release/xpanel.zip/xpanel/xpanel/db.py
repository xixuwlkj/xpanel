# -*- coding: utf-8 -*-
"""
XPanel 希旭面板 - SQLite 数据层
"""
import sqlite3
import json
import os
from . import config

_schema = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    created_at TEXT DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS sites (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    domain TEXT NOT NULL,
    site_type TEXT DEFAULT 'php',          -- php / python / static
    php_version TEXT DEFAULT '8.1',
    root_path TEXT,
    port INTEGER DEFAULT 0,                -- python 站点端口
    frame TEXT DEFAULT 'flask',            -- python 框架 flask/fastapi
    enabled INTEGER DEFAULT 1,
    created_at TEXT DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS nodes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    protocol TEXT DEFAULT 'vmess',         -- vmess / vless / trojan
    uuid TEXT NOT NULL,
    port INTEGER NOT NULL,
    alter_id INTEGER DEFAULT 0,
    encryption TEXT DEFAULT 'auto',
    network TEXT DEFAULT 'tcp',            -- tcp / ws / grpc
    path TEXT DEFAULT '',
    host TEXT DEFAULT '',
    tls INTEGER DEFAULT 0,
    enabled INTEGER DEFAULT 1,
    created_at TEXT DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS email_domains (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    domain TEXT UNIQUE NOT NULL,
    mode TEXT DEFAULT 'forward',           -- forward 转发 / standalone 独立邮箱
    forward_target TEXT DEFAULT '',        -- 转发模式下收件邮箱
    webmail_enabled INTEGER DEFAULT 1,
    enabled INTEGER DEFAULT 1,
    created_at TEXT DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS email_accounts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    domain_id INTEGER NOT NULL,
    prefix TEXT NOT NULL,
    password TEXT DEFAULT '',
    account_type TEXT DEFAULT 'alias',     -- alias 转发别名 / mailbox 独立邮箱账号
    target TEXT DEFAULT '',
    enabled INTEGER DEFAULT 1,
    created_at TEXT DEFAULT (datetime('now','localtime')),
    UNIQUE(domain_id, prefix)
);

CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
);
"""


def get_db():
    conn = sqlite3.connect(config.DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    os.makedirs(config.DATA_DIR, exist_ok=True)
    conn = get_db()
    conn.executescript(_schema)
    conn.commit()
    conn.close()


def set_setting(key, value):
    conn = get_db()
    conn.execute(
        "INSERT INTO settings(key,value) VALUES(?,?) "
        "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (key, str(value)))
    conn.commit()
    conn.close()


def get_setting(key, default=None):
    conn = get_db()
    row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    conn.close()
    return row['value'] if row else default


def fetchall(sql, args=()):
    conn = get_db()
    rows = conn.execute(sql, args).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def fetchone(sql, args=()):
    conn = get_db()
    row = conn.execute(sql, args).fetchone()
    conn.close()
    return dict(row) if row else None


def execute(sql, args=()):
    conn = get_db()
    cur = conn.execute(sql, args)
    conn.commit()
    lastid = cur.lastrowid
    conn.close()
    return lastid
