# -*- coding: utf-8 -*-
"""
XPanel 希旭面板 - 独立邮箱 Webmail（网页邮箱）
- 登录校验（对照 Dovecot passwd-file 中账号）
- 在线收信（直接读取 Maildir）
- 在线发信（走本机 Postfix SMTP）
- 管理账号（创建前缀、修改密码）
"""
import os
import re
import json
import smtplib
import time
import uuid
from email import policy
from email.parser import BytesParser
from email.utils import formatdate, make_msgid
from flask import Blueprint, request, jsonify, Response
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

from . import config, db, utils
from .auth import login_required

bp = Blueprint('webmail', __name__)

# 会话 { token: {domain, prefix} }
_sessions = {}


# ---------- 工具 ----------
def maildir_path(domain, prefix):
    return os.path.join(config.MAIL_ROOT, utils.safe_filename(domain),
                        utils.safe_filename(prefix), 'Maildir')


def get_domain(domain):
    return db.fetchone("SELECT * FROM email_domains WHERE domain=? AND mode='standalone'",
                       (domain,))


def get_account(domain_id, prefix):
    return db.fetchone(
        "SELECT * FROM email_accounts WHERE domain_id=? AND prefix=? AND account_type='mailbox'",
        (domain_id, prefix))


def _parse_msg(raw):
    msg = BytesParser(policy=policy.default).parsebytes(raw)
    def _decode(v):
        if not v:
            return ''
        try:
            return str(msg[v]) if v in msg else ''
        except Exception:
            return ''
    return {
        'from': _decode('From'),
        'to': _decode('To'),
        'cc': _decode('Cc'),
        'subject': _decode('Subject'),
        'date': _decode('Date'),
        'message_id': _decode('Message-ID'),
    }


def list_mail(domain, prefix, box='new'):
    md = maildir_path(domain, prefix)
    subdir = os.path.join(md, box)
    if not os.path.isdir(subdir):
        return []
    mails = []
    for fn in os.listdir(subdir):
        fp = os.path.join(subdir, fn)
        if not os.path.isfile(fp):
            continue
        try:
            with open(fp, 'rb') as f:
                raw = f.read()
            info = _parse_msg(raw)
            info['file'] = fn
            info['box'] = box
            info['size'] = len(raw)
            info['ts'] = os.path.getmtime(fp)
            mails.append(info)
        except Exception:
            continue
    mails.sort(key=lambda x: -x['ts'])
    return mails


def read_mail_raw(domain, prefix, fn, box='new'):
    fp = os.path.join(maildir_path(domain, prefix), box, fn)
    if not os.path.isfile(fp) or '..' in fn or '/' in fn:
        return None
    with open(fp, 'rb') as f:
        return f.read()


def send_mail(domain, prefix, password, to_list, subject, body):
    """通过本机 Postfix 发送邮件"""
    user = f"{prefix}@{domain}"
    sender = user
    msg = MIMEText(body, 'plain', 'utf-8')
    msg['Subject'] = subject
    msg['From'] = sender
    msg['To'] = ', '.join(to_list)
    msg['Date'] = formatdate(localtime=True)
    msg['Message-ID'] = make_msgid(domain=domain)

    last_err = None
    # 优先带认证走 587 submission
    for port, use_auth in ((587, True), (25, False)):
        try:
            s = smtplib.SMTP('127.0.0.1', port, timeout=15)
            s.ehlo()
            if use_auth:
                if s.has_extn('starttls'):
                    s.starttls()
                    s.ehlo()
                s.login(user, password)
            s.sendmail(sender, to_list, msg.as_string())
            s.quit()
            return True, '发送成功'
        except Exception as e:
            last_err = str(e)
            continue
    return False, f'发送失败: {last_err}'


# ---------- 页面 ----------
def webmail_html(domain):
    return f"""<!DOCTYPE html>
<html lang="zh">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>网页邮箱 - {domain}</title>
<style>
  * {{ margin:0; padding:0; box-sizing:border-box; font-family:-apple-system,'PingFang SC','Microsoft YaHei',sans-serif; }}
  body {{ background:#f0f3f7; color:#333; }}
  .topbar {{ background:#2a7de1; color:#fff; padding:14px 24px; display:flex; justify-content:space-between; align-items:center; }}
  .topbar h1 {{ font-size:18px; }}
  .wrap {{ display:flex; min-height:calc(100vh - 56px); }}
  .side {{ width:170px; background:#fff; border-right:1px solid #e5e8ec; padding:12px 0; }}
  .side a {{ display:block; padding:12px 20px; color:#555; text-decoration:none; cursor:pointer; }}
  .side a:hover, .side a.active {{ background:#eaf2fd; color:#2a7de1; border-left:3px solid #2a7de1; }}
  .main {{ flex:1; padding:20px; }}
  .card {{ background:#fff; border:1px solid #e5e8ec; border-radius:6px; padding:16px; margin-bottom:14px; }}
  table {{ width:100%; border-collapse:collapse; }}
  th,td {{ text-align:left; padding:10px 8px; border-bottom:1px solid #eef1f5; font-size:13px; }}
  th {{ background:#f7f9fc; color:#666; }}
  tr:hover td {{ background:#fafcff; }}
  .btn {{ background:#2a7de1; color:#fff; border:0; padding:7px 14px; border-radius:4px; cursor:pointer; font-size:13px; }}
  .btn.gray {{ background:#9aa4b2; }}
  .btn.green {{ background:#22a06b; }}
  input,textarea {{ width:100%; padding:8px; border:1px solid #d7dce3; border-radius:4px; font-size:13px; }}
  label {{ display:block; margin:10px 0 4px; font-size:13px; color:#555; }}
  .login {{ max-width:360px; margin:100px auto; }}
  .msg {{ padding:10px 14px; border-radius:4px; margin:10px 0; font-size:13px; }}
  .msg.ok {{ background:#e6f7ee; color:#1a7f4b; }}
  .msg.err {{ background:#fdeaea; color:#c0392b; }}
  .hidden {{ display:none; }}
  .mail-detail {{ white-space:pre-wrap; font-size:13px; line-height:1.7; }}
</style>
</head>
<body>
<div class="topbar"><h1>✉ {domain} 网页邮箱</h1><span id="who"></span></div>
<div class="wrap">
  <div class="side">
    <a data-v="inbox" class="active">收件箱</a>
    <a data-v="compose">写信</a>
    <a data-v="manage" id="manageLink">账号管理</a>
    <a data-v="logout" id="logoutLink">退出</a>
  </div>
  <div class="main">
    <div id="loginBox" class="login card">
      <h2 style="margin-bottom:14px">登录邮箱</h2>
      <div id="loginMsg"></div>
      <label>邮箱前缀</label><input id="lgPrefix" placeholder="admin" value="admin">
      <label>密码</label><input id="lgPass" type="password" placeholder="密码">
      <br><br><button class="btn" onclick="login()" style="width:100%">登 录</button>
    </div>
    <div id="appBox" class="hidden">
      <div id="view"></div>
    </div>
  </div>
</div>
<script>
const DOMAIN = {json.dumps(domain)};
let tok = localStorage.getItem('wm_' + DOMAIN) || '';
function api(p, body, method){{
  const opt = {{method: method||(body?'POST':'GET'), headers:{{'Content-Type':'application/json','X-WM-Token':tok}} }};
  if(body) opt.body = JSON.stringify(body);
  return fetch('/api/webmail/' + DOMAIN + p, opt).then(r=>r.json());
}}
function show(m,cls){{ document.getElementById('view').innerHTML = '<div class="msg '+cls+'">'+m+'</div>'; }}
async function login(){{
  const r = await api('/login', {{prefix:document.getElementById('lgPrefix').value, password:document.getElementById('lgPass').value}});
  if(r.ok){{ tok = r.token; localStorage.setItem('wm_'+DOMAIN, tok); location.reload(); }}
  else document.getElementById('loginMsg').innerHTML = '<div class="msg err">'+r.msg+'</div>';
}}
async function load(){{
  if(!tok) return;
  const me = await api('/me');
  if(!me.ok){{ document.getElementById('loginBox').classList.remove('hidden'); document.getElementById('appBox').classList.add('hidden'); return; }}
  document.getElementById('loginBox').classList.add('hidden');
  document.getElementById('appBox').classList.remove('hidden');
  document.getElementById('who').textContent = me.username + ' (' + me.email + ')';
  if(me.prefix !== 'admin') document.getElementById('manageLink').classList.add('hidden');
  showInbox();
}}
async function showInbox(){{
  document.querySelectorAll('.side a').forEach(a=>a.classList.toggle('active',a.dataset.v==='inbox'));
  const r = await api('/inbox');
  if(!r.ok) return show(r.msg,'err');
  let html = '<div class="card"><h3 style="margin-bottom:10px">收件箱 ('+r.data.new.length+')</h3>';
  html += '<table><tr><th>发件人</th><th>主题</th><th>时间</th><th></th></tr>';
  [...r.data.new, ...r.data.cur].forEach(m=>{{
    html += '<tr onclick="openMail(\\''+m.box+'\\',\\''+m.file+'\\')"><td>'+esc(m.from)+'</td><td>'+esc(m.subject)+'</td><td>'+new Date(m.ts*1000).toLocaleString()+'</td><td><button class="btn gray" onclick="event.stopPropagation();del(\\''+m.box+'\\',\\''+m.file+'\\')">删除</button></td></tr>';
  }});
  html += '</table></div>';
  document.getElementById('view').innerHTML = html;
}}
async function openMail(box,fn){{
  const r = await api('/read?box='+box+'&file='+encodeURIComponent(fn));
  if(!r.ok) return show(r.msg,'err');
  const d = r.data;
  document.getElementById('view').innerHTML = '<div class="card"><h3>'+esc(d.subject||'(无主题)')+'</h3>'
    +'<p style="color:#777;font-size:12px;margin:8px 0">'+esc(d.from)+' → '+esc(d.to)+'<br>'+esc(d.date)+'</p>'
    +'<hr style="margin:10px 0"><div class="mail-detail">'+esc(d.body||'(无正文)')+'</div>'
    +'<br><button class="btn gray" onclick="showInbox()">返回</button></div>';
}}
async function del(box,fn){{
  if(!confirm('删除这封邮件？')) return;
  const r = await api('/delete?box='+box+'&file='+encodeURIComponent(fn));
  if(r.ok) showInbox();
}}
async function showCompose(){{
  document.querySelectorAll('.side a').forEach(a=>a.classList.toggle('active',a.dataset.v==='compose'));
  document.getElementById('view').innerHTML = '<div class="card"><h3 style="margin-bottom:10px">写信</h3>'
    +'<label>收件人</label><input id="cmTo" placeholder="a@example.com, b@example.com">'
    +'<label>主题</label><input id="cmSub" placeholder="主题">'
    +'<label>正文</label><textarea id="cmBody" rows="10"></textarea>'
    +'<br><br><button class="btn" onclick="send()">发送</button></div>';
}}
async function send(){{
  const r = await api('/send', {{to:document.getElementById('cmTo').value, subject:document.getElementById('cmSub').value, body:document.getElementById('cmBody').value}});
  show(r.msg, r.ok?'ok':'err');
  if(r.ok) showCompose();
}}
async function showManage(){{
  document.querySelectorAll('.side a').forEach(a=>a.classList.toggle('active',a.dataset.v==='manage'));
  const r = await api('/accounts');
  if(!r.ok) return show(r.msg,'err');
  let html = '<div class="card"><h3 style="margin-bottom:10px">创建邮箱账号</h3>'
    +'<label>前缀</label><input id="nPrefix" placeholder="user1">'
    +'<label>密码</label><input id="nPass" placeholder="至少 6 位">'
    +'<br><br><button class="btn" onclick="createAcct()">创建</button></div>';
  html += '<div class="card"><h3 style="margin-bottom:10px">已有账号</h3><table><tr><th>邮箱</th><th>创建时间</th><th></th></tr>';
  r.data.forEach(a=>{{
    html += '<tr><td>'+esc(a.email)+'</td><td>'+a.created_at+'</td><td><button class="btn gray" onclick="delAcct('+a.id+')">删除</button></td></tr>';
  }});
  html += '</table></div>';
  document.getElementById('view').innerHTML = html;
}}
async function createAcct(){{
  const r = await api('/accounts', {{prefix:document.getElementById('nPrefix').value, password:document.getElementById('nPass').value}});
  show(r.msg, r.ok?'ok':'err');
  if(r.ok) showManage();
}}
async function delAcct(id){{ if(confirm('删除该账号？')){{ const r = await api('/accounts/'+id, {{}}, 'DELETE'); show(r.msg,r.ok?'ok':'err'); if(r.ok) showManage(); }} }}
function esc(s){{ return (s||'').replace(/[&<>"]/g, c=>({{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}}[c])); }}
document.querySelectorAll('.side a').forEach(a=>a.onclick = ()=>{{
  if(a.dataset.v==='logout'){{ localStorage.removeItem('wm_'+DOMAIN); location.reload(); }}
  else if(a.dataset.v==='inbox') showInbox();
  else if(a.dataset.v==='compose') showCompose();
  else if(a.dataset.v==='manage') showManage();
}});
load();
</script>
</body>
</html>"""


def _require_wm_token():
    d = request.view_args or {}
    domain = d.get('domain')
    token = request.headers.get('X-WM-Token') or request.args.get('token') or ''
    s = _sessions.get(token)
    if not s or s['domain'] != domain:
        return None, None, None
    return domain, s['prefix'], token


@bp.get('/webmail/<domain>')
def webmail_page(domain):
    dom = get_domain(domain)
    if not dom:
        return Response("未找到该独立邮箱域名", status=404)
    return Response(webmail_html(domain), mimetype='text/html')


# ---------- Webmail API ----------
@bp.post('/api/webmail/<domain>/login')
def wm_login(domain):
    dom = get_domain(domain)
    if not dom:
        return jsonify({'ok': False, 'msg': '域名不存在'})
    data = request.get_json(silent=True) or {}
    prefix = (data.get('prefix') or '').strip()
    password = data.get('password') or ''
    acct = get_account(dom['id'], prefix)
    if not acct or acct['password'] != password:
        return jsonify({'ok': False, 'msg': '账号或密码错误'})
    token = uuid.uuid4().hex
    _sessions[token] = {'domain': domain, 'prefix': prefix}
    return jsonify({'ok': True, 'token': token, 'username': f"{prefix}@{domain}"})


@bp.get('/api/webmail/<domain>/me')
def wm_me(domain):
    d, prefix, _ = _require_wm_token()
    if not d:
        return jsonify({'ok': False, 'msg': '未登录'})
    return jsonify({'ok': True, 'username': f"{prefix}@{domain}",
                    'email': f"{prefix}@{domain}", 'prefix': prefix})


@bp.get('/api/webmail/<domain>/inbox')
def wm_inbox(domain):
    d, prefix, _ = _require_wm_token()
    if not d:
        return jsonify({'ok': False, 'msg': '未登录'})
    return jsonify({'ok': True, 'data': {
        'new': list_mail(d, prefix, 'new'),
        'cur': list_mail(d, prefix, 'cur'),
    }})


@bp.get('/api/webmail/<domain>/read')
def wm_read(domain):
    d, prefix, _ = _require_wm_token()
    if not d:
        return jsonify({'ok': False, 'msg': '未登录'})
    box = request.args.get('box') or 'new'
    fn = request.args.get('file') or ''
    raw = read_mail_raw(d, prefix, fn, box)
    if raw is None:
        return jsonify({'ok': False, 'msg': '邮件不存在'})
    info = _parse_msg(raw)
    # 提取正文（优先 text/plain，其次 text/html 去标签；缺失 charset 时按 UTF-8 解码）
    body = ''
    try:
        msg = BytesParser(policy=policy.default).parsebytes(raw)
        parts = []
        if msg.is_multipart():
            for part in msg.walk():
                ct = part.get_content_type()
                if ct == 'text/plain':
                    parts.append((part, 0))
                elif ct == 'text/html':
                    parts.append((part, 1))
            parts.sort(key=lambda x: x[1])
        else:
            parts = [(msg, 0)]

        if parts:
            part = parts[0][0]
            raw_payload = part.get_payload(decode=True)
            if raw_payload is None:
                body = part.get_content()
            else:
                cset = part.get_content_charset() or 'utf-8'
                try:
                    body = raw_payload.decode(cset, errors='replace')
                except LookupError:
                    body = raw_payload.decode('utf-8', errors='replace')
                # 若按 us-ascii 解码出现大量替换符，重试 utf-8
                if body.count('\ufffd') > len(body) * 0.1:
                    body = raw_payload.decode('utf-8', errors='replace')
            if parts[0][1] == 1:
                body = re.sub(r'<[^>]+>', ' ', body)
    except Exception:
        body = '(无法解析正文)'
    return jsonify({'ok': True, 'data': {**info, 'body': body}})


@bp.delete('/api/webmail/<domain>/delete')
def wm_delete(domain):
    d, prefix, _ = _require_wm_token()
    if not d:
        return jsonify({'ok': False, 'msg': '未登录'})
    box = request.args.get('box') or 'new'
    fn = request.args.get('file') or ''
    fp = os.path.join(maildir_path(d, prefix), box, fn)
    if os.path.isfile(fp) and '/' not in fn and '..' not in fn:
        os.remove(fp)
    return jsonify({'ok': True, 'msg': '已删除'})


@bp.post('/api/webmail/<domain>/send')
def wm_send(domain):
    d, prefix, _ = _require_wm_token()
    if not d:
        return jsonify({'ok': False, 'msg': '未登录'})
    data = request.get_json(silent=True) or {}
    to_raw = data.get('to') or ''
    to_list = [x.strip() for x in to_raw.replace('，', ',').split(',') if x.strip()]
    if not to_list:
        return jsonify({'ok': False, 'msg': '请填写收件人'})
    acct = get_account(get_domain(d)['id'], prefix)
    ok, msg = send_mail(d, prefix, acct['password'], to_list,
                        data.get('subject') or '', data.get('body') or '')
    return jsonify({'ok': ok, 'msg': msg})


@bp.get('/api/webmail/<domain>/accounts')
def wm_accounts(domain):
    d, prefix, _ = _require_wm_token()
    if not d:
        return jsonify({'ok': False, 'msg': '未登录'})
    if prefix != 'admin':
        return jsonify({'ok': False, 'msg': '仅管理员可管理账号'})
    dom = get_domain(d)
    accts = db.fetchall(
        "SELECT * FROM email_accounts WHERE domain_id=? AND account_type='mailbox' ORDER BY id",
        (dom['id'],))
    for a in accts:
        a['email'] = f"{a['prefix']}@{d}"
    return jsonify({'ok': True, 'data': accts})


@bp.post('/api/webmail/<domain>/accounts')
def wm_create_account(domain):
    d, prefix, _ = _require_wm_token()
    if not d:
        return jsonify({'ok': False, 'msg': '未登录'})
    if prefix != 'admin':
        return jsonify({'ok': False, 'msg': '仅管理员可创建账号'})
    dom = get_domain(d)
    data = request.get_json(silent=True) or {}
    new_prefix = (data.get('prefix') or '').strip()
    password = data.get('password') or ''
    if not re.match(r'^[a-zA-Z0-9._-]{1,64}$', new_prefix):
        return jsonify({'ok': False, 'msg': '前缀格式不正确'})
    if len(password) < 6:
        return jsonify({'ok': False, 'msg': '密码至少 6 位'})
    if get_account(dom['id'], new_prefix):
        return jsonify({'ok': False, 'msg': '前缀已存在'})
    from .emailmgr import ensure_maildir, apply_mail_config
    ensure_maildir(d, new_prefix)
    db.execute(
        "INSERT INTO email_accounts(domain_id,prefix,password,account_type,target) "
        "VALUES(?,?,?,?,?)", (dom['id'], new_prefix, password, 'mailbox', ''))
    apply_mail_config()
    return jsonify({'ok': True, 'msg': '账号创建成功'})


@bp.delete('/api/webmail/<domain>/accounts/<int:aid>')
def wm_delete_account(domain, aid):
    d, prefix, _ = _require_wm_token()
    if not d:
        return jsonify({'ok': False, 'msg': '未登录'})
    if prefix != 'admin':
        return jsonify({'ok': False, 'msg': '仅管理员可删除账号'})
    a = db.fetchone("SELECT * FROM email_accounts WHERE id=?", (aid,))
    if not a:
        return jsonify({'ok': False, 'msg': '账号不存在'})
    import shutil
    shutil.rmtree(maildir_path(d, a['prefix']), ignore_errors=True)
    db.execute("DELETE FROM email_accounts WHERE id=?", (aid,))
    from .emailmgr import apply_mail_config
    apply_mail_config()
    return jsonify({'ok': True, 'msg': '账号已删除'})
