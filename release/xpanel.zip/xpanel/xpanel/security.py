# -*- coding: utf-8 -*-
"""
XPanel 希旭面板 - 安全组（防火墙端口管理）
兼容 iptables / ufw / firewalld；无 root 环境自动进入模拟模式
"""
import os
import re
from flask import Blueprint, request, jsonify
from . import utils
from .auth import login_required

bp = Blueprint('security', __name__)

# 非 root / 测试环境内存模拟
_FAKE_RULES = {}


def _have_root():
    return os.geteuid() == 0


def _fake():
    return not _have_root()


def listening_ports():
    """读取系统当前监听的 TCP 端口"""
    ports = set()
    for f in ('/proc/net/tcp', '/proc/net/tcp6'):
        try:
            with open(f) as fh:
                for line in fh.readlines()[1:]:
                    parts = line.split()
                    if len(parts) < 4:
                        continue
                    st = int(parts[3], 16)
                    if st != 0x0A:  # LISTEN
                        continue
                    port = int(parts[1].split(':')[1], 16)
                    if 0 < port < 65536:
                        ports.add(port)
        except Exception:
            continue
    return sorted(ports)


def current_rules():
    """读取 iptables INPUT 链中放行的端口规则"""
    rules = []
    if _fake():
        for k, v in _FAKE_RULES.items():
            rules.append({'port': v['port'], 'proto': v['proto'],
                          'comment': v['comment'], 'fake': True})
        return rules
    code, out, _ = utils.run_cmd("iptables -L INPUT -n --line-numbers 2>/dev/null")
    if code != 0:
        return rules
    for line in out.splitlines():
        m = re.search(r'dpt:(\d+)', line)
        if not m:
            continue
        port = int(m.group(1))
        proto = 'tcp' if 'tcp' in line.lower() else ('udp' if 'udp' in line.lower() else 'tcp')
        rules.append({'port': port, 'proto': proto, 'comment': '', 'fake': False})
    return rules


@bp.get('/api/security/status')
@login_required
def status():
    return jsonify({'ok': True, 'data': {
        'fake': _fake(),
        'rules': current_rules(),
        'listening': listening_ports(),
    }})


@bp.post('/api/security/open')
@login_required
def open_port():
    d = request.get_json(silent=True) or {}
    try:
        port = int(d.get('port'))
    except Exception:
        return jsonify({'ok': False, 'msg': '端口必须是数字'})
    if not (1 <= port <= 65535):
        return jsonify({'ok': False, 'msg': '端口范围 1-65535'})
    proto = d.get('proto') or 'tcp'
    if proto not in ('tcp', 'udp', 'tcp+udp'):
        return jsonify({'ok': False, 'msg': '协议只能是 tcp / udp / tcp+udp'})
    comment = (d.get('comment') or '').strip()
    if _fake():
        plist = []
        if proto in ('tcp', 'tcp+udp'):
            plist.append(('tcp', port))
        if proto in ('udp', 'tcp+udp'):
            plist.append(('udp', port))
        for p in plist:
            _FAKE_RULES[f"{p[0]}:{p[1]}"] = {'port': p[1], 'proto': p[0], 'comment': comment}
        return jsonify({'ok': True, 'msg': f'已放行 {port}（模拟模式）'})
    # 真实 iptables
    plist = []
    if proto in ('tcp', 'tcp+udp'):
        plist.append(('tcp', port))
    if proto in ('udp', 'tcp+udp'):
        plist.append(('udp', port))
    for p in plist:
        c, _, err = utils.run_cmd(
            f"iptables -C INPUT -p {p[0]} --dport {p[1]} -j ACCEPT 2>/dev/null; "
            f"iptables -A INPUT -p {p[0]} --dport {p[1]} -j ACCEPT")
        if c != 0:
            return jsonify({'ok': False, 'msg': f'iptables 操作失败: {err or "无权限"}'})
    utils.run_cmd("mkdir -p /etc/iptables && (iptables-save > /etc/iptables/rules.v4 2>/dev/null || true)")
    return jsonify({'ok': True, 'msg': f'已放行端口 {port}/{proto}'})


@bp.post('/api/security/close')
@login_required
def close_port():
    d = request.get_json(silent=True) or {}
    try:
        port = int(d.get('port'))
    except Exception:
        return jsonify({'ok': False, 'msg': '端口必须是数字'})
    proto = d.get('proto') or 'tcp'
    if _fake():
        _FAKE_RULES.pop(f"{proto}:{port}", None)
        _FAKE_RULES.pop(('tcp' if proto != 'tcp' else 'udp') + f":{port}", None)
        return jsonify({'ok': True, 'msg': f'已移除 {port}（模拟模式）'})
    for p in (('tcp', port), ('udp', port)):
        utils.run_cmd(f"iptables -D INPUT -p {p[0]} --dport {p[1]} -j ACCEPT 2>/dev/null")
    utils.run_cmd("mkdir -p /etc/iptables && (iptables-save > /etc/iptables/rules.v4 2>/dev/null || true)")
    return jsonify({'ok': True, 'msg': f'已移除端口 {port}/{proto}'})
