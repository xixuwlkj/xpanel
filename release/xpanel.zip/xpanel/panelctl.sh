#!/bin/bash
# ============================================================
#  XPanel 希旭面板 管理脚本
#  用法: bash panelctl.sh {start|stop|restart|status|resetpwd|uninstall}
# ============================================================
INSTALL_DIR="/www/server/xpanel"
SERVICE="xpanel"

case "$1" in
  start)
    systemctl start $SERVICE && echo -e "\033[0;32m面板已启动\033[0m" ;;
  stop)
    systemctl stop $SERVICE && echo -e "\033[0;33m面板已停止\033[0m" ;;
  restart)
    systemctl restart $SERVICE && echo -e "\033[0;32m面板已重启\033[0m" ;;
  status)
    systemctl status $SERVICE --no-pager ;;
  resetpwd)
    read -p "请输入新密码（至少6位）: " NEWPASS
    if [ ${#NEWPASS} -lt 6 ]; then echo -e "\033[0;31m密码太短\033[0m"; exit 1; fi
    python3 -c "
import json, os
p = '$INSTALL_DIR/data/panel.json'
cfg = json.load(open(p))
cfg['admin_password'] = '$NEWPASS'
json.dump(cfg, open(p, 'w'), ensure_ascii=False, indent=2)
import sys; sys.path.insert(0, '$INSTALL_DIR')
from xpanel import db, utils, config
db.init_db()
user = db.fetchone('SELECT * FROM users WHERE username=?', (cfg['admin_user'],))
if user:
    db.execute('UPDATE users SET password_hash=? WHERE username=?', (utils.hash_password('$NEWPASS'), cfg['admin_user']))
print('密码已重置为: $NEWPASS')
" && systemctl restart $SERVICE
    echo -e "\033[0;32m已重启面板，请使用新密码登录\033[0m" ;;
  uninstall)
    echo -e "\033[0;31m正在卸载 XPanel（保留站点与邮件数据）...\033[0m"
    systemctl stop $SERVICE 2>/dev/null
    systemctl disable $SERVICE 2>/dev/null
    rm -f /etc/systemd/system/xpanel.service
    systemctl daemon-reload
    read -p "是否删除安装目录 $INSTALL_DIR ? (y/N): " ans
    if [ "$ans" = "y" ] || [ "$ans" = "Y" ]; then rm -rf "$INSTALL_DIR"; fi
    echo "卸载完成" ;;
  *)
    echo "用法: bash panelctl.sh {start|stop|restart|status|resetpwd|uninstall}"
    ;;
esac
