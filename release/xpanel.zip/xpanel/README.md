# XPanel 希旭面板

一个类似宝塔面板的服务器管理面板，支持 **网站管理（PHP / Python / 静态）**、**节点管理（VMess / VLESS / Trojan）**、**邮箱服务（转发 / 独立邮箱 + 网页邮箱）**，一键 SSH 命令安装，安装完成自动在终端打印访问地址、用户名和密码。

---

## 一、一键安装

### 方式一：在线一键安装（GitHub）

把项目发布到 GitHub 后（见 `xpanel-github/README.md` 发布指南），用户只需要一条命令：

```bash
bash <(curl -sSL https://raw.githubusercontent.com/你的用户名/仓库名/main/sh/xp.sh)
```

安装完成后终端自动打印 **访问地址 + 用户名 + 随机密码**。

### 方式二：下载后本地安装

在 **root** 权限下执行（支持 Ubuntu / Debian / CentOS）：

```bash
wget -O xpanel.zip "你的下载地址/xpanel.zip"
unzip xpanel.zip && cd xpanel
bash install.sh
```

安装完成后终端会打印：

```
============================================================
   ✅ XPanel 希旭面板 安装完成！
============================================================

  访问地址:  http://你的服务器IP:8888
  内网地址:  http://内网IP:8888

  用户名:    admin
  密  码:    xxxxxxxx

  请尽快登录面板并在「设置」中修改密码！
============================================================
```

> 安装脚本**只安装面板本体**（宝塔式）。**Nginx / PHP / MySQL / Postfix / Dovecot / Xray** 等组件**不强制安装**，登录面板后首页会自动弹出「软件商店」询问是否安装，按需一键安装。

```bash
PANEL_PORT=9000 bash install.sh      # 指定端口
ADMIN_PASS=MyPass123 bash install.sh # 指定初始密码
```

### 常用管理命令

```bash
systemctl status xpanel       # 查看面板状态
systemctl restart xpanel      # 重启面板
bash /www/server/xpanel/panelctl.sh resetpwd    # 重置面板密码
bash /www/server/xpanel/panelctl.sh uninstall   # 卸载
```

---

## 二、功能总览

| 模块 | 功能 |
|---|---|
| 首页 | 服务器实时监控：CPU / 内存 / 磁盘 / 网速 / 负载 / 运行时长 / 服务状态 / 资源趋势图 |
| 网站 | 创建 PHP 网站、Python 项目（填启动命令，如 `python3 app.py` / gunicorn，自动注册 systemd，域名可选，无域名用 IP:端口访问）、静态站点；自动生成 Nginx 配置并热重载；查看/重新生成配置、启停、删除 |
| 节点 | 一键安装 Xray 核心；创建 VMess / VLESS / Trojan 节点（TCP / WS / gRPC / TLS）；自动生成客户端分享链接（vmess:// 等，可直接导入 v2rayN / Shadowrocket / Nekoray）；启停节点与核心 |
| 邮箱 | 两种模式：**邮箱转发** 与 **独立邮箱（网页邮箱）**，自动生成 Postfix/Dovecot 配置；独立邮箱自动生成 admin 账号密码并展示，网页邮箱支持在线收信 / 发信 / 账号管理 |
| 文件 | **文件管理**：浏览 / 上传 / 下载 / 新建文件 / 新建目录 / 重命名 / 删除 / 在线编辑，内置路径保护 |
| 安全 | **安全组**：放行 / 移除端口（iptables），列出系统当前监听端口并标注放行状态 |
| 终端 | **Web 终端**：浏览器内 bash 交互式终端（xterm.js，无需 SSH） |
| 软件 | **软件商店**：登录后弹窗检测未安装组件（Nginx / PHP / MySQL / Postfix / Dovecot / Xray），按需后台一键安装，实时显示进度；安装失败可点「日志」查看原因 |
| 设置 | 修改面板密码 |

---

## 三、邮箱服务：转发 与 独立邮箱 的区别

### 1. 邮箱转发（Forward）

- 你配置一个**域名**（如 `mail.my.com`），再填一个**收件邮箱**（如 `me@qq.com`）。
- 在面板里创建**邮箱前缀**（如 `sales`、`help`、`info`）。
- 之后别人往 **`任意前缀@mail.my.com`** 发信，Postfix 会把这封信**原样转发**到你的收件邮箱 `me@qq.com`。
- 特点：**不占本机磁盘空间、不需要管理多个邮箱账号**，适合"一个域名挂一堆前缀，全部收进自己的主邮箱"的场景。

```
配置: 域名 mail.my.com → 收件邮箱 me@qq.com
前缀: sales  →  别人发 sales@mail.my.com  →  转发到 me@qq.com
前缀: info   →  别人发 info@mail.my.com   →  转发到 me@qq.com
```

### 2. 独立邮箱（Standalone + 网页邮箱）

- 你配置一个**域名**（如 `mail.example.net`），系统会**自动生成一个网页邮箱管理页**（`http://面板地址:8888/webmail/mail.example.net`，也支持用域名直接访问）。
- 在网页邮箱里可以**创建任意前缀的邮箱账号**（如 `bob@mail.example.net`），并设置密码。
- 每个账号可以**网页在线收信（收件箱/读信/删信）和在线发信（写信/发送）**。
- 特点：**真正的独立邮箱**，每个前缀有独立的收件箱、独立的密码、可在线收发，相当于自建了一个完整邮件系统（底层 Postfix + Dovecot + Maildir）。

```
配置: 域名 mail.example.net → 自动生成网页邮箱
账号: bob@mail.example.net（密码由你设置）
网页: http://面板地址:8888/webmail/mail.example.net → 登录后在线收发信
```

### 使用前置条件

- 把域名的 **MX 记录** 解析到本服务器 IP，并在服务器**开放 25 端口**（入站收信）、587（发信认证）。
- 云厂商（阿里云/腾讯云/华为云等）的安全组也要放行 25 端口。

---

## 四、节点（VMess）使用说明

1. 在「节点」页点击 **一键安装 Xray 核心**（需服务器能访问 GitHub）。
2. 点击 **+ 创建节点**，填名称、端口，选择协议（VMess/VLESS/Trojan）、传输方式（TCP/WS/gRPC）、WS 路径、是否 TLS。
3. 创建后点击节点「配置/链接」，复制 **分享链接**（`vmess://...`）。
4. 把链接导入 v2rayN / Nekoray / Shadowrocket / v2rayNG 等客户端即可。
5. 客户端连的地址填**服务器公网 IP**，端口为节点端口。

> 放行端口：`firewall-cmd --add-port=10086/tcp`（CentOS）或 `ufw allow 10086/tcp`（Ubuntu）。

---

## 五、网站使用说明

- **PHP 网站**：选"PHP 网站"+ PHP 版本，自动创建站点目录、写入 `index.php`、生成 Nginx fastcgi 配置。
- **Python 项目**：选"Python 项目"+ 框架（Flask/FastAPI）+ 内部端口，面板自动建 venv、装依赖、写 gunicorn + systemd 服务、生成 Nginx 反向代理。
- **静态站点**：纯静态 HTML，自动生成 `index.html`。
- 站点目录默认在 `/www/wwwroot/<域名>/`，文件管理与源码查看可在面板中浏览。

---

## 六、目录结构

```
/www/server/xpanel/
├── install.sh                 # 一键安装脚本
├── panelctl.sh                # 面板管理脚本（start/stop/restart/resetpwd）
├── requirements.txt           # Python 依赖
├── xpanel/                    # 后端代码
│   ├── app.py                 # 主入口
│   ├── config.py              # 配置（支持 env / panel.json 覆盖）
│   ├── auth.py                # 认证
│   ├── db.py                  # SQLite 数据层
│   ├── system.py              # 系统监控
│   ├── sites.py               # 网站管理
│   ├── nodes.py               # 节点管理
│   ├── emailmgr.py            # 邮箱管理
│   ├── webmail.py             # 网页邮箱
│   ├── files.py               # 文件管理
│   ├── security.py            # 安全组（防火墙）
│   └── terminal.py            # Web 终端
├── static/                    # 前端（宝塔风格 SPA）
├── templates/                 # 配置模板
└── data/                      # 运行时数据（panel.json / panel.db / 日志）
```

---

## 七、常见问题

**Q: 面板端口是多少？**
A: 默认 `8888`。可通过 `PANEL_PORT=xxxx bash install.sh` 或修改 `data/panel.json` 里的 `port`。

**Q: 忘记面板密码怎么办？**
A: `bash /www/server/xpanel/panelctl.sh resetpwd`，按提示输入新密码即可。

**Q: 邮件收不到？**
A: 检查：① 域名 MX 记录是否指向本机；② 服务器与云安全组是否放行 25 端口；③ `systemctl status postfix` 是否运行。

**Q: 节点连不上？**
A: 检查：① Xray 是否已安装并运行；② 节点端口是否放行；③ 客户端地址是否填了公网 IP；④ WS 路径是否与创建时一致。

**Q: 非 root 环境能跑吗？**
A: 面板本身支持通过环境变量指定数据目录运行（开发模式），但完整功能（写 Nginx 配置、systemd、Postfix）需要 root。生产环境请用 root 安装。

---

## 八、环境变量（开发 / 自定义部署）

| 变量 | 默认 | 说明 |
|---|---|---|
| `XPANEL_PORT` | 8888 | 面板端口 |
| `XPANEL_WWW_ROOT` | /www/wwwroot | 网站根目录 |
| `XPANEL_NGINX_CONF_DIR` | /www/server/nginx/conf/vhost | Nginx 站点配置目录 |
| `XPANEL_MAIL_ROOT` | /var/mail/vhosts | 邮箱 Maildir 根目录 |
| `XPANEL_POSTFIX_*` | /etc/postfix/* | Postfix 相关文件路径 |
| `XPANEL_DOVECOT_*` | /etc/dovecot/* | Dovecot 相关文件路径 |
| `XPANEL_ADMIN_USER/PASS` | admin/xpanel888 | 初始管理员 |
