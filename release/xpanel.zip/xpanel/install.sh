#!/bin/bash
# ============================================================
#  XPanel 希旭面板 一键安装脚本
#  用法（root 下执行）:
#     bash install.sh
#  可选环境变量:
#     PANEL_PORT=8888         面板端口
#     ADMIN_USER=admin        管理员用户名
#     ADMIN_PASS=xxxx         管理员密码（不填则随机生成）
#     NO_NGINX=1              不安装 Nginx
#     NO_PHP=1                不安装 PHP-FPM
#     NO_MAIL=1               不安装 Postfix+Dovecot
#  容器/测试环境:
#     XPANEL_INSTALL_DIR=/xx  安装目录（默认 /www/server/xpanel）
#     XPANEL_SKIP_ROOT=1      跳过 root 检查（Docker/CI 用）
#     XPANEL_SKIP_SYSTEMD=1   跳过 systemctl 操作（Docker/CI 用）
#     XPANEL_WWW_ROOT=/xx     网站根目录（默认 /www/wwwroot）
#     XPANEL_MAIL_ROOT_DIR=/xx  邮件根目录（默认 /var/mail/vhosts）
# ============================================================
set -e

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'

PANEL_PORT="${PANEL_PORT:-8888}"
ADMIN_USER="${ADMIN_USER:-admin}"
INSTALL_DIR="${XPANEL_INSTALL_DIR:-/www/server/xpanel}"
WWW_ROOT="${XPANEL_WWW_ROOT:-/www/wwwroot}"
NGINX_VHOST_DIR="${XPANEL_NGINX_VHOST_DIR:-/www/server/nginx/conf/vhost}"
MAIL_ROOT_DIR="${XPANEL_MAIL_ROOT_DIR:-/var/mail/vhosts}"

echo -e "${BLUE}============================================${NC}"
echo -e "${BLUE}   XPanel 希旭面板 安装程序 v1.0.0${NC}"
echo -e "${BLUE}============================================${NC}"

# ---------- 1. 环境检查 ----------
if [ "$(id -u)" != "0" ] && [ -z "$XPANEL_SKIP_ROOT" ]; then
  echo -e "${RED}[错误] 请使用 root 用户执行安装（sudo -i 或 sudo bash install.sh）${NC}"
  exit 1
fi

if [ -d "$INSTALL_DIR" ]; then
  echo -e "${YELLOW}[提示] 检测到已有安装目录 $INSTALL_DIR，将覆盖更新文件（数据保留）${NC}"
fi

# ---------- 2. 系统检测 ----------
if [ -f /etc/debian_version ] || [ -f /etc/os-release ] && grep -qiE 'ubuntu|debian' /etc/os-release; then
  OS_FAMILY="debian"
  PKG_INSTALL="apt-get install -y"
  PKG_UPDATE="apt-get update"
elif [ -f /etc/redhat-release ] || grep -qiE 'centos|redhat|fedora|rocky|almalinux' /etc/os-release 2>/dev/null; then
  OS_FAMILY="rhel"
  PKG_INSTALL="yum install -y"
  PKG_UPDATE="yum makecache"
else
  echo -e "${RED}[错误] 暂不支持该系统，支持 Ubuntu/Debian/CentOS${NC}"
  exit 1
fi
echo -e "${GREEN}[1/5] 系统: $OS_FAMILY ${NC}"

# ---------- 3. 基础依赖 ----------
echo -e "${GREEN}[2/5] 安装基础依赖 (python3 / curl / nginx ...)${NC}"
$PKG_UPDATE >/dev/null 2>&1 || true
$PKG_INSTALL curl wget python3 python3-pip python3-venv openssl net-tools >/dev/null 2>&1 || true

if [ -z "$NO_NGINX" ] && ! command -v nginx >/dev/null 2>&1; then
  echo "  安装 Nginx ..."
  $PKG_INSTALL nginx >/dev/null 2>&1 || true
fi

if [ -z "$NO_PHP" ] && ! command -v php-fpm >/dev/null 2>&1; then
  echo "  安装 PHP-FPM (默认 8.1，Ubuntu 自动装 8.3/8.1) ..."
  if [ "$OS_FAMILY" = "debian" ]; then
    $PKG_INSTALL php-fpm php-cli php-mysql php-curl php-gd php-mbstring php-xml >/dev/null 2>&1 || true
  else
    $PKG_INSTALL epel-release >/dev/null 2>&1 || true
    $PKG_INSTALL php-fpm php-cli php-mysqlnd php-curl php-gd php-mbstring php-xml >/dev/null 2>&1 || true
  fi
fi

if [ -z "$NO_MAIL" ] && { ! command -v postfix >/dev/null 2>&1 || ! command -v dovecot >/dev/null 2>&1; }; then
  echo "  安装邮件服务 Postfix + Dovecot ..."
  if [ "$OS_FAMILY" = "debian" ]; then
    DEBIAN_FRONTEND=noninteractive $PKG_INSTALL postfix dovecot-imapd dovecot-pop3d >/dev/null 2>&1 || true
  else
    $PKG_INSTALL postfix dovecot >/dev/null 2>&1 || true
  fi
fi

# ---------- 4. 拷贝面板 ----------
echo -e "${GREEN}[3/5] 部署面板到 $INSTALL_DIR${NC}"
mkdir -p "$INSTALL_DIR"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cp -r "$SCRIPT_DIR/xpanel" "$INSTALL_DIR/"
cp -r "$SCRIPT_DIR/static" "$INSTALL_DIR/"
cp -r "$SCRIPT_DIR/templates" "$INSTALL_DIR/"

# 创建虚拟环境并安装依赖
if [ ! -d "$INSTALL_DIR/venv" ]; then
  python3 -m venv "$INSTALL_DIR/venv"
fi
"$INSTALL_DIR/venv/bin/pip" install --upgrade pip -q
"$INSTALL_DIR/venv/bin/pip" install flask psutil requests -q

# ---------- 5. 初始化配置 ----------
echo -e "${GREEN}[4/5] 生成管理员账号与配置${NC}"
mkdir -p "$INSTALL_DIR/data"
if [ -z "$ADMIN_PASS" ]; then
  ADMIN_PASS="$(openssl rand -hex 4)"
  echo -e "${YELLOW}  已随机生成管理员密码${NC}"
fi
cat > "$INSTALL_DIR/data/panel.json" <<EOF
{
  "port": $PANEL_PORT,
  "admin_user": "$ADMIN_USER",
  "admin_password": "$ADMIN_PASS",
  "www_root": "$WWW_ROOT",
  "mail_root": "$MAIL_ROOT_DIR"
}
EOF

# 网站目录
mkdir -p "$WWW_ROOT"
# Nginx 站点目录（宝塔风格）
mkdir -p "$NGINX_VHOST_DIR"
# 邮件目录
mkdir -p "$MAIL_ROOT_DIR"

# ---------- 6. 注册 systemd 服务 ----------
if [ -z "$XPANEL_SKIP_SYSTEMD" ]; then
echo -e "${GREEN}[5/5] 注册并启动服务${NC}"
cat > /etc/systemd/system/xpanel.service <<EOF
[Unit]
Description=XPanel Server Panel (希旭面板)
After=network.target
[Service]
Type=simple
WorkingDirectory=$INSTALL_DIR
Environment=XPANEL_PORT=$PANEL_PORT
ExecStart=$INSTALL_DIR/venv/bin/python3 -m xpanel.app
Restart=always
RestartSec=3
[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable xpanel >/dev/null 2>&1 || true
systemctl restart xpanel
# 开机自启相关系统服务
systemctl enable nginx >/dev/null 2>&1 || true
systemctl restart nginx >/dev/null 2>&1 || true
if command -v postfix >/dev/null 2>&1; then
  systemctl enable postfix dovecot >/dev/null 2>&1 || true
  systemctl restart postfix dovecot >/dev/null 2>&1 || true
fi
else
  echo -e "${GREEN}[5/5] 跳过 systemd（XPANEL_SKIP_SYSTEMD=1，容器/测试环境）${NC}"
fi
# ---------- 7. 输出安装结果 ----------
sleep 2
IP=$(curl -s --max-time 3 https://api.ipify.org 2>/dev/null || hostname -I | awk '{print $1}')
if [ -z "$IP" ]; then IP="你的服务器IP"; fi

echo ""
echo -e "${GREEN}============================================================${NC}"
echo -e "${GREEN}   ✅ XPanel 希旭面板 安装完成！${NC}"
echo -e "${GREEN}============================================================${NC}"
echo ""
echo -e "${YELLOW}  访问地址:${NC}  http://$IP:$PANEL_PORT"
echo -e "${YELLOW}  内网地址:${NC}  http://$(hostname -I 2>/dev/null | awk '{print $1}'):$PANEL_PORT"
echo ""
echo -e "${YELLOW}  用户名:${NC}    $ADMIN_USER"
echo -e "${YELLOW}  密  码:${NC}    $ADMIN_PASS"
echo ""
echo -e "${BLUE}  请尽快登录面板并在「设置」中修改密码！${NC}"
echo ""
echo -e "${GREEN}  常用管理命令:${NC}"
echo "    systemctl status xpanel    # 查看面板状态"
echo "    systemctl restart xpanel   # 重启面板"
echo "    bash $INSTALL_DIR/panelctl.sh resetpwd   # 重置密码"
echo ""
echo -e "${YELLOW}  功能: 网站管理(PHP/Python/静态) · 节点管理(VMess/VLESS/Trojan) · 邮箱服务(转发/独立邮箱+网页邮箱)${NC}"
echo -e "${GREEN}============================================================${NC}"
