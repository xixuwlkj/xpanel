/* ===== XPanel 希旭面板 - 前端逻辑 ===== */
'use strict';

/* 调试用：全局错误捕获 */
window.onerror = function (msg, src, line) {
  var v = document.getElementById('view');
  if (v) v.innerHTML = '<div class="msg err">JS错误: ' + esc(msg) + ' @line ' + line + '</div>';
  return false;
};
window.addEventListener('unhandledrejection', function (e) {
  var v = document.getElementById('view');
  if (v) v.innerHTML = '<div class="msg err">Promise错误: ' + esc(String(e.reason)) + '</div>';
});

/* ---------- API ---------- */
const API = {
  token: localStorage.getItem('xp_token') || '',
  async req(method, url, body) {
    const opt = { method, headers: { 'Content-Type': 'application/json' } };
    if (this.token) opt.headers['X-Panel-Token'] = this.token;
    if (body) opt.body = JSON.stringify(body);
    const resp = await fetch(url, opt);
    let data;
    try { data = await resp.json(); } catch (e) { data = { ok: false, msg: '服务器响应异常' }; }
    if (resp.status === 401) { App.forceLogout(); }
    return data;
  },
  get(url) { return this.req('GET', url); },
  post(url, body) { return this.req('POST', url, body); },
  del(url) { return this.req('DELETE', url); },
};

/* ---------- 工具 ---------- */
function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g,
    c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
function fmtSize(n) {
  n = Number(n) || 0;
  for (const u of ['B', 'KB', 'MB', 'GB', 'TB']) { if (n < 1024 || u === 'TB') return n.toFixed(1) + ' ' + u; n /= 1024; }
}
function fmtUptime(sec) {
  const d = Math.floor(sec / 86400), h = Math.floor(sec % 86400 / 3600), m = Math.floor(sec % 3600 / 60);
  return (d ? d + '天 ' : '') + h + '时 ' + m + '分';
}
function fmtTime(ts) { return new Date(ts * 1000).toLocaleString(); }

function toast(msg, type) {
  const el = document.getElementById('toast');
  el.textContent = msg; el.className = 'toast ' + (type || '');
  clearTimeout(el._t);
  el._t = setTimeout(() => el.classList.add('hidden'), 2600);
}

async function copyText(text, tip) {
  try {
    await navigator.clipboard.writeText(text);
  } catch (e) {
    const ta = document.createElement('textarea');
    ta.value = text; document.body.appendChild(ta); ta.select();
    document.execCommand('copy'); ta.remove();
  }
  toast(tip || '已复制');
}

/* ---------- 模态框 ---------- */
const Modal = {
  open(title, bodyHtml, footHtml) {
    document.getElementById('modalTitle').textContent = title;
    document.getElementById('modalBody').innerHTML = bodyHtml;
    document.getElementById('modalMask').classList.remove('hidden');
    if (footHtml) {
      let f = document.querySelector('.modal-foot');
      if (!f) { f = document.createElement('div'); f.className = 'modal-foot'; document.querySelector('.modal').appendChild(f); }
      f.innerHTML = footHtml;
    }
  },
  close() { document.getElementById('modalMask').classList.add('hidden'); },
};
document.getElementById('modalMask').addEventListener('click', e => {
  if (e.target.id === 'modalMask') Modal.close();
});

/* ---------- 图表（Canvas 折线图） ---------- */
function drawLineChart(canvasId, labels, series) {
  const cv = document.getElementById(canvasId);
  if (!cv) return;
  const dpr = window.devicePixelRatio || 1;
  const W = cv.clientWidth, H = cv.clientHeight;
  cv.width = W * dpr; cv.height = H * dpr;
  const ctx = cv.getContext('2d');
  ctx.scale(dpr, dpr);
  ctx.clearRect(0, 0, W, H);
  if (!series.length || !series[0].data.length) return;

  const pad = { l: 40, r: 12, t: 14, b: 24 };
  const iw = W - pad.l - pad.r, ih = H - pad.t - pad.b;
  let max = 100;
  series.forEach(s => s.data.forEach(v => { if (v > max) max = v; }));
  max = Math.ceil(max / 10) * 10 || 100;

  // 网格
  ctx.strokeStyle = '#eef1f5'; ctx.lineWidth = 1; ctx.fillStyle = '#8a94a3'; ctx.font = '11px sans-serif';
  for (let i = 0; i <= 4; i++) {
    const y = pad.t + ih - ih * i / 4;
    ctx.beginPath(); ctx.moveTo(pad.l, y); ctx.lineTo(W - pad.r, y); ctx.stroke();
    ctx.textAlign = 'right'; ctx.fillText(Math.round(max * i / 4), pad.l - 6, y + 4);
  }
  const step = iw / (labels.length - 1 || 1);
  labels.forEach((lb, i) => {
    ctx.textAlign = 'center';
    ctx.fillText(lb, pad.l + step * i, H - 8);
  });

  series.forEach(s => {
    ctx.beginPath();
    s.data.forEach((v, i) => {
      const x = pad.l + step * i, y = pad.t + ih - (v / max) * ih;
      i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
    });
    ctx.strokeStyle = s.color; ctx.lineWidth = 2; ctx.stroke();
    // 面积
    ctx.lineTo(pad.l + step * (s.data.length - 1), pad.t + ih);
    ctx.lineTo(pad.l, pad.t + ih); ctx.closePath();
    ctx.fillStyle = s.color + '22'; ctx.fill();
  });
}

/* ---------- 页面标题 ---------- */
const TITLES = { dashboard: '首页', sites: '网站', nodes: '节点', email: '邮箱', settings: '设置' };

/* ---------- 首页 ---------- */
async function renderDashboard() {
  document.getElementById('view').innerHTML = '<div class="empty">加载中...</div>';
  const [ov, svc] = await Promise.all([API.get('/api/system/overview'), API.get('/api/system/services')]);
  if (!ov.ok) return;
  const o = ov.data;
  let stats = `
    <div class="stat-grid">
      <div class="stat"><div class="s-label">CPU 使用率</div><div class="s-val">${o.cpu_percent.toFixed(1)}<small>%</small></div>
        <div class="bar blue"><i style="width:${o.cpu_percent}%"></i></div>
        <div class="s-sub">${o.cpu_count} 核 · 负载 ${o.load.join(' / ')}</div></div>
      <div class="stat"><div class="s-label">内存使用率</div><div class="s-val">${o.mem.percent.toFixed(1)}<small>%</small></div>
        <div class="bar orange"><i style="width:${o.mem.percent}%"></i></div>
        <div class="s-sub">${fmtSize(o.mem.used)} / ${fmtSize(o.mem.total)}</div></div>
      <div class="stat"><div class="s-label">磁盘使用率</div><div class="s-val">${o.disk.percent.toFixed(1)}<small>%</small></div>
        <div class="bar green"><i style="width:${o.disk.percent}%"></i></div>
        <div class="s-sub">${fmtSize(o.disk.used)} / ${fmtSize(o.disk.total)}</div></div>
      <div class="stat"><div class="s-label">实时网速</div><div class="s-val"><small>↓</small>${o.net.down}<small> ↑</small>${o.net.up}</div>
        <div class="s-sub">运行 ${fmtUptime(o.uptime)}</div></div>
    </div>
    <div class="dash-grid">
      <div class="card"><h3>资源使用趋势</h3><canvas id="resChart" class="chart-box"></canvas></div>
      <div class="card"><h3>服务状态</h3><div id="svcList"></div>
        <div class="mt8"><a class="link" onclick="renderSites()">管理网站 →</a></div></div>
    </div>
    <div class="card"><h3>系统信息</h3>
      <table class="tbl">
        <tr><td style="width:140px">主机名</td><td class="mono">${esc(o.hostname)}</td></tr>
        <tr><td>操作系统</td><td class="mono">${esc(o.os)}</td></tr>
        <tr><td>Python 版本</td><td class="mono">${esc(o.python)}</td></tr>
        <tr><td>面板地址</td><td class="mono">http://${location.host}</td></tr>
      </table></div>`;
  document.getElementById('view').innerHTML = stats;

  // 服务状态
  let sv = '';
  (svc.data || []).forEach(s => {
    const st = !s.installed ? '<span class="badge gray">未安装</span>'
      : s.running ? '<span class="badge on">运行中</span>' : '<span class="badge off">已停止</span>';
    sv += `<div class="svc-item"><span>${esc(s.name)} <small style="color:#9aa4b2">${esc(s.desc)}</small></span>${st}</div>`;
  });
  document.getElementById('svcList').innerHTML = sv;

  // 图表
  const hist = await API.get('/api/system/cpu_history');
  const labels = [], cpu = [], mem = [];
  (hist.data || []).forEach((d, i) => { labels.push(i % 5 === 0 ? i + 's' : ''); cpu.push(d.cpu); mem.push(d.mem); });
  drawLineChart('resChart', labels, [
    { color: '#2a7de1', data: cpu },
    { color: '#22a06b', data: mem },
  ]);
}

/* ---------- 网站 ---------- */
async function renderSites() {
  document.getElementById('view').innerHTML = '<div class="empty">加载中...</div>';
  const r = await API.get('/api/sites');
  if (!r.ok) return;
  const rows = (r.data || []).map(s => {
    const typeBadge = s.site_type === 'php' ? '<span class="badge info">PHP ' + esc(s.php_version) + '</span>'
      : s.site_type === 'python' ? '<span class="badge warn">Python :' + s.port + '</span>'
      : '<span class="badge gray">静态</span>';
    return `<tr>
      <td><b>${esc(s.name)}</b><br><span class="mono" style="color:#7c8aa0">${esc(s.domain)}</span></td>
      <td>${typeBadge}</td>
      <td>${s.enabled ? '<span class="badge on">运行</span>' : '<span class="badge off">停用</span>'}</td>
      <td>${fmtTime(new Date(s.created_at.replace(/-/g, '/')).getTime() / 1000)}</td>
      <td class="actions">
        <a class="btn small" onclick="siteDetail(${s.id})">配置</a>
        <a class="btn small" onclick="siteToggle(${s.id},${s.enabled})">${s.enabled ? '停用' : '启用'}</a>
        <a class="btn small red" onclick="siteDel(${s.id})">删除</a>
      </td></tr>`;
  }).join('');
  document.getElementById('view').innerHTML = `
    <div class="flex mb8"><div class="grow"></div>
      <button class="btn primary" onclick="siteCreateModal()">+ 创建网站</button></div>
    <div class="card"><table class="tbl">
      <tr><th>站点</th><th>类型</th><th>状态</th><th>创建时间</th><th></th></tr>
      ${rows || '<tr><td colspan="5"><div class="empty">暂无网站，点击右上角创建</div></td></tr>'}
    </table></div>`;
}

async function siteCreateModal() {
  Modal.open('创建网站', `
    <div class="form-group"><label>网站名称</label><input id="fName" placeholder="例如 myblog"></div>
    <div class="form-group"><label>域名</label><input id="fDomain" placeholder="例如 example.com"></div>
    <div class="form-row">
      <div class="form-group"><label>网站类型</label>
        <select id="fType" onchange="onSiteTypeChange()">
          <option value="php">PHP 网站</option>
          <option value="python">Python 项目</option>
          <option value="static">静态站点</option>
        </select></div>
      <div class="form-group"><label>PHP 版本</label><select id="fPhp"><option value="8.1">PHP 8.1</option><option value="8.2">PHP 8.2</option><option value="7.4">PHP 7.4</option></select></div>
    </div>
    <div class="form-group" id="pyFrameRow"><label>Python 框架</label>
      <select id="fFrame"><option value="flask">Flask</option><option value="fastapi">FastAPI</option></select></div>
    <div class="form-group"><label>内部端口（Python 项目）</label><input id="fPort" placeholder="8000">
      <div class="form-tip">仅 Python 项目需要，Nginx 会反向代理到该端口</div></div>
  `, `<button class="btn" onclick="Modal.close()">取消</button><button class="btn primary" onclick="siteCreate()">创建</button>`);
  onSiteTypeChange();
}
function onSiteTypeChange() {
  const t = document.getElementById('fType').value;
  document.getElementById('pyFrameRow').style.display = t === 'python' ? '' : 'none';
  document.getElementById('fPort').closest('.form-group').style.display = t === 'python' ? '' : 'none';
  document.getElementById('fPhp').closest('.form-group').style.display = t === 'php' ? '' : 'none';
}
async function siteCreate() {
  const body = {
    name: document.getElementById('fName').value,
    domain: document.getElementById('fDomain').value,
    site_type: document.getElementById('fType').value,
    php_version: document.getElementById('fPhp').value,
    frame: document.getElementById('fFrame').value,
    port: parseInt(document.getElementById('fPort').value) || 8000,
  };
  const r = await API.post('/api/sites', body);
  toast(r.msg, r.ok ? 'ok' : 'err');
  if (r.ok) { Modal.close(); renderSites(); }
}
async function siteToggle(id, cur) {
  const r = await API.post('/api/sites/' + id + '/toggle', {});
  toast(r.msg, r.ok ? 'ok' : 'err'); renderSites();
}
async function siteDel(id) {
  if (!confirm('确定删除该网站？网站文件会保留在磁盘上。')) return;
  const r = await API.del('/api/sites/' + id);
  toast(r.msg, r.ok ? 'ok' : 'err'); renderSites();
}
async function siteDetail(id) {
  const r = await API.get('/api/sites/' + id + '/config');
  if (!r.ok) return toast(r.msg, 'err');
  const d = r.data;
  Modal.open('网站配置 - ' + d.site.name, `
    <div class="flex mb8"><b>${esc(d.site.domain)}</b> <span class="badge info">${d.site.site_type.toUpperCase()}</span>
      <span class="badge on">根目录</span></div>
    <div class="form-group"><label>站点根目录</label><input value="${esc(d.root_path)}" readonly></div>
    <div class="form-group"><label>Nginx 配置</label>
      <pre class="conf">${esc(d.nginx_conf || '（尚未生成配置，请点击下方重新生成）')}</pre></div>
  `, `<button class="btn" onclick="Modal.close()">关闭</button>
      <button class="btn primary" onclick="siteApplyNginx(${id})">重新生成并重载 Nginx</button>`);
}
async function siteApplyNginx(id) {
  const r = await API.post('/api/sites/' + id + '/apply_nginx', {});
  toast(r.msg, r.ok ? 'ok' : 'err');
}

/* ---------- 节点 ---------- */
async function renderNodes() {
  document.getElementById('view').innerHTML = '<div class="empty">加载中...</div>';
  const [r, st] = await Promise.all([API.get('/api/nodes'), API.get('/api/nodes/status')]);
  if (!r.ok) return;
  const core = st.data || {};
  const coreStatus = !core.installed
    ? `<span class="badge off">未安装</span> <button class="btn primary small" onclick="installXray()">一键安装 Xray 核心</button>`
    : core.running
      ? `<span class="badge on">运行中</span> <button class="btn small" onclick="xrayService('restart')">重启</button> <button class="btn small" onclick="xrayService('stop')">停止</button>`
      : `<span class="badge off">已停止</span> <button class="btn small" onclick="xrayService('start')">启动</button>`;
  const rows = (r.data || []).map(n => `
    <tr>
      <td><b>${esc(n.name)}</b></td>
      <td><span class="badge info">${esc(n.protocol.toUpperCase())}</span></td>
      <td class="mono">${n.port}</td>
      <td class="mono">${esc(n.network)}${n.network === 'ws' ? ' ' + esc(n.path) : ''}${n.tls ? ' +TLS' : ''}</td>
      <td>${n.enabled ? '<span class="badge on">启用</span>' : '<span class="badge off">停用</span>'}</td>
      <td class="actions">
        <a class="btn small" onclick="nodeDetail(${n.id})">配置/链接</a>
        <a class="btn small" onclick="nodeToggle(${n.id},${n.enabled})">${n.enabled ? '停用' : '启用'}</a>
        <a class="btn small red" onclick="nodeDel(${n.id})">删除</a>
      </td></tr>`).join('');
  document.getElementById('view').innerHTML = `
    <div class="card"><h3>Xray 核心 <span style="font-size:12px;color:#9aa4b2">${core.version || ''}</span></h3>
      <div class="flex">${coreStatus}</div></div>
    <div class="flex mb8"><div class="grow"></div>
      <button class="btn primary" onclick="nodeCreateModal()">+ 创建节点</button></div>
    <div class="card"><table class="tbl">
      <tr><th>名称</th><th>协议</th><th>端口</th><th>传输</th><th>状态</th><th></th></tr>
      ${rows || '<tr><td colspan="6"><div class="empty">暂无节点</div></td></tr>'}
    </table></div>`;
}

async function installXray() {
  toast('正在安装 Xray 核心，可能需要几分钟...');
  const r = await API.post('/api/nodes/install', {});
  toast(r.msg, r.ok ? 'ok' : 'err');
  renderNodes();
}
async function xrayService(action) {
  const r = await API.post('/api/nodes/1/service', { action });
  toast(r.msg, r.ok ? 'ok' : 'err'); renderNodes();
}
function nodeCreateModal() {
  Modal.open('创建节点', `
    <div class="form-group"><label>节点名称</label><input id="nName" placeholder="例如 香港-01"></div>
    <div class="form-row">
      <div class="form-group"><label>协议</label><select id="nProto"><option value="vmess">VMess</option><option value="vless">VLESS</option><option value="trojan">Trojan</option></select></div>
      <div class="form-group"><label>端口</label><input id="nPort" type="number" value="10086"></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label>传输协议</label><select id="nNet" onchange="onNodeNet()"><option value="tcp">TCP</option><option value="ws">WebSocket</option><option value="grpc">gRPC</option></select></div>
      <div class="form-group"><label>alterId</label><input id="nAlter" type="number" value="0"></div>
    </div>
    <div class="form-group" id="nPathRow"><label>WS 路径</label><input id="nPath" placeholder="/ray"></div>
    <div class="form-group"><label>TLS 加密</label><select id="nTls"><option value="0">关闭</option><option value="1">开启（需配置证书）</option></select></div>
    <div class="form-tip">UUID 会自动生成，创建后可查看分享链接</div>
  `, `<button class="btn" onclick="Modal.close()">取消</button><button class="btn primary" onclick="nodeCreate()">创建</button>`);
  onNodeNet();
}
function onNodeNet() {
  document.getElementById('nPathRow').style.display = document.getElementById('nNet').value === 'ws' ? '' : 'none';
}
async function nodeCreate() {
  const port = parseInt(document.getElementById('nPort').value) || 10086;
  const r = await API.post('/api/nodes', {
    name: document.getElementById('nName').value,
    protocol: document.getElementById('nProto').value,
    port: port,
    network: document.getElementById('nNet').value,
    alter_id: parseInt(document.getElementById('nAlter').value) || 0,
    path: document.getElementById('nPath').value,
    tls: document.getElementById('nTls').value === '1',
  });
  toast(r.msg, r.ok ? 'ok' : 'err');
  if (r.ok) { Modal.close(); renderNodes(); }
}
async function nodeDetail(id) {
  const r = await API.get('/api/nodes/' + id);
  if (!r.ok) return toast(r.msg, 'err');
  const d = r.data;
  Modal.open('节点 - ' + d.node.name, `
    <div class="form-group"><label>服务器 IP</label><input value="${esc(d.node.server_ip)}" readonly></div>
    <div class="form-group"><label>端口 / UUID</label>
      <input value="${d.node.port} / ${esc(d.node.uuid)}" readonly></div>
    <div class="form-group"><label>分享链接（点击复制）</label>
      <textarea rows="3" class="mono" readonly onclick="copyText(this.value,'链接已复制')">${esc(d.share_link)}</textarea>
      <div class="form-tip">复制到 v2rayN / Nekoray / Shadowrocket 等客户端即可导入</div></div>
    <div class="form-group"><label>Xray Inbound 配置</label><pre class="conf">${esc(d.json)}</pre></div>
  `, `<button class="btn" onclick="Modal.close()">关闭</button>
      <button class="btn green" onclick="copyText('${esc(d.share_link)}','链接已复制')">复制分享链接</button>`);
}
async function nodeToggle(id, cur) {
  const r = await API.post('/api/nodes/' + id + '/toggle', {});
  toast(r.msg, r.ok ? 'ok' : 'err'); renderNodes();
}
async function nodeDel(id) {
  if (!confirm('确定删除该节点？')) return;
  const r = await API.del('/api/nodes/' + id);
  toast(r.msg, r.ok ? 'ok' : 'err'); renderNodes();
}

/* ---------- 邮箱 ---------- */
async function renderEmail() {
  document.getElementById('view').innerHTML = '<div class="empty">加载中...</div>';
  const [r, st] = await Promise.all([API.get('/api/email/domains'), API.get('/api/email/status')]);
  if (!r.ok) return;
  const s = st.data || {};
  const installInfo = (!s.postfix || !s.dovecot)
    ? `<span class="badge off">邮件服务未安装</span>
       <button class="btn primary small" onclick="installMail()">一键安装 Postfix + Dovecot</button>
       <span class="form-tip" style="margin-left:8px">安装后开放 25 端口即可收发</span>`
    : `<span class="badge on">Postfix / Dovecot 已就绪</span>
       <span class="${s.port25 ? 'badge on' : 'badge warn'}">25 端口${s.port25 ? '已监听' : '未监听'}</span>`;

  const rows = (r.data || []).map(d => {
    const modeBadge = d.mode === 'forward' ? '<span class="badge info">转发邮箱</span>' : '<span class="badge green">独立邮箱</span>';
    const accounts = (d.accounts || []).map(a => {
      const email = a.prefix + '@' + d.domain;
      return `<div class="svc-item">
        <span class="mono">${esc(email)}</span>
        <span>${a.account_type === 'alias' ? '→ ' + esc(a.target) : ''}</span>
        <span><a class="link small" onclick="acctDel(${a.id})">删除</a></span></div>`;
    }).join('');
    return `<div class="card">
      <div class="flex mb8">
        <h3 style="margin:0" class="grow">${esc(d.domain)}</h3> ${modeBadge}
        ${d.mode === 'standalone' ? `<a class="btn small green" target="_blank" href="/webmail/${esc(d.domain)}">网页邮箱 →</a>` : ''}
        <a class="btn small" onclick="acctCreateModal(${d.id},'${d.mode}','${esc(d.domain)}')">+ 添加账号</a>
        <a class="btn small red" onclick="domainDel(${d.id})">删除</a>
      </div>
      ${d.mode === 'forward'
        ? `<div class="form-tip mb8">转发收件邮箱：<span class="mono">${esc(d.forward_target)}</span> —— 发给 <b>任意前缀@${esc(d.domain)}</b> 的邮件将转发到该邮箱</div>`
        : `<div class="form-tip mb8">独立邮箱：可创建任意前缀账号，通过网页邮箱在线收发</div>`}
      ${accounts || '<div class="form-tip">（暂无账号）</div>'}
    </div>`;
  }).join('');

  document.getElementById('view').innerHTML = `
    <div class="card"><h3>邮件服务状态</h3><div class="flex">${installInfo}</div></div>
    <div class="flex mb8"><div class="grow"></div>
      <button class="btn primary" onclick="domainCreateModal()">+ 添加邮箱域名</button></div>
    ${rows || '<div class="card"><div class="empty">暂无邮箱域名</div></div>'}`;
}

async function installMail() {
  toast('正在安装 Postfix + Dovecot，可能需要几分钟...');
  const r = await API.post('/api/email/install', {});
  toast(r.msg, r.ok ? 'ok' : 'err');
  renderEmail();
}

function domainCreateModal() {
  Modal.open('添加邮箱域名', `
    <div class="form-group"><label>域名</label><input id="eDomain" placeholder="例如 mail.example.com">
      <div class="form-tip">需将域名的 MX 记录解析到本服务器 IP，并开放 25 端口</div></div>
    <div class="form-group"><label>模式</label>
      <select id="eMode" onchange="onModeChange()">
        <option value="forward">邮箱转发</option>
        <option value="standalone">独立邮箱</option>
      </select></div>
    <div class="form-group" id="eTargetRow"><label>收件邮箱（转发目标）</label>
      <input id="eTarget" placeholder="例如 me@qq.com">
      <div class="form-tip">邮箱转发：在下方创建前缀后，别人发送到 前缀@域名 的邮件会转发到该收件邮箱</div></div>
    <div class="form-group" id="eStandTip" style="display:none">
      <div class="form-tip">独立邮箱：创建后自动生成网页邮箱管理页，可在线创建账号、收发邮件</div></div>
  `, `<button class="btn" onclick="Modal.close()">取消</button><button class="btn primary" onclick="domainCreate()">创建</button>`);
  onModeChange();
}
function onModeChange() {
  const m = document.getElementById('eMode').value;
  document.getElementById('eTargetRow').style.display = m === 'forward' ? '' : 'none';
  document.getElementById('eStandTip').style.display = m === 'standalone' ? '' : 'none';
}
async function domainCreate() {
  const r = await API.post('/api/email/domains', {
    domain: document.getElementById('eDomain').value,
    mode: document.getElementById('eMode').value,
    forward_target: document.getElementById('eTarget').value,
  });
  toast(r.msg, r.ok ? 'ok' : 'err');
  if (r.ok) { Modal.close(); renderEmail(); }
}
async function domainDel(id) {
  if (!confirm('确定删除该邮箱域名及其所有账号？')) return;
  const r = await API.del('/api/email/domains/' + id);
  toast(r.msg, r.ok ? 'ok' : 'err'); renderEmail();
}
function acctCreateModal(did, mode, domain) {
  const isForward = mode === 'forward';
  Modal.open('添加邮箱账号 - ' + domain, `
    <div class="form-group"><label>邮箱前缀</label><input id="aPrefix" placeholder="例如 user1">
      <div class="form-tip">完整地址：<b>前缀@${esc(domain)}</b></div></div>
    ${isForward
      ? `<div class="form-group"><label>转发目标（留空使用域名默认收件邮箱）</label><input id="aTarget" placeholder="例如 me@qq.com"></div>`
      : `<div class="form-group"><label>邮箱密码（至少 6 位）</label><input id="aPass" type="text" placeholder="例如 abc123"></div>`}
  `, `<button class="btn" onclick="Modal.close()">取消</button><button class="btn primary" onclick="acctCreate(${did},'${isForward ? 'alias' : 'mailbox'}')">创建</button>`);
}
async function acctCreate(did, type) {
  const r = await API.post('/api/email/accounts', {
    domain_id: did,
    prefix: document.getElementById('aPrefix').value,
    account_type: type,
    target: document.getElementById('aTarget') ? document.getElementById('aTarget').value : '',
    password: document.getElementById('aPass') ? document.getElementById('aPass').value : '',
  });
  toast(r.msg, r.ok ? 'ok' : 'err');
  if (r.ok) { Modal.close(); renderEmail(); }
}
async function acctDel(aid) {
  if (!confirm('确定删除该账号？')) return;
  const r = await API.del('/api/email/accounts/' + aid);
  toast(r.msg, r.ok ? 'ok' : 'err'); renderEmail();
}

/* ---------- 设置 ---------- */
async function renderSettings() {
  const me = await API.get('/api/me');
  document.getElementById('view').innerHTML = `
    <div class="card"><h3>修改登录密码</h3>
      <div class="form-group" style="max-width:420px"><label>原密码</label><input id="pOld" type="password"></div>
      <div class="form-group" style="max-width:420px"><label>新密码（至少 6 位）</label><input id="pNew" type="password"></div>
      <button class="btn primary" onclick="changePwd()">保存修改</button></div>
    <div class="card"><h3>关于</h3>
      <table class="tbl">
        <tr><td style="width:140px">面板名称</td><td>XPanel 希旭面板</td></tr>
        <tr><td>版本</td><td>v1.0.0</td></tr>
        <tr><td>登录账号</td><td>${esc((me.data || {}).username || '')}</td></tr>
        <tr><td>功能</td><td>网站管理（PHP / Python / 静态）· 节点管理（VMess / VLESS / Trojan）· 邮箱服务（转发 / 独立邮箱 + 网页邮箱）</td></tr>
      </table></div>`;
}
async function changePwd() {
  const r = await API.post('/api/change_password', {
    old_password: document.getElementById('pOld').value,
    new_password: document.getElementById('pNew').value,
  });
  toast(r.msg, r.ok ? 'ok' : 'err');
}

/* ---------- 路由 ---------- */
const Router = {
  current: 'dashboard',
  show(page) {
    this.current = page;
    document.querySelectorAll('#menu a').forEach(a => a.classList.toggle('active', a.dataset.page === page));
    document.getElementById('pageTitle').textContent = TITLES[page] || '首页';
    const fns = { dashboard: renderDashboard, sites: renderSites, nodes: renderNodes, email: renderEmail, settings: renderSettings };
    (fns[page] || renderDashboard)();
  },
};
document.querySelectorAll('#menu a').forEach(a => {
  a.addEventListener('click', () => Router.show(a.dataset.page));
});

/* ---------- 登录 ---------- */
const App = {
  async login() {
    const u = document.getElementById('loginUser').value.trim();
    const p = document.getElementById('loginPass').value;
    const msg = document.getElementById('loginMsg');
    const r = await API.post('/api/login', { username: u, password: p });
    if (r.ok) {
      API.token = r.token;
      localStorage.setItem('xp_token', r.token);
      msg.classList.add('hidden');
      this.enter();
    } else {
      msg.textContent = r.msg;
      msg.className = 'msg err';
    }
  },
  enter() {
    document.getElementById('loginPage').classList.add('hidden');
    document.getElementById('app').classList.remove('hidden');
    document.getElementById('topUser').textContent = localStorage.getItem('xp_user') || '';
    API.get('/api/me').then(r => { if (r.ok) document.getElementById('topUser').textContent = r.data.username; });
    Router.show('dashboard');
  },
  forceLogout() {
    localStorage.removeItem('xp_token');
    API.token = '';
    document.getElementById('app').classList.add('hidden');
    document.getElementById('loginPage').classList.remove('hidden');
  },
};
document.getElementById('loginBtn').addEventListener('click', () => App.login());
document.getElementById('loginPass').addEventListener('keydown', e => { if (e.key === 'Enter') App.login(); });
document.getElementById('logoutBtn').addEventListener('click', () => {
  API.post('/api/logout', {}).finally(() => App.forceLogout());
});

/* ---------- 启动 ---------- */
(function init() {
  if (API.token) {
    API.get('/api/me').then(r => r.ok ? App.enter() : App.forceLogout());
  }
})();
