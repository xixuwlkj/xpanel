/* ===== XPanel 希旭面板 - 前端逻辑 ===== */
'use strict';

/* 调试用：全局错误捕获 */
window.onerror = function (msg, src, line) {
  var v = document.getElementById('view');
  if (v) v.innerHTML = '<div class="msg err">JS错误: ' + esc(msg) + ' @line ' + line + '</div>';
  return false;
};
window.addEventListener('unhandledrejection', function (e) {
  var v = document.getElementById('view');
  if (v) v.innerHTML = '<div class="msg err">Promise错误: ' + esc(String(e.reason)) + '</div>';
});

/* ---------- API ---------- */
const API = {
  token: localStorage.getItem('xp_token') || '',
  async req(method, url, body) {
    const opt = { method, headers: { 'Content-Type': 'application/json' } };
    if (this.token) opt.headers['X-Panel-Token'] = this.token;
    if (body) opt.body = JSON.stringify(body);
    const resp = await fetch(url, opt);
    let data;
    try { data = await resp.json(); } catch (e) { data = { ok: false, msg: '服务器响应异常' }; }
    if (resp.status === 401) { App.forceLogout(); }
    return data;
  },
  get(url) { return this.req('GET', url); },
  post(url, body) { return this.req('POST', url, body); },
  del(url) { return this.req('DELETE', url); },
};

/* ---------- 工具 ---------- */
function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g,
    c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
function fmtSize(n) {
  n = Number(n) || 0;
  for (const u of ['B', 'KB', 'MB', 'GB', 'TB']) { if (n < 1024 || u === 'TB') return n.toFixed(1) + ' ' + u; n /= 1024; }
}
function fmtUptime(sec) {
  const d = Math.floor(sec / 86400), h = Math.floor(sec % 86400 / 3600), m = Math.floor(sec % 3600 / 60);
  return (d ? d + '天 ' : '') + h + '时 ' + m + '分';
}
function fmtTime(ts) { return new Date(ts * 1000).toLocaleString(); }

function toast(msg, type) {
  const el = document.getElementById('toast');
  el.textContent = msg; el.className = 'toast ' + (type || '');
  clearTimeout(el._t);
  el._t = setTimeout(() => el.classList.add('hidden'), 2600);
}

async function copyText(text, tip) {
  try {
    await navigator.clipboard.writeText(text);
  } catch (e) {
    const ta = document.createElement('textarea');
    ta.value = text; document.body.appendChild(ta); ta.select();
    document.execCommand('copy'); ta.remove();
  }
  toast(tip || '已复制');
}

/* ---------- 模态框 ---------- */
const Modal = {
  open(title, bodyHtml, footHtml) {
    document.getElementById('modalTitle').textContent = title;
    document.getElementById('modalBody').innerHTML = bodyHtml;
    document.getElementById('modalMask').classList.remove('hidden');
    if (footHtml) {
      let f = document.querySelector('.modal-foot');
      if (!f) { f = document.createElement('div'); f.className = 'modal-foot'; document.querySelector('.modal').appendChild(f); }
      f.innerHTML = footHtml;
    }
  },
  close() { document.getElementById('modalMask').classList.add('hidden'); },
};
document.getElementById('modalMask').addEventListener('click', e => {
  if (e.target.id === 'modalMask') Modal.close();
});

/* ---------- 图表（Canvas 折线图） ---------- */
function drawLineChart(canvasId, labels, series) {
  const cv = document.getElementById(canvasId);
  if (!cv) return;
  const dpr = window.devicePixelRatio || 1;
  const W = cv.clientWidth, H = cv.clientHeight;
  cv.width = W * dpr; cv.height = H * dpr;
  const ctx = cv.getContext('2d');
  ctx.scale(dpr, dpr);
  ctx.clearRect(0, 0, W, H);
  if (!series.length || !series[0].data.length) return;

  const pad = { l: 40, r: 12, t: 14, b: 24 };
  const iw = W - pad.l - pad.r, ih = H - pad.t - pad.b;
  let max = 100;
  series.forEach(s => s.data.forEach(v => { if (v > max) max = v; }));
  max = Math.ceil(max / 10) * 10 || 100;

  // 网格
  ctx.strokeStyle = '#eef1f5'; ctx.lineWidth = 1; ctx.fillStyle = '#8a94a3'; ctx.font = '11px sans-serif';
  for (let i = 0; i <= 4; i++) {
    const y = pad.t + ih - ih * i / 4;
    ctx.beginPath(); ctx.moveTo(pad.l, y); ctx.lineTo(W - pad.r, y); ctx.stroke();
    ctx.textAlign = 'right'; ctx.fillText(Math.round(max * i / 4), pad.l - 6, y + 4);
  }
  const step = iw / (labels.length - 1 || 1);
  labels.forEach((lb, i) => {
    ctx.textAlign = 'center';
    ctx.fillText(lb, pad.l + step * i, H - 8);
  });

  series.forEach(s => {
    ctx.beginPath();
    s.data.forEach((v, i) => {
      const x = pad.l + step * i, y = pad.t + ih - (v / max) * ih;
      i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
    });
    ctx.strokeStyle = s.color; ctx.lineWidth = 2; ctx.stroke();
    // 面积
    ctx.lineTo(pad.l + step * (s.data.length - 1), pad.t + ih);
    ctx.lineTo(pad.l, pad.t + ih); ctx.closePath();
    ctx.fillStyle = s.color + '22'; ctx.fill();
  });
}

/* ---------- 页面标题 ---------- */
const TITLES = { dashboard: '首页', sites: '网站', nodes: '节点', email: '邮箱', softwares: '软件', files: '文件', security: '安全', terminal: '终端', settings: '设置' };

/* ---------- 首页 ---------- */
async function renderDashboard() {
  document.getElementById('view').innerHTML = '<div class="empty">加载中...</div>';
  const [ov, svc] = await Promise.all([API.get('/api/system/overview'), API.get('/api/system/services')]);
  if (!ov.ok) return;
  const o = ov.data;
  let stats = `
    <div class="stat-grid">
      <div class="stat"><div class="s-label">CPU 使用率</div><div class="s-val">${o.cpu_percent.toFixed(1)}<small>%</small></div>
        <div class="bar blue"><i style="width:${o.cpu_percent}%"></i></div>
        <div class="s-sub">${o.cpu_count} 核 · 负载 ${o.load.join(' / ')}</div></div>
      <div class="stat"><div class="s-label">内存使用率</div><div class="s-val">${o.mem.percent.toFixed(1)}<small>%</small></div>
        <div class="bar orange"><i style="width:${o.mem.percent}%"></i></div>
        <div class="s-sub">${fmtSize(o.mem.used)} / ${fmtSize(o.mem.total)}</div></div>
      <div class="stat"><div class="s-label">磁盘使用率</div><div class="s-val">${o.disk.percent.toFixed(1)}<small>%</small></div>
        <div class="bar green"><i style="width:${o.disk.percent}%"></i></div>
        <div class="s-sub">${fmtSize(o.disk.used)} / ${fmtSize(o.disk.total)}</div></div>
      <div class="stat"><div class="s-label">实时网速</div><div class="s-val"><small>↓</small>${o.net.down}<small> ↑</small>${o.net.up}</div>
        <div class="s-sub">运行 ${fmtUptime(o.uptime)}</div></div>
    </div>
    <div class="dash-grid">
      <div class="card"><h3>资源使用趋势</h3><canvas id="resChart" class="chart-box"></canvas></div>
      <div class="card"><h3>服务状态</h3><div id="svcList"></div>
        <div class="mt8"><a class="link" onclick="renderSites()">管理网站 →</a></div></div>
    </div>
    <div class="card"><h3>系统信息</h3>
      <table class="tbl">
        <tr><td style="width:140px">主机名</td><td class="mono">${esc(o.hostname)}</td></tr>
        <tr><td>操作系统</td><td class="mono">${esc(o.os)}</td></tr>
        <tr><td>Python 版本</td><td class="mono">${esc(o.python)}</td></tr>
        <tr><td>面板地址</td><td class="mono">http://${location.host}</td></tr>
      </table></div>`;
  document.getElementById('view').innerHTML = stats;

  // 服务状态
  let sv = '';
  (svc.data || []).forEach(s => {
    const st = !s.installed ? '<span class="badge gray">未安装</span>'
      : s.running ? '<span class="badge on">运行中</span>' : '<span class="badge off">已停止</span>';
    sv += `<div class="svc-item"><span>${esc(s.name)} <small style="color:#9aa4b2">${esc(s.desc)}</small></span>${st}</div>`;
  });
  document.getElementById('svcList').innerHTML = sv;

  // 图表
  const hist = await API.get('/api/system/cpu_history');
  const labels = [], cpu = [], mem = [];
  (hist.data || []).forEach((d, i) => { labels.push(i % 5 === 0 ? i + 's' : ''); cpu.push(d.cpu); mem.push(d.mem); });
  drawLineChart('resChart', labels, [
    { color: '#2a7de1', data: cpu },
    { color: '#22a06b', data: mem },
  ]);
}

/* ---------- 网站 ---------- */
async function renderSites() {
  document.getElementById('view').innerHTML = '<div class="empty">加载中...</div>';
  const r = await API.get('/api/sites');
  if (!r.ok) return;
  const rows = (r.data || []).map(s => {
    const typeBadge = s.site_type === 'php' ? '<span class="badge info">PHP ' + esc(s.php_version) + '</span>'
      : s.site_type === 'python' ? '<span class="badge warn">Python :' + s.port + '</span><br><span class="mono" style="color:#7c8aa0;font-size:11px">' + esc(s.start_command || '') + '</span>'
      : '<span class="badge gray">静态</span>';
    return `<tr>
      <td><b>${esc(s.name)}</b><br><span class="mono" style="color:#7c8aa0">${esc(s.domain)}</span></td>
      <td>${typeBadge}</td>
      <td>${s.enabled ? '<span class="badge on">运行</span>' : '<span class="badge off">停用</span>'}</td>
      <td>${fmtTime(new Date(s.created_at.replace(/-/g, '/')).getTime() / 1000)}</td>
      <td class="actions">
        <a class="btn small" onclick="siteDetail(${s.id})">配置</a>
        <a class="btn small" onclick="siteToggle(${s.id},${s.enabled})">${s.enabled ? '停用' : '启用'}</a>
        <a class="btn small red" onclick="siteDel(${s.id})">删除</a>
      </td></tr>`;
  }).join('');
  document.getElementById('view').innerHTML = `
    <div class="flex mb8"><div class="grow"></div>
      <button class="btn primary" onclick="siteCreateModal()">+ 创建网站</button></div>
    <div class="card"><table class="tbl">
      <tr><th>站点</th><th>类型</th><th>状态</th><th>创建时间</th><th></th></tr>
      ${rows || '<tr><td colspan="5"><div class="empty">暂无网站，点击右上角创建</div></td></tr>'}
    </table></div>`;
}

async function siteCreateModal() {
  Modal.open('创建网站', `
    <div class="form-group"><label>网站名称</label><input id="fName" placeholder="例如 myblog"></div>
    <div class="form-group" id="fDomainRow"><label>域名</label><input id="fDomain" placeholder="例如 example.com">
      <div class="form-tip">Python 项目可不填域名，直接用 IP:端口 访问</div></div>
    <div class="form-row">
      <div class="form-group"><label>网站类型</label>
        <select id="fType" onchange="onSiteTypeChange()">
          <option value="php">PHP 网站</option>
          <option value="python">Python 项目</option>
          <option value="static">静态站点</option>
        </select></div>
      <div class="form-group" id="fPhpRow"><label>PHP 版本</label><select id="fPhp"><option value="8.1">PHP 8.1</option><option value="8.2">PHP 8.2</option><option value="7.4">PHP 7.4</option></select></div>
    </div>
    <div class="form-group" id="pyCmdRow"><label>Python 启动命令</label><input id="fCmd" placeholder="例如 gunicorn -b 127.0.0.1:8000 -w 2 app:app">
      <div class="form-tip">必填。面板将该命令注册为 systemd 服务，在项目目录下执行</div></div>
    <div class="form-group" id="pyPortRow"><label>项目端口</label><input id="fPort" type="number" value="8000">
      <div class="form-tip">必填。有域名时 Nginx 反代到该端口；无域名时直接访问 IP:端口</div></div>
  `, `<button class="btn" onclick="Modal.close()">取消</button><button class="btn primary" onclick="siteCreate()">创建</button>`);
  onSiteTypeChange();
}
function onSiteTypeChange() {
  const t = document.getElementById('fType').value;
  const py = t === 'python';
  document.getElementById('pyCmdRow').style.display = py ? '' : 'none';
  document.getElementById('pyPortRow').style.display = py ? '' : 'none';
  document.getElementById('fPhpRow').style.display = t === 'php' ? '' : 'none';
}
async function siteCreate() {
  const body = {
    name: document.getElementById('fName').value,
    domain: document.getElementById('fDomain').value,
    site_type: document.getElementById('fType').value,
    php_version: document.getElementById('fPhp').value,
    start_command: document.getElementById('fCmd').value,
    port: parseInt(document.getElementById('fPort').value) || 8000,
  };
  const r = await API.post('/api/sites', body);
  toast(r.msg, r.ok ? 'ok' : 'err');
  if (r.ok) { Modal.close(); renderSites(); }
}
async function siteToggle(id, cur) {
  const r = await API.post('/api/sites/' + id + '/toggle', {});
  toast(r.msg, r.ok ? 'ok' : 'err'); renderSites();
}
async function siteDel(id) {
  if (!confirm('确定删除该网站？网站文件会保留在磁盘上。')) return;
  const r = await API.del('/api/sites/' + id);
  toast(r.msg, r.ok ? 'ok' : 'err'); renderSites();
}
async function siteDetail(id) {
  const r = await API.get('/api/sites/' + id + '/config');
  if (!r.ok) return toast(r.msg, 'err');
  const d = r.data;
  Modal.open('网站配置 - ' + d.site.name, `
    <div class="flex mb8"><b>${esc(d.site.domain)}</b> <span class="badge info">${d.site.site_type.toUpperCase()}</span>
      <span class="badge on">根目录</span></div>
    <div class="form-group"><label>站点根目录</label><input value="${esc(d.root_path)}" readonly></div>
    <div class="form-group"><label>Nginx 配置</label>
      <pre class="conf">${esc(d.nginx_conf || '（尚未生成配置，请点击下方重新生成）')}</pre></div>
  `, `<button class="btn" onclick="Modal.close()">关闭</button>
      <button class="btn primary" onclick="siteApplyNginx(${id})">重新生成并重载 Nginx</button>`);
}
async function siteApplyNginx(id) {
  const r = await API.post('/api/sites/' + id + '/apply_nginx', {});
  toast(r.msg, r.ok ? 'ok' : 'err');
}

/* ---------- 节点 ---------- */
async function renderNodes() {
  document.getElementById('view').innerHTML = '<div class="empty">加载中...</div>';
  const [r, st] = await Promise.all([API.get('/api/nodes'), API.get('/api/nodes/status')]);
  if (!r.ok) return;
  const core = st.data || {};
  const coreStatus = !core.installed
    ? `<span class="badge off">未安装</span> <button class="btn primary small" onclick="installXray()">一键安装 Xray 核心</button>`
    : core.running
      ? `<span class="badge on">运行中</span> <button class="btn small" onclick="xrayService('restart')">重启</button> <button class="btn small" onclick="xrayService('stop')">停止</button>`
      : `<span class="badge off">已停止</span> <button class="btn small" onclick="xrayService('start')">启动</button>`;
  const rows = (r.data || []).map(n => `
    <tr>
      <td><b>${esc(n.name)}</b></td>
      <td><span class="badge info">${esc(n.protocol.toUpperCase())}</span></td>
      <td class="mono">${n.port}</td>
      <td class="mono">${esc(n.network)}${n.network === 'ws' ? ' ' + esc(n.path) : ''}${n.tls ? ' +TLS' : ''}</td>
      <td>${n.enabled ? '<span class="badge on">启用</span>' : '<span class="badge off">停用</span>'}</td>
      <td class="actions">
        <a class="btn small" onclick="nodeDetail(${n.id})">配置/链接</a>
        <a class="btn small" onclick="nodeToggle(${n.id},${n.enabled})">${n.enabled ? '停用' : '启用'}</a>
        <a class="btn small red" onclick="nodeDel(${n.id})">删除</a>
      </td></tr>`).join('');
  document.getElementById('view').innerHTML = `
    <div class="card"><h3>Xray 核心 <span style="font-size:12px;color:#9aa4b2">${core.version || ''}</span></h3>
      <div class="flex">${coreStatus}</div></div>
    <div class="flex mb8"><div class="grow"></div>
      <button class="btn primary" onclick="nodeCreateModal()">+ 创建节点</button></div>
    <div class="card"><table class="tbl">
      <tr><th>名称</th><th>协议</th><th>端口</th><th>传输</th><th>状态</th><th></th></tr>
      ${rows || '<tr><td colspan="6"><div class="empty">暂无节点</div></td></tr>'}
    </table></div>`;
}

async function installXray() {
  toast('正在安装 Xray 核心，可能需要几分钟...');
  const r = await API.post('/api/nodes/install', {});
  toast(r.msg, r.ok ? 'ok' : 'err');
  renderNodes();
}
async function xrayService(action) {
  const r = await API.post('/api/nodes/1/service', { action });
  toast(r.msg, r.ok ? 'ok' : 'err'); renderNodes();
}
function nodeCreateModal() {
  Modal.open('创建节点', `
    <div class="form-group"><label>节点名称</label><input id="nName" placeholder="例如 香港-01"></div>
    <div class="form-row">
      <div class="form-group"><label>协议</label><select id="nProto"><option value="vmess">VMess</option><option value="vless">VLESS</option><option value="trojan">Trojan</option></select></div>
      <div class="form-group"><label>端口</label><input id="nPort" type="number" value="10086"></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label>传输协议</label><select id="nNet" onchange="onNodeNet()"><option value="tcp">TCP</option><option value="ws">WebSocket</option><option value="grpc">gRPC</option></select></div>
      <div class="form-group"><label>alterId</label><input id="nAlter" type="number" value="0"></div>
    </div>
    <div class="form-group" id="nPathRow"><label>WS 路径</label><input id="nPath" placeholder="/ray"></div>
    <div class="form-group"><label>TLS 加密</label><select id="nTls"><option value="0">关闭</option><option value="1">开启（需配置证书）</option></select></div>
    <div class="form-tip">UUID 会自动生成，创建后可查看分享链接</div>
  `, `<button class="btn" onclick="Modal.close()">取消</button><button class="btn primary" onclick="nodeCreate()">创建</button>`);
  onNodeNet();
}
function onNodeNet() {
  document.getElementById('nPathRow').style.display = document.getElementById('nNet').value === 'ws' ? '' : 'none';
}
async function nodeCreate() {
  const port = parseInt(document.getElementById('nPort').value) || 10086;
  const r = await API.post('/api/nodes', {
    name: document.getElementById('nName').value,
    protocol: document.getElementById('nProto').value,
    port: port,
    network: document.getElementById('nNet').value,
    alter_id: parseInt(document.getElementById('nAlter').value) || 0,
    path: document.getElementById('nPath').value,
    tls: document.getElementById('nTls').value === '1',
  });
  toast(r.msg, r.ok ? 'ok' : 'err');
  if (r.ok) { Modal.close(); renderNodes(); }
}
async function nodeDetail(id) {
  const r = await API.get('/api/nodes/' + id);
  if (!r.ok) return toast(r.msg, 'err');
  const d = r.data;
  Modal.open('节点 - ' + d.node.name, `
    <div class="form-group"><label>服务器 IP</label><input value="${esc(d.node.server_ip)}" readonly></div>
    <div class="form-group"><label>端口 / UUID</label>
      <input value="${d.node.port} / ${esc(d.node.uuid)}" readonly></div>
    <div class="form-group"><label>分享链接（点击复制）</label>
      <textarea rows="3" class="mono" readonly onclick="copyText(this.value,'链接已复制')">${esc(d.share_link)}</textarea>
      <div class="form-tip">复制到 v2rayN / Nekoray / Shadowrocket 等客户端即可导入</div></div>
    <div class="form-group"><label>Xray Inbound 配置</label><pre class="conf">${esc(d.json)}</pre></div>
  `, `<button class="btn" onclick="Modal.close()">关闭</button>
      <button class="btn green" onclick="copyText('${esc(d.share_link)}','链接已复制')">复制分享链接</button>`);
}
async function nodeToggle(id, cur) {
  const r = await API.post('/api/nodes/' + id + '/toggle', {});
  toast(r.msg, r.ok ? 'ok' : 'err'); renderNodes();
}
async function nodeDel(id) {
  if (!confirm('确定删除该节点？')) return;
  const r = await API.del('/api/nodes/' + id);
  toast(r.msg, r.ok ? 'ok' : 'err'); renderNodes();
}

/* ---------- 邮箱 ---------- */
async function renderEmail() {
  document.getElementById('view').innerHTML = '<div class="empty">加载中...</div>';
  const [r, st] = await Promise.all([API.get('/api/email/domains'), API.get('/api/email/status')]);
  if (!r.ok) return;
  const s = st.data || {};
  const installInfo = (!s.postfix || !s.dovecot)
    ? `<span class="badge off">邮件服务未安装</span>
       <button class="btn primary small" onclick="installMail()">一键安装 Postfix + Dovecot</button>
       <span class="form-tip" style="margin-left:8px">安装后开放 25 端口即可收发</span>`
    : `<span class="badge on">Postfix / Dovecot 已就绪</span>
       <span class="${s.port25 ? 'badge on' : 'badge warn'}">25 端口${s.port25 ? '已监听' : '未监听'}</span>`;

  const rows = (r.data || []).map(d => {
    const modeBadge = d.mode === 'forward' ? '<span class="badge info">转发邮箱</span>' : '<span class="badge green">独立邮箱</span>';
    const accounts = (d.accounts || []).map(a => {
      const email = a.prefix + '@' + d.domain;
      return `<div class="svc-item">
        <span class="mono">${esc(email)}</span>
        <span>${a.account_type === 'alias' ? '→ ' + esc(a.target) : ''}</span>
        <span><a class="link small" onclick="acctDel(${a.id})">删除</a></span></div>`;
    }).join('');
    return `<div class="card">
      <div class="flex mb8">
        <h3 style="margin:0" class="grow">${esc(d.domain)}</h3> ${modeBadge}
        ${d.mode === 'standalone' ? `<a class="btn small green" target="_blank" href="/webmail/${esc(d.domain)}">网页邮箱 →</a>` : ''}
        ${d.mode === 'standalone' ? `<a class="btn small" onclick="wmCopy('${location.origin}/webmail/${esc(d.domain)}','${esc(d.domain)}')">复制登录地址</a>` : ''}
        <a class="btn small" onclick="acctCreateModal(${d.id},'${d.mode}','${esc(d.domain)}')">+ 添加账号</a>
        <a class="btn small red" onclick="domainDel(${d.id})">删除</a>
      </div>
      ${d.mode === 'forward'
        ? `<div class="form-tip mb8">转发收件邮箱：<span class="mono">${esc(d.forward_target)}</span> —— 发给 <b>任意前缀@${esc(d.domain)}</b> 的邮件将转发到该邮箱</div>`
        : `<div class="form-tip mb8">独立邮箱：可创建任意前缀账号，通过网页邮箱在线收发</div>
           ${(() => { const adm = (d.accounts || []).find(a => a.prefix === 'admin'); return adm ?
             `<div class="msg ok" style="margin-top:8px">网页邮箱登录地址：<b class="mono">${location.origin}/webmail/${esc(d.domain)}</b><br>
              管理员账号：<b class="mono">admin@${esc(d.domain)}</b>　密码：<b class="mono">${esc(adm.password)}</b>
              <a class="link" style="margin-left:8px" onclick="copyText('admin@${esc(d.domain)}','账号已复制')">复制账号</a>
              <a class="link" onclick="copyText('${esc(adm.password)}','密码已复制')">复制密码</a></div>` : ''; })()}`}
      ${accounts || '<div class="form-tip">（暂无账号）</div>'}
    </div>`;
  }).join('');

  document.getElementById('view').innerHTML = `
    <div class="card"><h3>邮件服务状态</h3><div class="flex">${installInfo}</div></div>
    <div class="flex mb8"><div class="grow"></div>
      <button class="btn primary" onclick="domainCreateModal()">+ 添加邮箱域名</button></div>
    ${rows || '<div class="card"><div class="empty">暂无邮箱域名</div></div>'}`;
}

async function installMail() {
  toast('正在安装 Postfix + Dovecot，可能需要几分钟...');
  const r = await API.post('/api/email/install', {});
  toast(r.msg, r.ok ? 'ok' : 'err');
  renderEmail();
}

function domainCreateModal() {
  Modal.open('添加邮箱域名', `
    <div class="form-group"><label>域名</label><input id="eDomain" placeholder="例如 mail.example.com">
      <div class="form-tip">需将域名的 MX 记录解析到本服务器 IP，并开放 25 端口</div></div>
    <div class="form-group"><label>模式</label>
      <select id="eMode" onchange="onModeChange()">
        <option value="forward">邮箱转发</option>
        <option value="standalone">独立邮箱</option>
      </select></div>
    <div class="form-group" id="eTargetRow"><label>收件邮箱（转发目标）</label>
      <input id="eTarget" placeholder="例如 me@qq.com">
      <div class="form-tip">邮箱转发：在下方创建前缀后，别人发送到 前缀@域名 的邮件会转发到该收件邮箱</div></div>
    <div class="form-group" id="eStandTip" style="display:none">
      <div class="form-tip">独立邮箱：创建后自动生成网页邮箱管理页，可在线创建账号、收发邮件</div></div>
  `, `<button class="btn" onclick="Modal.close()">取消</button><button class="btn primary" onclick="domainCreate()">创建</button>`);
  onModeChange();
}
function onModeChange() {
  const m = document.getElementById('eMode').value;
  document.getElementById('eTargetRow').style.display = m === 'forward' ? '' : 'none';
  document.getElementById('eStandTip').style.display = m === 'standalone' ? '' : 'none';
}
async function domainCreate() {
  const r = await API.post('/api/email/domains', {
    domain: document.getElementById('eDomain').value,
    mode: document.getElementById('eMode').value,
    forward_target: document.getElementById('eTarget').value,
  });
  toast(r.msg, r.ok ? 'ok' : 'err');
  if (r.ok) { Modal.close(); renderEmail(); }
}
async function domainDel(id) {
  if (!confirm('确定删除该邮箱域名及其所有账号？')) return;
  const r = await API.del('/api/email/domains/' + id);
  toast(r.msg, r.ok ? 'ok' : 'err'); renderEmail();
}
function acctCreateModal(did, mode, domain) {
  const isForward = mode === 'forward';
  Modal.open('添加邮箱账号 - ' + domain, `
    <div class="form-group"><label>邮箱前缀</label><input id="aPrefix" placeholder="例如 user1">
      <div class="form-tip">完整地址：<b>前缀@${esc(domain)}</b></div></div>
    ${isForward
      ? `<div class="form-group"><label>转发目标（留空使用域名默认收件邮箱）</label><input id="aTarget" placeholder="例如 me@qq.com"></div>`
      : `<div class="form-group"><label>邮箱密码（至少 6 位）</label><input id="aPass" type="text" placeholder="例如 abc123"></div>`}
  `, `<button class="btn" onclick="Modal.close()">取消</button><button class="btn primary" onclick="acctCreate(${did},'${isForward ? 'alias' : 'mailbox'}')">创建</button>`);
}
async function acctCreate(did, type) {
  const r = await API.post('/api/email/accounts', {
    domain_id: did,
    prefix: document.getElementById('aPrefix').value,
    account_type: type,
    target: document.getElementById('aTarget') ? document.getElementById('aTarget').value : '',
    password: document.getElementById('aPass') ? document.getElementById('aPass').value : '',
  });
  toast(r.msg, r.ok ? 'ok' : 'err');
  if (r.ok) { Modal.close(); renderEmail(); }
}
async function acctDel(aid) {
  if (!confirm('确定删除该账号？')) return;
  const r = await API.del('/api/email/accounts/' + aid);
  toast(r.msg, r.ok ? 'ok' : 'err'); renderEmail();
}

/* ---------- 软件商店 ---------- */
let softwaresPoll = null;
let softwaresPrompted = false;

function swStatusText(c) {
  if (c.installed || c.status === 'done') return '已安装';
  if (c.status === 'running') return '安装中...';
  if (c.status === 'pending') return '等待中';
  if (c.status === 'error') return '安装失败';
  return '未安装';
}
function swBadgeCls(c) {
  if (c.installed || c.status === 'done') return 'on';
  if (c.status === 'running' || c.status === 'pending') return 'info';
  if (c.status === 'error') return 'off';
  return 'gray';
}
async function renderSoftwares() {
  const r = await API.get('/api/softwares');
  const data = r.data || {};
  const list = Object.values(data).map(c => `
    <div class="card sw-card">
      <div class="sw-icon">${esc(c.icon || '▣')}</div>
      <div class="sw-info">
        <div class="sw-name">${esc(c.label)}</div>
        <div class="sw-desc">${esc(c.desc)}</div>
      </div>
      <div class="sw-right">
        <span class="badge ${swBadgeCls(c)}">${swStatusText(c)}</span>
        <button class="btn small ${c.installed ? 'ghost' : 'primary'}" ${c.installed || c.status === 'running' || c.status === 'pending' ? 'disabled' : ''} onclick="swInstall('${c.name}')">${c.installed ? '已安装' : '安装'}</button>
        ${c.status === 'error' ? '<button class="btn small orange" onclick="swLog(\'' + c.name + '\')">日志</button>' : ''}
      </div>
    </div>`).join('');
  document.getElementById('view').innerHTML = `
    <div class="card"><h3>软件商店
      <span class="more" onclick="swInstallAll()">一键安装全部未装软件</span></h3>
      <p class="form-tip">以下软件未随面板安装，按需安装即可（需 root 权限，安装过程在后台进行，可随时回到本页查看进度）。</p></div>
    ${list}`;
}
async function swInstall(name) {
  const r = await API.post('/api/softwares/install', { name });
  toast(r.msg, r.ok ? 'ok' : 'err');
  if (r.ok) swPoll();
}
async function swInstallAll() {
  const r = await API.post('/api/softwares/install_all', {});
  toast(r.msg, r.ok ? 'ok' : 'err');
  if (r.ok) swPoll();
}
async function swInstallAllFromPrompt() {
  Modal.close();
  await swInstallAll();
}
function swPoll() {
  clearTimeout(softwaresPoll);
  softwaresPoll = setTimeout(async () => {
    try {
      const r = await API.get('/api/softwares');
      if (!r.ok) return;
      const data = r.data || {};
      const busy = Object.values(data).some(c => c.status === 'running' || c.status === 'pending');
      if (Router.current === 'softwares') renderSoftwares();
      if (busy) { swPoll(); }
      else { checkSoftwaresPrompt(); }
    } catch (e) { /* 忽略轮询错误 */ }
  }, 2000);
}
async function checkSoftwaresPrompt() {
  if (softwaresPrompted || !API.token) return;
  try {
    const r = await API.get('/api/softwares');
    if (!r.ok) return;
    const data = r.data || {};
    const missing = Object.values(data).filter(c => !c.installed);
    if (missing.length === 0) return;
    const list = missing.map(c => `<div class="sw-line"><span class="sw-ic">${esc(c.icon || '▣')}</span>${esc(c.label)}</div>`).join('');
    Modal.open('检测到未安装软件',
      `<p class="form-tip" style="margin-bottom:8px">以下组件可提升面板功能（宝塔式按需安装）：</p>
       <div class="sw-list">${list}</div>
       <p class="form-tip" style="margin-top:10px">安装需要 root 权限，将在后台进行，完成后自动提示。</p>`,
      `<button class="btn" onclick="Modal.close()">暂不安装</button>
       <button class="btn primary" onclick="swInstallAllFromPrompt()">一键安装全部</button>`);
    softwaresPrompted = true;
  } catch (e) { /* 忽略 */ }
}

/* ---------- 文件管理 ---------- */
let fmPath = '/';
function fp(p) { return 'decodeURIComponent("' + encodeURIComponent(p) + '")'; }
async function renderFiles() {
  document.getElementById('view').innerHTML = '<div class="empty">加载中...</div>';
  await fmList('/');
}
async function fmList(path) {
  fmPath = path || '/';
  const r = await API.get('/api/files/list?path=' + encodeURIComponent(fmPath));
  if (!r.ok) { document.getElementById('view').innerHTML = '<div class="msg err">' + esc(r.msg) + '</div>'; return; }
  const d = r.data;
  const parts = d.path.split('/').filter(Boolean);
  let crumbs = '<a onclick="fmList(\'/\')">/</a>';
  let acc = '';
  parts.forEach(p => { acc += '/' + p; crumbs += '<span class="sep">/</span><a onclick="fmList(' + fp(acc) + ')">' + esc(p) + '</a>'; });
  const diskPct = Math.round(d.disk_used / d.disk_total * 100);
  let rows = '';
  if (d.parent) rows += '<tr><td class="name-col"><span class="f-ic dir">▸</span><a class="dir-link" onclick="fmList(' + fp(d.parent) + ')">..</a></td><td></td><td></td><td></td><td></td></tr>';
  d.entries.forEach(e => {
    const nameHtml = e.is_dir
      ? '<span class="f-ic dir">▣</span><a class="dir-link" onclick="fmList(' + fp(e.path) + ')">' + esc(e.name) + '</a>'
      : '<span class="f-ic file">▤</span><span>' + esc(e.name) + '</span>';
    rows += '<tr><td class="name-col">' + nameHtml + '</td>' +
      '<td>' + (e.is_dir ? '<span class="badge gray">目录</span>' : e.size_txt) + '</td>' +
      '<td class="perm-tag">' + e.perm + '</td>' +
      '<td>' + esc(e.mtime) + '</td>' +
      '<td class="actions">' +
        (e.is_dir ? '' : '<a class="btn small" onclick="fmEdit(' + fp(e.path) + ')">编辑</a>' +
          '<a class="btn small ghost" onclick="fmDown(' + fp(e.path) + ')">下载</a>') +
        '<a class="btn small" onclick="fmRename(' + fp(e.path) + ',\'' + esc(e.name) + '\')">重命名</a>' +
        '<a class="btn small red" onclick="fmDel(' + fp(e.path) + ')">删除</a>' +
      '</td></tr>';
  });
  document.getElementById('view').innerHTML = `
    <div class="fm-toolbar">
      <div class="crumb">${crumbs}</div>
      <input type="file" id="fmFile" style="display:none" onchange="fmUpload()">
      <button class="btn small" onclick="document.getElementById('fmFile').click()">上传</button>
      <button class="btn small ghost" onclick="fmNewModal('file')">新建文件</button>
      <button class="btn small ghost" onclick="fmNewModal('dir')">新建目录</button>
      <button class="btn small ghost" onclick="fmList(fmPath)">刷新</button>
    </div>
    <div class="card">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
        <span style="font-size:13px;color:#4a5a6e">磁盘：<b class="mono">${d.path}</b></span>
        <span style="font-size:12px;color:#7a8699">已用 ${fmtSize(d.disk_used)} / 共 ${fmtSize(d.disk_total)}（${diskPct}%）</span>
      </div>
      <div class="disk-line"><i style="width:${diskPct}%"></i></div>
      <table class="tbl fm-table" style="margin-top:12px">
        <tr><th>名称</th><th>大小</th><th>权限</th><th>修改时间</th><th></th></tr>
        ${rows || '<tr><td colspan="5"><div class="empty">空目录</div></td></tr>'}
      </table>
    </div>`;
}
async function fmUpload() {
  const f = document.getElementById('fmFile').files[0];
  if (!f) return;
  const fd = new FormData();
  fd.append('file', f);
  fd.append('path', fmPath);
  const r = await fetch('/api/files/upload', { method: 'POST', headers: { 'X-Panel-Token': API.token }, body: fd }).then(x => x.json());
  toast(r.msg, r.ok ? 'ok' : 'err');
  fmList(fmPath);
}
function fmNewModal(kind) {
  Modal.open(kind === 'dir' ? '新建目录' : '新建文件',
    '<div class="form-group"><label>名称</label><input id="fmNewName" placeholder="' + (kind === 'dir' ? '目录名' : '文件名') + '"></div>' +
    '<div class="form-tip">当前位置：<span class="mono">' + esc(fmPath) + '</span></div>',
    '<button class="btn" onclick="Modal.close()">取消</button><button class="btn primary" onclick="fmNew(\'' + kind + '\')">创建</button>');
}
async function fmNew(kind) {
  const name = document.getElementById('fmNewName').value;
  if (!name) return toast('请输入名称', 'err');
  const url = kind === 'dir' ? '/api/files/mkdir' : '/api/files/create';
  const r = await API.post(url, { path: fmPath, name });
  toast(r.msg, r.ok ? 'ok' : 'err');
  if (r.ok) { Modal.close(); fmList(fmPath); }
}
async function fmEdit(path) {
  const r = await API.get('/api/files/content?path=' + encodeURIComponent(path));
  if (!r.ok) return toast(r.msg, 'err');
  Modal.open('编辑文件 - ' + path.split('/').pop(),
    '<div class="form-group"><label>路径：<span class="mono">' + esc(path) + '</span></label>' +
    '<textarea id="fmContent" rows="18" class="mono" style="width:100%">' + esc(r.data.content) + '</textarea></div>',
    '<button class="btn" onclick="Modal.close()">取消</button><button class="btn primary" onclick="fmSave()">保存</button>');
  window._fmEditPath = path;
}
async function fmSave() {
  const r = await API.post('/api/files/write', { path: window._fmEditPath, content: document.getElementById('fmContent').value });
  toast(r.msg, r.ok ? 'ok' : 'err');
  if (r.ok) Modal.close();
}
function fmDown(path) { window.location = '/api/files/download?path=' + encodeURIComponent(path) + '&token=' + API.token; }
async function fmRename(path, oldName) {
  Modal.open('重命名', '<div class="form-group"><label>原名称</label><input value="' + esc(oldName) + '" readonly></div>' +
    '<div class="form-group"><label>新名称</label><input id="fmNewName2" value="' + esc(oldName) + '"></div>',
    '<button class="btn" onclick="Modal.close()">取消</button><button class="btn primary" onclick="fmDoRename(\'' + encodeURIComponent(path) + '\')">确定</button>');
}
async function fmDoRename(epath) {
  const path = decodeURIComponent(epath);
  const r = await API.post('/api/files/rename', { path, new_name: document.getElementById('fmNewName2').value });
  toast(r.msg, r.ok ? 'ok' : 'err');
  if (r.ok) { Modal.close(); fmList(fmPath); }
}
async function fmDel(path) {
  if (!confirm('确定删除该' + (path.endsWith('/') ? '目录' : '文件') + '？删除后不可恢复！')) return;
  const r = await API.del('/api/files?path=' + encodeURIComponent(path));
  toast(r.msg, r.ok ? 'ok' : 'err');
  fmList(fmPath);
}
/* ---------- 安全组 ---------- */
async function renderSecurity() {
  document.getElementById('view').innerHTML = '<div class="empty">加载中...</div>';
  const r = await API.get('/api/security/status');
  if (!r.ok) return;
  const d = r.data || {};
  const ruleSet = {};
  (d.rules || []).forEach(x => { ruleSet[x.proto + ':' + x.port] = x; });
  let openRows = '';
  (d.rules || []).forEach(x => {
    openRows += '<div class="port-row"><div><span class="port-num">' + x.port + '</span> <span class="port-proto">' + esc(x.proto.toUpperCase()) + '</span>' +
      (x.comment ? '<span class="port-comment">' + esc(x.comment) + '</span>' : '') + '</div>' +
      '<button class="btn small red" onclick="secClose(' + x.port + ',\'' + x.proto + '\')">移除</button></div>';
  });
  let listenRows = '';
  (d.listening || []).forEach(p => {
    const key = 'tcp:' + p;
    const opened = !!ruleSet[key];
    listenRows += '<div class="port-row"><div><span class="port-num">' + p + '</span> <span class="port-proto">TCP</span>' +
      (opened ? '' : ' <span class="badge warn">未放行</span>') + '</div>' +
      (opened ? '<span class="badge on">已放行</span>' : '<button class="btn small" onclick="secOpen(' + p + ')">放行</button>') + '</div>';
  });
  document.getElementById('view').innerHTML = `
    <div class="card"><h3>添加放行端口</h3>
      <div class="form-row">
        <div class="form-group" style="max-width:160px"><label>端口</label><input id="secPort" type="number" placeholder="例如 8080"></div>
        <div class="form-group" style="max-width:180px"><label>协议</label><select id="secProto"><option value="tcp">TCP</option><option value="udp">UDP</option><option value="tcp+udp">TCP+UDP</option></select></div>
        <div class="form-group"><label>备注（可选）</label><input id="secComment" placeholder="例如 节点端口"></div>
      </div>
      <button class="btn primary" onclick="secOpenManual()">放行端口</button>
      ${d.fake ? '<span class="form-tip" style="margin-left:10px">当前为非 root 环境（模拟模式），不会真正修改防火墙</span>' : ''}
    </div>
    <div class="card"><h3>已放行端口（防火墙规则）</h3>
      <div class="port-list">${openRows || '<div class="empty">暂无放行规则</div>'}</div></div>
    <div class="card"><h3>系统当前监听端口</h3>
      <div class="sec-legend"><span><span class="dot" style="background:#12a15d"></span>已放行</span><span><span class="dot" style="background:#ff9900"></span>未放行</span></div>
      <div class="port-list" style="margin-top:8px">${listenRows || '<div class="empty">暂无监听端口</div>'}</div></div>`;
}
async function secOpenManual() {
  const port = parseInt(document.getElementById('secPort').value);
  if (!port) return toast('请输入端口', 'err');
  const r = await API.post('/api/security/open', {
    port, proto: document.getElementById('secProto').value,
    comment: document.getElementById('secComment').value,
  });
  toast(r.msg, r.ok ? 'ok' : 'err');
  renderSecurity();
}
async function secOpen(port) {
  const r = await API.post('/api/security/open', { port, proto: 'tcp' });
  toast(r.msg, r.ok ? 'ok' : 'err');
  renderSecurity();
}
async function secClose(port, proto) {
  if (!confirm('移除端口 ' + port + '/' + proto + ' 的放行规则？')) return;
  const r = await API.post('/api/security/close', { port, proto });
  toast(r.msg, r.ok ? 'ok' : 'err');
  renderSecurity();
}
/* ---------- 终端 ---------- */
let term = null;
let termTimer = null;
async function renderTerminal() {
  document.getElementById('view').innerHTML = `
    <div class="card" style="padding:0;overflow:hidden">
      <div class="term-toolbar">
        <span class="tt-title">终端</span>
        <span>bash · 交互式</span>
        <span class="grow"></span>
        <a class="btn small ghost" onclick="termReset()">重置会话</a>
      </div>
      <div id="termBox" class="term-box"></div>
    </div>`;
  await API.post('/api/terminal/start', {});
  if (term) { try { term.dispose(); } catch (e) {} }
  term = new Terminal({
    cursorBlink: true, fontSize: 13,
    fontFamily: 'Menlo, Consolas, "Courier New", monospace',
    theme: { background: '#1b2430', foreground: '#d6e0ec', cursor: '#d6e0ec', selectionBackground: '#33415a' },
  });
  term.open(document.getElementById('termBox'));
  term.write('\r\n\x1b[36mXPanel 终端已连接（bash）\x1b[0m\r\n');
  term.onData(d => { API.post('/api/terminal/input', { data: d }); });
  clearInterval(termTimer);
  termTimer = setInterval(async () => {
    try {
      const r = await API.get('/api/terminal/output');
      if (r.ok && r.data && term) term.write(r.data);
    } catch (e) {}
  }, 250);
}
async function termReset() {
  if (term) { try { term.reset(); } catch (e) {} }
  const r = await API.post('/api/terminal/reset', {});
  if (r.ok && term) term.write('\r\n\x1b[36m--- 终端已重置 ---\x1b[0m\r\n');
}
/* ---------- 辅助：邮箱复制 ---------- */
function wmCopy(url, domain) {
  const full = location.origin + '/webmail/' + domain;
  copyText(full, '网页邮箱地址已复制：' + full);
}
/* ---------- 软件日志 ---------- */
async function swLog(name) {
  const r = await API.get('/api/softwares/log?name=' + name);
  Modal.open('安装日志 - ' + name,
    '<pre class="conf sw-log">' + esc((r.data || {}).log || '（暂无日志）') + '</pre>',
    '<button class="btn" onclick="Modal.close()">关闭</button><button class="btn ghost" onclick="copyText(document.querySelector(\'.sw-log\').textContent,\'日志已复制\')">复制日志</button>');
}

/* ---------- 设置 ---------- */
async function renderSettings() {
  const me = await API.get('/api/me');
  document.getElementById('view').innerHTML = `
    <div class="card"><h3>修改登录密码</h3>
      <div class="form-group" style="max-width:420px"><label>原密码</label><input id="pOld" type="password"></div>
      <div class="form-group" style="max-width:420px"><label>新密码（至少 6 位）</label><input id="pNew" type="password"></div>
      <button class="btn primary" onclick="changePwd()">保存修改</button></div>
    <div class="card"><h3>关于</h3>
      <table class="tbl">
        <tr><td style="width:140px">面板名称</td><td>XPanel 希旭面板</td></tr>
        <tr><td>版本</td><td>v1.0.0</td></tr>
        <tr><td>登录账号</td><td>${esc((me.data || {}).username || '')}</td></tr>
        <tr><td>功能</td><td>网站管理（PHP / Python / 静态）· 节点管理（VMess / VLESS / Trojan）· 邮箱服务（转发 / 独立邮箱 + 网页邮箱）</td></tr>
      </table></div>`;
}
async function changePwd() {
  const r = await API.post('/api/change_password', {
    old_password: document.getElementById('pOld').value,
    new_password: document.getElementById('pNew').value,
  });
  toast(r.msg, r.ok ? 'ok' : 'err');
}

/* ---------- 路由 ---------- */
const Router = {
  current: 'dashboard',
  show(page) {
    this.current = page;
    if (typeof termTimer !== 'undefined' && termTimer) { clearInterval(termTimer); termTimer = null; }
    if (page !== 'terminal' && typeof term !== 'undefined' && term) { try { term.dispose(); term = null; } catch (e) {} }
    document.querySelectorAll('#menu a').forEach(a => a.classList.toggle('active', a.dataset.page === page));
    document.getElementById('pageTitle').textContent = TITLES[page] || '首页';
    const fns = { dashboard: renderDashboard, sites: renderSites, nodes: renderNodes, email: renderEmail, softwares: renderSoftwares, files: renderFiles, security: renderSecurity, terminal: renderTerminal, settings: renderSettings };
    (fns[page] || renderDashboard)();
  },
};
document.querySelectorAll('#menu a').forEach(a => {
  a.addEventListener('click', () => Router.show(a.dataset.page));
});

/* ---------- 登录 ---------- */
const App = {
  async login() {
    const u = document.getElementById('loginUser').value.trim();
    const p = document.getElementById('loginPass').value;
    const msg = document.getElementById('loginMsg');
    const r = await API.post('/api/login', { username: u, password: p });
    if (r.ok) {
      API.token = r.token;
      localStorage.setItem('xp_token', r.token);
      msg.classList.add('hidden');
      this.enter();
    } else {
      msg.textContent = r.msg;
      msg.className = 'msg err';
    }
  },
  enter() {
    document.getElementById('loginPage').classList.add('hidden');
    document.getElementById('app').classList.remove('hidden');
    document.getElementById('topUser').textContent = localStorage.getItem('xp_user') || '';
    API.get('/api/me').then(r => { if (r.ok) document.getElementById('topUser').textContent = r.data.username; });
    Router.show('dashboard');
    checkSoftwaresPrompt();
  },
  forceLogout() {
    localStorage.removeItem('xp_token');
    API.token = '';
    document.getElementById('app').classList.add('hidden');
    document.getElementById('loginPage').classList.remove('hidden');
  },
};
document.getElementById('loginBtn').addEventListener('click', () => App.login());
document.getElementById('loginPass').addEventListener('keydown', e => { if (e.key === 'Enter') App.login(); });
document.getElementById('logoutBtn').addEventListener('click', () => {
  API.post('/api/logout', {}).finally(() => App.forceLogout());
});

/* ---------- 启动 ---------- */
(function init() {
  if (API.token) {
    API.get('/api/me').then(r => r.ok ? App.enter() : App.forceLogout());
  }
})();
