# -*- coding: utf-8 -*-
"""
XPanel 希旭面板 - 软件商店
检测各组件是否安装，并支持后台异步安装（宝塔式按需安装）。
组件不在面板安装脚本中强制安装，登录面板后由用户在软件商店/弹窗中选择安装。
"""
import os
import re
import subprocess
import threading
import time
from flask import Blueprint, request, jsonify

from . import config
from .auth import login_required
from . import utils
from .utils import run_cmd

bp = Blueprint('softwares', __name__)

# ---------------- 组件定义 ----------------
# check: 用于检测是否已安装的命令
# install: 按系统分发的安装命令；'any' 表示通用安装
COMPONENTS = [
    {
        'name': 'nginx',
        'label': 'Nginx 服务器',
        'desc': 'Web 服务器，网站 / PHP / 反向代理运行必需',
        'icon': '▣',
        'check': 'command -v nginx',
        'install': {
            'debian': 'DEBIAN_FRONTEND=noninteractive apt-get install -y nginx',
            'rhel': 'yum install -y nginx',
        },
        'service': 'nginx',
    },
    {
        'name': 'php',
        'label': 'PHP-FPM',
        'desc': 'PHP 运行环境（php8.x + 常用扩展），PHP 网站必需',
        'icon': '℗',
        'check': 'command -v php',
        'install': {
            'debian': "PHPV=\"\"; for v in 8.4 8.3 8.2 8.1 8.0 7.4; do apt-cache show php$v-fpm >/dev/null 2>&1 && { PHPV=$v; break; }; done; if [ -n \"$PHPV\" ]; then DEBIAN_FRONTEND=noninteractive apt-get install -y php${PHPV}-fpm php${PHPV}-cli php${PHPV}-mysql php${PHPV}-curl php${PHPV}-gd php${PHPV}-mbstring php${PHPV}-xml; else DEBIAN_FRONTEND=noninteractive apt-get install -y php-fpm php-cli php-mysql php-curl php-gd php-mbstring php-xml; fi",
            'rhel': 'yum install -y epel-release && yum install -y php-fpm php-cli php-mysqlnd php-curl php-gd php-mbstring php-xml',
        },
        'service': 'php-fpm',
    },
    {
        'name': 'mysql',
        'label': 'MySQL / MariaDB',
        'desc': '数据库服务（MariaDB），网站数据存储',
        'icon': '◈',
        'check': 'command -v mysql || command -v mariadb',
        'install': {
            'debian': 'DEBIAN_FRONTEND=noninteractive apt-get install -y mariadb-server',
            'rhel': 'yum install -y mariadb-server',
        },
        'service': 'mariadb',
    },
    {
        'name': 'postfix',
        'label': 'Postfix 邮件服务器',
        'desc': 'SMTP 邮件收发，邮箱服务（转发 / 独立邮箱）必需',
        'icon': '✉',
        'check': 'command -v postfix',
        'install': {
            'debian': 'DEBIAN_FRONTEND=noninteractive apt-get install -y postfix postfix-mysql || DEBIAN_FRONTEND=noninteractive apt-get install -y postfix',
            'rhel': 'yum install -y postfix',
        },
        'service': 'postfix',
    },
    {
        'name': 'dovecot',
        'label': 'Dovecot 收信服务',
        'desc': 'IMAP / POP3 收信，独立邮箱（网页邮箱）必需',
        'icon': '✆',
        'check': 'command -v dovecot',
        'install': {
            'debian': 'DEBIAN_FRONTEND=noninteractive apt-get install -y dovecot-imapd dovecot-pop3d || DEBIAN_FRONTEND=noninteractive apt-get install -y dovecot-core dovecot-imapd dovecot-pop3d || DEBIAN_FRONTEND=noninteractive apt-get install -y dovecot',
            'rhel': 'yum install -y dovecot',
        },
        'service': 'dovecot',
    },
    {
        'name': 'xray',
        'label': 'Xray 核心',
        'desc': '代理节点运行核心（VMess / VLESS / Trojan）',
        'icon': '◎',
        'check': 'command -v xray',
        'install': {
            'any': 'download',
        },
        'service': 'xray',
    },
]

# ---------------- 运行状态（内存） ----------------
# {name: {'status': running|done|error, 'message': str, 'start': ts}}
_state = {}
_state_lock = threading.Lock()

def _log_file(name):
    return os.path.join(config.DATA_DIR, 'logs', f'install_{name}.log')


def _log(name, text):
    try:
        os.makedirs(os.path.dirname(_log_file(name)), exist_ok=True)
        with open(_log_file(name), 'a', encoding='utf-8') as f:
            f.write(text + '\n')
    except Exception:
        pass

# 非 root 测试模式：环境变量指定模拟安装命令
# 仅供沙箱 / 测试用：XPANEL_FAKE_INSTALL=1 时不执行真实 apt，直接标记成功
FAKE_INSTALL = os.environ.get('XPANEL_FAKE_INSTALL', '') == '1'


def detect_os():
    """返回 debian / rhel / unknown"""
    if os.path.exists('/etc/debian_version'):
        return 'debian'
    try:
        with open('/etc/os-release') as f:
            content = f.read()
        if re.search(r'(?i)ubuntu|debian', content):
            return 'debian'
        if re.search(r'(?i)centos|redhat|fedora|rocky|almalinux', content):
            return 'rhel'
    except Exception:
        pass
    return 'debian'  # 默认 debian


def _is_installed(name):
    comp = _by_name(name)
    if not comp:
        return False
    code, _, _ = run_cmd(comp['check'], timeout=15)
    return code == 0


def _by_name(name):
    for c in COMPONENTS:
        if c['name'] == name:
            return c
    return None


def scan():
    """返回全部组件当前状态"""
    result = {}
    for c in COMPONENTS:
        installed = _is_installed(c['name'])
        with _state_lock:
            st = _state.get(c['name'], {})
        if installed:
            status = 'done'
            message = '已安装'
        else:
            status = st.get('status', 'idle')
            message = st.get('message', '未安装')
        result[c['name']] = {
            'label': c['label'],
            'desc': c['desc'],
            'icon': c['icon'],
            'installed': installed,
            'status': status,
            'message': message,
        }
    return result


def _ensure_xray_config():
    """确保 Xray 存在可用配置（否则 systemd 启动即失败）"""
    cfg = '/usr/local/etc/xray/config.json'
    try:
        os.makedirs('/usr/local/etc/xray', exist_ok=True)
        if not os.path.exists(cfg):
            with open(cfg, 'w', encoding='utf-8') as f:
                f.write('{\n'
                        '  "log": { "loglevel": "warning" },\n'
                        '  "inbounds": [],\n'
                        '  "outbounds": [ { "protocol": "freedom", "tag": "direct" } ]\n'
                        '}\n')
    except Exception:
        pass


def _install_xray_binary():
    """直接下载 Xray 官方预编译二进制并部署（官方脚本不可用时的兜底方案）。
    返回 (code, stdout, stderr)。"""
    bin_path = '/usr/local/bin/xray'
    tmp_zip = '/tmp/xpanel_xray.zip'
    tmp_dir = '/tmp/xpanel_xray_dist'
    steps = [
        ('安装 unzip', "DEBIAN_FRONTEND=noninteractive apt-get install -y unzip || yum install -y unzip || true"),
        ('下载 Xray 二进制', f"curl -L -o {tmp_zip} https://github.com/XTLS/Xray-core/releases/latest/download/Xray-linux-64.zip"),
        ('解压', f"rm -rf {tmp_dir} && mkdir -p {tmp_dir} && unzip -o {tmp_zip} -d {tmp_dir}"),
        ('安装二进制', f"install -m 755 {tmp_dir}/xray {bin_path}"),
    ]
    for label, cmd in steps:
        code, out, err = run_cmd(cmd, timeout=300)
        if code != 0:
            return code, out, err or f'步骤[{label}]失败'
    # 生成 systemd unit
    unit = '/etc/systemd/system/xray.service'
    unit_body = """[Unit]
Description=Xray Service
After=network.target nss-lookup.target

[Service]
Type=simple
ExecStart=/usr/local/bin/xray run -config /usr/local/etc/xray/config.json
Restart=on-failure
RestartPreventExitStatus=23

[Install]
WantedBy=multi-user.target
"""
    try:
        _ensure_xray_config()
        with open(unit, 'w') as f:
            f.write(unit_body)
        run_cmd('systemctl daemon-reload && systemctl enable xray 2>/dev/null', timeout=30)
    except Exception as e:
        return 1, '', f'写入 systemd unit 失败: {e}'
    return 0, 'Xray 二进制部署完成', ''


def _set_state(name, status, message):
    with _state_lock:
        _state[name] = {'status': status, 'message': message, 'start': time.time()}


def _install_worker(name):
    comp = _by_name(name)
    if not comp:
        return
    _set_state(name, 'running', '正在安装...')
    _log(name, f"[{time.strftime('%H:%M:%S')}] === 开始安装 {comp['label']} ===")
    try:
        if FAKE_INSTALL:
            time.sleep(1)
            _set_state(name, 'done', '安装完成（测试模式）')
            _log(name, '测试模式：跳过真实安装')
            return
        os_family = detect_os()
        if name == 'xray':
            # Xray 安装：优先官方脚本，脚本无效时回退直接下载预编译二进制
            script = '/tmp/xpanel_xray_install.sh'
            code, out, err = run_cmd(
                f"curl -Ls -o {script} https://github.com/XTLS/Xray-install/raw/main/install-release.sh",
                timeout=120)
            _log(name, f'下载安装脚本: exit={code}')
            ok_script = False
            if code == 0 and os.path.exists(script):
                shead = ''
                try:
                    with open(script, 'rb') as f:
                        shead = f.read(200).decode('utf-8', 'ignore')
                except Exception:
                    shead = ''
                if shead.startswith('#!/'):
                    ok_script = True
                else:
                    _log(name, f'安装脚本内容异常（非 shell 脚本）: {shead[:80]!r}')
            if ok_script:
                _log(name, f'执行安装脚本: bash {script} install')
                code, out, err = run_cmd(f"bash {script} install", timeout=900)
                _log(name, f'官方脚本 exit={code}')
                _ensure_xray_config()
            else:
                _log(name, '官方脚本不可用，尝试直接下载 Xray 预编译二进制')
                code, out, err = _install_xray_binary()
            try:
                os.remove(script)
            except Exception:
                pass
        else:
            cmd = comp['install'].get(os_family) or comp['install'].get('any')
            if not cmd:
                _set_state(name, 'error', '当前系统不支持自动安装，请手动安装')
                return
            if os_family == 'debian':
                _log(name, 'apt-get update ...')
                ucode, uout, uerr = run_cmd('apt-get update', timeout=300)
                if ucode != 0:
                    _log(name, f'apt-get update 失败(exit={ucode}): {(uerr or uout)[-800:]}')
            elif os_family == 'rhel':
                run_cmd('yum makecache', timeout=180)
            _log(name, f'执行: {cmd}')
            code, out, err = run_cmd(cmd, timeout=900)
        _log(name, f'安装命令 exit={code}')
        if err:
            _log(name, f'stderr: {err[-1500:]}')
        if out:
            _log(name, f'stdout: {out[-1500:]}')
        # 启动服务
        svc = comp.get('service')
        if svc:
            _log(name, f'启动服务 {svc}')
            if name == 'php':
                # Debian 上服务名可能是 php8.2-fpm / php8.1-fpm，探测实际名字
                run_cmd(
                    'SVC=$(systemctl list-unit-files 2>/dev/null | grep -oE "php[0-9.]*-fpm\\.service" | head -1); '
                    'if [ -n "$SVC" ]; then SVC=${SVC%.service}; systemctl enable "$SVC" 2>/dev/null; systemctl restart "$SVC" 2>/dev/null; '
                    'else systemctl enable php-fpm 2>/dev/null; systemctl restart php-fpm 2>/dev/null; fi',
                    timeout=60)
            else:
                run_cmd(f"systemctl enable {svc} 2>/dev/null; systemctl restart {svc} 2>/dev/null", timeout=60)
        if _is_installed(name):
            _set_state(name, 'done', '安装完成')
            _log(name, '=== 安装完成 ===')
        else:
            msg = (err or out or '')[-300:] or '校验失败'
            _set_state(name, 'error', f'安装失败: {msg}')
            _log(name, f'=== 安装失败: {msg} ===')
    except Exception as e:
        _set_state(name, 'error', f'安装异常: {str(e)}')
        _log(name, f'=== 异常: {str(e)} ===')


# ---------------- API ----------------
@bp.get('/api/softwares')
@login_required
def api_list():
    return jsonify({'ok': True, 'data': scan()})


@bp.post('/api/softwares/install')
@login_required
def api_install():
    body = request.get_json(silent=True) or {}
    name = (body.get('name') or '').strip()
    comp = _by_name(name)
    if not comp:
        return jsonify({'ok': False, 'msg': '未知组件'})
    with _state_lock:
        st = _state.get(name, {})
        if st.get('status') == 'running':
            return jsonify({'ok': False, 'msg': f'{comp["label"]} 正在安装中'})
        if st.get('status') == 'done':
            return jsonify({'ok': False, 'msg': f'{comp["label"]} 已安装'})
    if _is_installed(name):
        return jsonify({'ok': False, 'msg': f'{comp["label"]} 已安装'})
    t = threading.Thread(target=_install_worker, args=(name,), daemon=True)
    t.start()
    return jsonify({'ok': True, 'msg': f'开始安装 {comp["label"]}'})


@bp.post('/api/softwares/install_all')
@login_required
def api_install_all():
    started = []
    for c in COMPONENTS:
        if _is_installed(c['name']):
            continue
        with _state_lock:
            st = _state.get(c['name'], {})
            if st.get('status') == 'running' or st.get('status') == 'done':
                continue
        _set_state(c['name'], 'pending', '等待安装...')
        t = threading.Thread(target=_install_worker, args=(c['name'],), daemon=True)
        t.start()
        started.append(c['label'])
    return jsonify({'ok': True, 'msg': f'已开始安装 {len(started)} 个组件',
                    'data': {'started': started}})


@bp.get('/api/softwares/log')
@login_required
def api_log():
    name = request.args.get('name') or ''
    if not _by_name(name):
        return jsonify({'ok': False, 'msg': '未知组件'})
    log = utils.read_file(_log_file(name))
    # 只返回最近 120 行
    lines = log.strip().split('\n')
    if len(lines) > 120:
        lines = lines[-120:]
    return jsonify({'ok': True, 'data': {'name': name, 'log': '\n'.join(lines)}})
