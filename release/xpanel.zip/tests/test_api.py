# -*- coding: utf-8 -*-
"""
XPanel 希旭面板 - 端到端 API 测试
运行: 在项目根目录执行 python3 tests/test_api.py
需要先设置测试路径环境变量（见 test 脚本或 install.sh）
"""
import base64
import json
import os
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 测试用临时目录（避免污染系统）
_BASE = os.path.join(tempfile.gettempdir(), 'xpanel_test')
os.makedirs(_BASE, exist_ok=True)
os.environ['XPANEL_WWW_ROOT'] = os.path.join(_BASE, 'wwwroot')
os.environ['XPANEL_NGINX_CONF_DIR'] = os.path.join(_BASE, 'nginx')
os.environ['XPANEL_MAIL_ROOT'] = os.path.join(_BASE, 'mail')
os.environ['XPANEL_POSTFIX_MAIN_CF'] = os.path.join(_BASE, 'postfix/main.cf')
os.environ['XPANEL_POSTFIX_VIRTUAL'] = os.path.join(_BASE, 'postfix/virtual')
os.environ['XPANEL_POSTFIX_VMAILBOX'] = os.path.join(_BASE, 'postfix/vmailbox')
os.environ['XPANEL_DOVECOT_CONF_DIR'] = os.path.join(_BASE, 'dovecot')
os.environ['XPANEL_DOVECOT_CONF'] = os.path.join(_BASE, 'dovecot/dovecot.conf')
os.environ['XPANEL_DOVECOT_PASSWD'] = os.path.join(_BASE, 'dovecot/dovecot-passwd')
os.environ['XPANEL_SYSTEMD_DIR'] = os.path.join(_BASE, 'systemd')
# 软件商店：测试模式（不执行真实 apt 安装）
os.environ['XPANEL_FAKE_INSTALL'] = '1'
# 清理旧的测试数据目录（项目 data 目录）
_PROJ_DATA = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data')
import shutil
if os.path.isdir(_PROJ_DATA):
    try:
        shutil.rmtree(_PROJ_DATA)
    except Exception:
        pass

from xpanel.app import app

app.config['TESTING'] = True
c = app.test_client()

passed, failed = 0, 0


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1
        print(f'  [PASS] {name}')
    else:
        failed += 1
        print(f'  [FAIL] {name} {extra}')


print('== 1. 认证 ==')
r = c.post('/api/login', json={'username': 'admin', 'password': 'xpanel888'})
check('默认账号登录', r.status_code == 200 and r.get_json()['ok'])
tok = r.get_json()['token']
H = {'X-Panel-Token': tok}
check('错误密码被拒', c.post('/api/login', json={'username': 'admin', 'password': 'bad'}).get_json()['ok'] is False)
check('无 token 被拒', c.get('/api/system/overview').status_code == 401)
check('改密码', c.post('/api/change_password', json={'old_password': 'xpanel888', 'new_password': 'newpass123'}, headers=H).get_json()['ok'])
check('新密码登录', c.post('/api/login', json={'username': 'admin', 'password': 'newpass123'}).get_json()['ok'])
# 改回
c.post('/api/change_password', json={'old_password': 'newpass123', 'new_password': 'xpanel888'}, headers=H)

print('== 2. 系统监控 ==')
r = c.get('/api/system/overview', headers=H).get_json()
check('系统总览', r['ok'] and 'data' in r and 'cpu_percent' in r['data'])
r = c.get('/api/system/services', headers=H).get_json()
check('服务状态', r['ok'] and isinstance(r['data'], list))
r = c.get('/api/system/cpu_history', headers=H).get_json()
check('CPU 历史采样', r['ok'] and len(r['data']) >= 2)

print('== 3. 网站管理 ==')
for st, dom in (('php', 'php.example.com'), ('python', 'py.example.com'), ('static', 'st.example.com')):
    body = {'name': st, 'domain': dom, 'site_type': st, 'php_version': '8.1', 'port': 8001}
    if st == 'python':
        body['start_command'] = 'gunicorn -b 127.0.0.1:8001 -w 2 app:app'
    r = c.post('/api/sites', json=body, headers=H)
    check(f'创建 {st} 站点', r.get_json()['ok'], r.get_data(as_text=True))
# Python 项目无域名也可创建（启动命令模式）
r = c.post('/api/sites', json={'name': 'pynodom', 'site_type': 'python', 'port': 8002,
                               'start_command': 'python3 app.py'}, headers=H)
check('Python 项目无域名创建', r.get_json()['ok'], r.get_data(as_text=True))
r = c.post('/api/sites', json={'name': 'pybad', 'site_type': 'python', 'port': 8003}, headers=H)
check('Python 缺启动命令被拒', r.get_json()['ok'] is False)
r = c.get('/api/sites', headers=H).get_json()
check('站点列表 4 个（含无域名 Python 项目）', len(r['data']) == 4)
r = c.get('/api/sites/1/config', headers=H).get_json()
check('PHP 站点含 fastcgi 配置', 'fastcgi' in r['data']['nginx_conf'])
r = c.get('/api/sites/2/config', headers=H).get_json()
check('Python 站点含反向代理', 'proxy_pass' in r['data']['nginx_conf'])
r = c.get('/api/sites/3/config', headers=H).get_json()
check('静态站点 index', 'try_files' in r['data']['nginx_conf'])
# 检查生成的站点文件
check('PHP 站点根目录有 index.php', os.path.exists(os.path.join(_BASE, 'wwwroot/php.example.com/index.php')))
check('静态站点根目录有 index.html', os.path.exists(os.path.join(_BASE, 'wwwroot/st.example.com/index.html')))
# 重复域名拒绝
r = c.post('/api/sites', json={'name': 'dup', 'domain': 'php.example.com', 'site_type': 'php'}, headers=H)
check('重复域名被拒', r.get_json()['ok'] is False)
r = c.post('/api/sites/1/toggle', headers=H)
check('站点启停', r.get_json()['ok'])

print('== 4. 节点管理 ==')
r = c.get('/api/nodes/status', headers=H).get_json()
check('Xray 状态接口', r['ok'] and 'installed' in r['data'])
r = c.post('/api/nodes', json={'name': 'hk', 'protocol': 'vmess', 'port': 10086, 'network': 'tcp'}, headers=H)
check('创建 vmess 节点', r.get_json()['ok'])
r = c.post('/api/nodes', json={'name': 'ws', 'protocol': 'vmess', 'port': 10087, 'network': 'ws', 'path': '/ray'}, headers=H)
check('创建 ws 节点', r.get_json()['ok'])
r = c.post('/api/nodes', json={'name': 'dup', 'protocol': 'vmess', 'port': 10086, 'network': 'tcp'}, headers=H)
check('重复端口被拒', r.get_json()['ok'] is False)
r = c.get('/api/nodes', headers=H).get_json()
check('节点列表 2 个', len(r['data']) == 2)
n = r['data'][0]
# 验证 vmess 链接可解码
b64 = n['share_link'].split('vmess://')[1]
decoded = json.loads(base64.b64decode(b64 + '===').decode())
check('vmess 链接可解码', decoded['port'] == str(n['port']) and decoded['id'] == n['uuid'])
r = c.get('/api/nodes/1', headers=H).get_json()
check('节点详情含 Xray JSON', json.loads(r['data']['json'])['protocol'] == 'vmess')
r = c.post('/api/nodes/1/toggle', headers=H)
check('节点启停', r.get_json()['ok'])

print('== 5. 邮箱管理 ==')
r = c.post('/api/email/domains', json={'domain': 'fwd.example.com', 'mode': 'forward', 'forward_target': 'me@qq.com'}, headers=H)
check('创建转发域名', r.get_json()['ok'])
fwd_id = r.get_json()['id']
r = c.post('/api/email/accounts', json={'domain_id': fwd_id, 'prefix': 'sales', 'account_type': 'alias'}, headers=H)
check('创建转发别名', r.get_json()['ok'])
r = c.post('/api/email/domains', json={'domain': 'mail.example.net', 'mode': 'standalone'}, headers=H)
check('创建独立邮箱域名', r.get_json()['ok'])
std_id = r.get_json()['id']
r = c.post('/api/email/accounts', json={'domain_id': std_id, 'prefix': 'bob', 'account_type': 'mailbox', 'password': 'bob123456'}, headers=H)
check('创建独立邮箱账号', r.get_json()['ok'])
# 校验生成的配置文件
virtual = open(os.path.join(_BASE, 'postfix/virtual')).read()
check('转发配置含 sales@fwd.example.com→me@qq.com', f'sales@fwd.example.com\tme@qq.com' in virtual)
vmailbox = open(os.path.join(_BASE, 'postfix/vmailbox')).read()
check('独立邮箱映射含 bob', 'bob@mail.example.net' in vmailbox)
pwdf = open(os.path.join(_BASE, 'dovecot/dovecot-passwd')).read()
check('Dovecot 密码文件含 bob', 'bob@mail.example.net:{PLAIN}bob123456' in pwdf)

print('== 6. 网页邮箱 Webmail ==')
# 投放一封测试邮件
md = os.path.join(_BASE, 'mail/mail.example.net/bob/Maildir/new')
os.makedirs(md, exist_ok=True)
with open(os.path.join(md, '1.test'), 'w', encoding='utf-8') as f:
    f.write("From: alice@example.com\nTo: bob@mail.example.net\n"
            "Subject: =?utf-8?B?5rWL6K+V5L2T6aqM?=\n\n这是测试邮件\n")
r = c.get('/api/webmail/mail.example.net/inbox')
check('未登录访问被拒', r.get_json()['ok'] is False)
r = c.post('/api/webmail/mail.example.net/login', json={'prefix': 'bob', 'password': 'bob123456'})
check('Webmail 登录', r.get_json()['ok'])
wtok = r.get_json()['token']
WH = {'X-WM-Token': wtok}
r = c.get('/api/webmail/mail.example.net/inbox', headers=WH).get_json()
check('收件箱有 1 封', len(r['data']['new']) == 1)
r = c.get('/api/webmail/mail.example.net/read?box=new&file=1.test', headers=WH).get_json()
check('读信正文正常', r['ok'] and '测试邮件' in r['data']['body'], repr(r['data'].get('body')))
check('主题解码正常', r['data']['subject'] == '测试体验', r['data']['subject'])
# 非管理员不能管理账号
r = c.post('/api/webmail/mail.example.net/login', json={'prefix': 'admin', 'password': ''})
# 用 admin 账号
r = c.get('/api/email/domains', headers=H).get_json()
admin_acct = [a for a in r['data'] if a['domain'] == 'mail.example.net'][0]['accounts'][0]
admin_pwd = admin_acct['password']
r = c.post('/api/webmail/mail.example.net/login', json={'prefix': 'admin', 'password': admin_pwd})
wtok2 = r.get_json()['token']
r = c.get('/api/webmail/mail.example.net/accounts', headers={'X-WM-Token': wtok2}).get_json()
check('admin 可管理账号', r['ok'])

print('== 7. 软件商店 ==')
r = c.get('/api/softwares', headers=H).get_json()
check('软件列表含 6 个组件', r['ok'] and len(r['data']) == 6)
sw_names = set(r['data'].keys())
check('组件齐全', {'nginx', 'php', 'mysql', 'postfix', 'dovecot', 'xray'} <= sw_names)
r = c.post('/api/softwares/install', json={'name': 'php'}, headers=H).get_json()
check('开始安装 php', r['ok'])
# 等后台安装完成
import time
for _ in range(10):
    st = c.get('/api/softwares', headers=H).get_json()['data']['php']['status']
    if st == 'done':
        break
    time.sleep(0.3)
r = c.get('/api/softwares', headers=H).get_json()
check('php 安装完成状态', r['data']['php']['status'] == 'done')
r = c.post('/api/softwares/install', json={'name': 'php'}, headers=H)
check('已装组件拒绝重复安装', r.get_json()['ok'] is False)
r = c.post('/api/softwares/install', json={'name': 'nope'}, headers=H)
check('未知组件被拒', r.get_json()['ok'] is False)
r = c.post('/api/softwares/install_all', headers=H)
check('一键安装全部接口', r.get_json()['ok'])
# 未登录访问被拒
check('软件接口需登录', c.get('/api/softwares').status_code == 401)

print('== 8. 面板页面 ==')
check('首页 200', c.get('/').status_code == 200)
check('前端 JS 200', c.get('/static/js/app.js').status_code == 200)
check('前端 CSS 200', c.get('/static/css/style.css').status_code == 200)
check('Webmail 页面 200', c.get('/webmail/mail.example.net').status_code == 200)


print('== 7. 文件管理 ==')
r = c.get('/api/files/list?path=' + _BASE, headers=H).get_json()
check('文件列表', r['ok'] and isinstance(r['data']['entries'], list))
r = c.post('/api/files/mkdir', json={'path': _BASE, 'name': 'fm_test'}, headers=H)
check('新建目录', r.get_json()['ok'])
r = c.post('/api/files/create', json={'path': os.path.join(_BASE, 'fm_test'), 'name': 'hello.txt'}, headers=H)
check('新建文件', r.get_json()['ok'])
r = c.post('/api/files/write', json={'path': os.path.join(_BASE, 'fm_test/hello.txt'), 'content': 'hi'}, headers=H)
check('写入文件', r.get_json()['ok'])
r = c.get('/api/files/content?path=' + os.path.join(_BASE, 'fm_test/hello.txt'), headers=H).get_json()
check('读取文件内容', r['ok'] and r['data']['content'] == 'hi')
r = c.post('/api/files/rename', json={'path': os.path.join(_BASE, 'fm_test/hello.txt'), 'new_name': 'renamed.txt'}, headers=H)
check('重命名', r.get_json()['ok'])
r = c.post('/api/files/rename', json={'path': os.path.join(_BASE, 'fm_test/renamed.txt'), 'new_name': '../../evil'}, headers=H)
check('非法重命名被拒', r.get_json()['ok'] is False)
r = c.delete('/api/files?path=' + os.path.join(_BASE, 'fm_test/renamed.txt'), headers=H)
check('删除文件', r.get_json()['ok'])
r = c.delete('/api/files?path=' + os.path.join(_BASE, 'fm_test'), headers=H)
check('删除目录', r.get_json()['ok'])
r = c.delete('/api/files?path=/', headers=H)
check('保护路径不可删', r.get_json()['ok'] is False)

print('== 8. 安全组 ==')
r = c.get('/api/security/status', headers=H).get_json()
check('安全状态', r['ok'] and 'rules' in r['data'] and 'listening' in r['data'])
r = c.post('/api/security/open', json={'port': 8080, 'proto': 'tcp', 'comment': 'test'}, headers=H)
check('放行端口', r.get_json()['ok'])
r = c.post('/api/security/open', json={'port': 99999, 'proto': 'tcp'}, headers=H)
check('非法端口被拒', r.get_json()['ok'] is False)
r = c.post('/api/security/open', json={'port': 8080, 'proto': 'icmp'}, headers=H)
check('非法协议被拒', r.get_json()['ok'] is False)
r = c.post('/api/security/close', json={'port': 8080, 'proto': 'tcp'}, headers=H)
check('移除端口', r.get_json()['ok'])

print('== 9. Web 终端 ==')
r = c.post('/api/terminal/start', headers=H)
check('终端启动', r.get_json()['ok'])
r = c.post('/api/terminal/input', json={'data': 'echo xpanel_term_ok\n'}, headers=H)
check('终端输入', r.get_json()['ok'])
import time
time.sleep(0.5)
r = c.get('/api/terminal/output', headers=H).get_json()
check('终端输出回显', r['ok'] and 'xpanel_term_ok' in r['data'], r.get('data', '')[:60])
r = c.post('/api/terminal/reset', headers=H)
check('终端重置', r.get_json()['ok'])

print('== 10. 软件商店日志 ==')
r = c.get('/api/softwares/log?name=nginx', headers=H).get_json()
check('软件日志接口', r['ok'] and 'log' in r['data'])
r = c.get('/api/softwares/log?name=nonexist', headers=H).get_json()
check('未知组件日志被拒', r['ok'] is False)

print(f'\n========== 结果: {passed} 通过, {failed} 失败 ==========')
sys.exit(1 if failed else 0)
