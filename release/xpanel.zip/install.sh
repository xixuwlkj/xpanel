#!/bin/bash
# ============================================================
#  XPanel 希旭面板 一键安装脚本（仅安装面板本体）
#
#  Nginx / PHP / MySQL / Postfix / Dovecot / Xray 等组件
#  不在安装脚本中强制安装 —— 登录面板后通过
#  「软件商店」弹窗按需安装（宝塔式体验）。
#
#  用法（root 下执行）:
#     bash install.sh
#  可选环境变量:
#     PANEL_PORT=8888         面板端口
#     ADMIN_USER=xx           管理员用户名（不填则随机生成/沿用已有）
#     ADMIN_PASS=xxxx         管理员密码（不填则随机生成）
#     NO_SSL=1                不生成自签名证书（默认生成并开启 HTTPS）
#  容器/测试环境:
#     XPANEL_INSTALL_DIR=/xx  安装目录（默认 /www/server/xpanel）
#     XPANEL_SKIP_ROOT=1      跳过 root 检查（Docker/CI 用）
#     XPANEL_SKIP_SYSTEMD=1   跳过 systemctl 操作（Docker/CI 用）
#     XPANEL_WWW_ROOT=/xx     网站根目录（默认 /www/wwwroot）
#     XPANEL_MAIL_ROOT_DIR=/xx  邮件根目录（默认 /var/mail/vhosts）
# ============================================================
set -e
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'
PANEL_PORT="${PANEL_PORT:-8888}"
INSTALL_DIR="${XPANEL_INSTALL_DIR:-/www/server/xpanel}"
WWW_ROOT="${XPANEL_WWW_ROOT:-/www/wwwroot}"
NGINX_VHOST_DIR="${XPANEL_NGINX_VHOST_DIR:-/www/server/nginx/conf/vhost}"
MAIL_ROOT_DIR="${XPANEL_MAIL_ROOT_DIR:-/var/mail/vhosts}"

echo -e "${BLUE}============================================${NC}"
echo -e "${BLUE}   XPanel 希旭面板 安装程序 v1.3.0${NC}"
echo -e "${BLUE}   （面板本体，组件请进面板软件商店安装）${NC}"
echo -e "${BLUE}============================================${NC}"

# ---------- 0. 账号（未显式指定时：已有配置则沿用，否则随机生成） ----------
if [ -z "$ADMIN_USER" ] && [ -f "$INSTALL_DIR/data/panel.json" ]; then
  ADMIN_USER="$(python3 -c "import json;print(json.load(open('$INSTALL_DIR/data/panel.json')).get('admin_user',''))" 2>/dev/null || true)"
fi
if [ -z "$ADMIN_USER" ]; then
  ADMIN_USER="xpanel$(openssl rand -hex 2 2>/dev/null || echo 0000)"
fi

# ---------- 1. 环境检查 ----------
if [ "$(id -u)" != "0" ] && [ -z "$XPANEL_SKIP_ROOT" ]; then
  echo -e "${RED}[错误] 请使用 root 用户执行安装（sudo -i 或 sudo bash install.sh）${NC}"
  exit 1
fi
if [ -d "$INSTALL_DIR" ]; then
  echo -e "${YELLOW}[提示] 检测到已有安装目录 $INSTALL_DIR，将覆盖更新文件（数据保留）${NC}"
fi

# ---------- 2. 系统检测 ----------
if [ -f /etc/debian_version ] || { [ -f /etc/os-release ] && grep -qiE 'ubuntu|debian' /etc/os-release; }; then
  OS_FAMILY="debian"
  PKG_INSTALL="apt-get install -y"
  PKG_UPDATE="apt-get update"
elif [ -f /etc/redhat-release ] || grep -qiE 'centos|redhat|fedora|rocky|almalinux' /etc/os-release 2>/dev/null; then
  OS_FAMILY="rhel"
  PKG_INSTALL="yum install -y"
  PKG_UPDATE="yum makecache"
else
  echo -e "${RED}[错误] 暂不支持该系统，支持 Ubuntu/Debian/CentOS${NC}"
  exit 1
fi
echo -e "${GREEN}[1/6] 系统: $OS_FAMILY ${NC}"

# ---------- 3. 面板本体依赖（curl / python3 / openssl） ----------
echo -e "${GREEN}[2/6] 检查面板运行依赖 (curl / python3 / openssl) ${NC}"
if ! command -v curl >/dev/null 2>&1; then
  echo "  安装 curl ..."
  $PKG_UPDATE >/dev/null 2>&1 || true
  $PKG_INSTALL curl >/dev/null 2>&1 || true
fi
if ! command -v python3 >/dev/null 2>&1; then
  echo "  安装 python3 ..."
  $PKG_UPDATE >/dev/null 2>&1 || true
  $PKG_INSTALL python3 >/dev/null 2>&1 || true
fi
if ! command -v openssl >/dev/null 2>&1; then
  echo "  安装 openssl ..."
  $PKG_UPDATE >/dev/null 2>&1 || true
  $PKG_INSTALL openssl >/dev/null 2>&1 || true
fi
if ! command -v python3 >/dev/null 2>&1; then
  echo -e "${RED}[错误] python3 安装失败，请手动安装后重试${NC}"
  exit 1
fi
# 确保 venv 支持可用
echo "  检查 venv 支持 ..."
if ! python3 -m venv --help >/dev/null 2>&1; then
  $PKG_UPDATE >/dev/null 2>&1 || true
  if [ "$OS_FAMILY" = "debian" ]; then
    $PKG_INSTALL python3-venv python3-pip >/dev/null 2>&1 || true
  else
    $PKG_INSTALL python3-virtualenv python3-pip >/dev/null 2>&1 || true
  fi
fi

# ---------- 4. 部署面板 ----------
echo -e "${GREEN}[3/6] 部署面板到 $INSTALL_DIR${NC}"
mkdir -p "$INSTALL_DIR"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cp -r "$SCRIPT_DIR/xpanel" "$INSTALL_DIR/"
cp -r "$SCRIPT_DIR/static" "$INSTALL_DIR/"
cp -r "$SCRIPT_DIR/templates" "$INSTALL_DIR/"
if [ -d "$SCRIPT_DIR/sh" ]; then cp -r "$SCRIPT_DIR/sh" "$INSTALL_DIR/" 2>/dev/null || true; fi

# 创建虚拟环境并安装依赖
NEED_RECREATE=0
if [ ! -d "$INSTALL_DIR/venv/bin/python3" ]; then
  NEED_RECREATE=1
elif ! grep -q "include-system-site-packages = true" "$INSTALL_DIR/venv/pyvenv.cfg" 2>/dev/null; then
  NEED_RECREATE=1
fi
if [ "$NEED_RECREATE" = "1" ]; then
  echo "  创建 Python 虚拟环境 ..."
  rm -rf "$INSTALL_DIR/venv"
  if ! python3 -m venv --without-pip --system-site-packages "$INSTALL_DIR/venv" 2>/tmp/xpanel_venv_err.log; then
    $PKG_UPDATE >/dev/null 2>&1 || true
    if [ "$OS_FAMILY" = "debian" ]; then
      $PKG_INSTALL python3-venv python3-pip >/dev/null 2>&1 || true
    else
      $PKG_INSTALL python3-virtualenv python3-pip >/dev/null 2>&1 || true
    fi
    if ! python3 -m venv --without-pip --system-site-packages "$INSTALL_DIR/venv" 2>>/tmp/xpanel_venv_err.log; then
      echo -e "${RED}[错误] 虚拟环境创建失败：${NC}"
      tail -20 /tmp/xpanel_venv_err.log 2>/dev/null
      exit 1
    fi
  fi
fi
echo "  安装面板 Python 依赖 (flask / psutil / requests) ..."
command -v pip3 >/dev/null 2>&1 || { $PKG_UPDATE >/dev/null 2>&1 || true; $PKG_INSTALL python3-pip >/dev/null 2>&1 || true; }
pip3 install --break-system-packages flask psutil requests -q 2>/dev/null \
  || pip3 install flask psutil requests -q 2>/dev/null \
  || $PKG_INSTALL python3-flask python3-psutil >/dev/null 2>&1 || true
if ! "$INSTALL_DIR/venv/bin/python3" -c "import flask" >/dev/null 2>&1; then
  echo -e "${YELLOW}[提示] flask 未自动安装成功，面板可能无法启动。可手动执行:${NC}"
  echo -e "${YELLOW}  apt install -y python3-flask python3-psutil${NC}"
fi

# ---------- 5. 生成账号 / 证书 / 配置 ----------
echo -e "${GREEN}[4/6] 生成管理员账号与 SSL 证书${NC}"
mkdir -p "$INSTALL_DIR/data"
if [ -z "$ADMIN_PASS" ]; then
  ADMIN_PASS="$(openssl rand -hex 4)"
  echo -e "${YELLOW}  已随机生成管理员密码${NC}"
fi
# 自签名证书（默认开启 HTTPS）
SSL_ENABLED=true
SSL_DIR="$INSTALL_DIR/ssl"
if [ -z "$NO_SSL" ]; then
  mkdir -p "$SSL_DIR"
  if [ ! -f "$SSL_DIR/cert.pem" ] || [ ! -f "$SSL_DIR/key.pem" ]; then
    openssl req -x509 -newkey rsa:2048 -nodes -days 3650 \
      -keyout "$SSL_DIR/key.pem" -out "$SSL_DIR/cert.pem" \
      -subj "/C=CN/O=XPanel/OU=XiXu/CN=xpanel.local" >/dev/null 2>&1 \
      && echo "  已生成自签名 SSL 证书（默认 HTTPS 访问）" \
      || { echo -e "${YELLOW}  证书生成失败，面板将以 HTTP 启动${NC}"; SSL_ENABLED=false; }
  else
    echo "  检测到已有 SSL 证书，沿用"
  fi
else
  SSL_ENABLED=false
fi
cat > "$INSTALL_DIR/data/panel.json" <<EOF
{
  "port": $PANEL_PORT,
  "admin_user": "$ADMIN_USER",
  "admin_password": "$ADMIN_PASS",
  "www_root": "$WWW_ROOT",
  "mail_root": "$MAIL_ROOT_DIR",
  "ssl": $SSL_ENABLED
}
EOF
# 数据目录（受限环境创建失败不中断，面板运行时会按需创建）
mkdir -p "$WWW_ROOT" 2>/dev/null || echo -e "${YELLOW}  警告：无法创建 $WWW_ROOT，稍后由面板自动创建${NC}"
mkdir -p "$NGINX_VHOST_DIR" 2>/dev/null || echo -e "${YELLOW}  警告：无法创建 $NGINX_VHOST_DIR，稍后由面板自动创建${NC}"
mkdir -p "$MAIL_ROOT_DIR" 2>/dev/null || echo -e "${YELLOW}  警告：无法创建 $MAIL_ROOT_DIR，稍后由面板自动创建${NC}"

# ---------- 6. 注册 systemd 服务 + 安装 XIP 命令 ----------
if [ -z "$XPANEL_SKIP_SYSTEMD" ]; then
echo -e "${GREEN}[5/6] 注册服务并安装 XIP 管理命令${NC}"
cat > /etc/systemd/system/xpanel.service <<EOF
[Unit]
Description=XPanel Server Panel (希旭面板)
After=network.target
[Service]
Type=simple
WorkingDirectory=$INSTALL_DIR
Environment=XPANEL_PORT=$PANEL_PORT
ExecStart=$INSTALL_DIR/venv/bin/python3 -m xpanel.app
Restart=always
RestartSec=3
[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable xpanel >/dev/null 2>&1 || true
systemctl restart xpanel
# 安装 XIP 管理命令（仿宝塔 bt 命令）
if [ -f "$INSTALL_DIR/sh/xip" ]; then
  cp "$INSTALL_DIR/sh/xip" /usr/local/bin/xip
  chmod +x /usr/local/bin/xip
  echo "  已安装 XIP 管理命令（输入 xip 查看菜单）"
fi
else
  echo -e "${GREEN}[5/6] 跳过 systemd（XPANEL_SKIP_SYSTEMD=1，容器/测试环境）${NC}"
fi

# ---------- 7. 输出安装结果 ----------
sleep 2
IP=$(curl -s --max-time 3 https://api.ipify.org 2>/dev/null || hostname -I | awk '{print $1}')
if [ -z "$IP" ]; then IP="你的服务器IP"; fi
SCHEME="http"; [ "$SSL_ENABLED" = "true" ] && SCHEME="https"
echo ""
echo -e "${GREEN}============================================================${NC}"
echo -e "${GREEN}   ✅ XPanel 希旭面板 安装完成！${NC}"
echo -e "${GREEN}============================================================${NC}"
echo ""
echo -e "${YELLOW}  访问地址:${NC}  $SCHEME://$IP:$PANEL_PORT"
echo -e "${YELLOW}  内网地址:${NC}  $SCHEME://$(hostname -I 2>/dev/null | awk '{print $1}'):$PANEL_PORT"
echo ""
echo -e "${YELLOW}  用户名:${NC}    $ADMIN_USER"
echo -e "${YELLOW}  密  码:${NC}    $ADMIN_PASS"
echo ""
if [ "$SSL_ENABLED" = "true" ]; then
  echo -e "${BLUE}  已默认开启 HTTPS（自签名证书）。${NC}"
  echo -e "${BLUE}  浏览器提示证书不受信任时，点「高级 → 继续访问」即可。${NC}"
fi
echo -e "${BLUE}  请尽快登录面板并在「设置」中修改密码！${NC}"
echo ""
echo -e "${YELLOW}  Nginx / PHP / MySQL / 邮件等组件未随面板安装，${NC}"
echo -e "${YELLOW}  登录面板后首页会弹出「软件商店」引导按需安装。${NC}"
echo ""
echo -e "${GREEN}  常用管理命令（xip 命令，仿宝塔 bt）:${NC}"
echo "    xip                查看管理菜单"
echo "    xip restart        重启面板"
echo "    xip reload         重载面板"
echo "    xip resetpwd       重置登录密码"
echo "    xip setport        修改面板端口"
echo "    xip ssl on|off     开启/关闭 HTTPS"
echo "    xip info           查看面板信息"
echo "    systemctl status xpanel    # 查看面板状态"
echo ""
echo -e "${GREEN}============================================================${NC}"
